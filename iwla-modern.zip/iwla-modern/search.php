<?php
/**
 * Search results.
 */
get_header();
global $wp_query;
?>
<section class="page-hero">
	<div class="container">
		<h1>Search results</h1>
		<p class="lead">
			<?php
			printf(
				esc_html( _n( '%1$d result for "%2$s"', '%1$d results for "%2$s"', (int) $wp_query->found_posts, 'iwla-modern' ) ),
				(int) $wp_query->found_posts,
				esc_html( get_search_query() )
			);
			?>
		</p>
	</div>
</section>
<div class="container">
	<div class="content-wrap">
		<?php get_search_form(); ?>
		<?php if ( have_posts() ) : ?>
			<ul class="iwla-search-results">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<li>
						<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<p><?php echo esc_html( has_excerpt() ? get_the_excerpt() : wp_trim_words( wp_strip_all_tags( get_the_content() ), 28 ) ); ?></p>
					</li>
				<?php endwhile; ?>
			</ul>
		<?php else : ?>
			<h2>No matches</h2>
			<p>Nothing matched that search. Try a different word, or browse from the <a href="<?php echo esc_url( home_url( '/' ) ); ?>">home page</a> or the <a href="<?php echo esc_url( home_url( '/calendar/' ) ); ?>">calendar</a>.</p>
		<?php endif; ?>
	</div>
</div>
<?php get_footer(); ?>
