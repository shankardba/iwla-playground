# IWLA Modern

A modern, readable rebuild of the Arlington-Fairfax Chapter (Izaak Walton League of America) WordPress site, replacing the legacy theme at [wp.arlingtonfairfax-iwla.org](https://wp.arlingtonfairfax-iwla.org).

## What's here

- A classic PHP WordPress theme (`style.css`, `functions.php`, `header.php`/`footer.php`, `page.php`, `front-page.php`) — semantic HTML5, mobile-first responsive layout, accessible contrast/focus states.
- Two custom post types so non-technical admins can update content from wp-admin with no code changes:
  - **Documents** (`inc/documents.php`) — chapter PDFs/forms hosted on Google Drive. Add a title + category + Drive link; use `[iwla_documents category="slug"]` anywhere in page content to list them.
  - **Events** (`inc/events.php`) — the chapter calendar. Add a title, date, and description; `[iwla_events limit="3"]` (or the home/front-page template) renders the soonest upcoming events automatically.
- `seed-content.php` — a one-time wp-cli script (`wp eval-file seed-content.php`) that creates the site's consolidated page structure (Home, About, Membership, Ranges & Training + sub-pages, Conservation, Youth Programs, Resources, Contact), the primary nav menu, and seed Documents/Events records. Content was consolidated from ~80 legacy pages down to a cleaner ~12-page structure, dropping stale/duplicate content (test pages, expired RFPs, one-off notices) while preserving every current fact.

## Local development

This was built against a lightweight local WordPress install using the official **SQLite Database Integration** plugin (no MySQL server needed):

```bash
brew install php wp-cli
wp core download
# install the SQLite Database Integration plugin's db.php drop-in, add
# define('DB_ENGINE', 'sqlite'); to wp-config.php before wp-settings.php loads
wp core install --url=http://localhost:8888 --title="..." --admin_user=admin --admin_password=... --admin_email=...
wp theme activate iwla-modern
wp eval-file seed-content.php
wp server --host=0.0.0.0 --port=8888
```

## Deploying elsewhere

Zip this directory and install it as a theme via **Appearance → Themes → Add New → Upload Theme** on any standard self-hosted WordPress site (or a WordPress.com Business-tier+ site — lower tiers block custom theme/plugin code entirely). Content can be brought over via **Tools → Export/Import** (WXR).

After activating on a new site:
1. **Settings → Reading**: set the imported "Home" page as the static front page.
2. **Appearance → Menus**: confirm the imported menu is assigned to the "Primary Navigation" location.
3. **Documents**: every seeded document starts with no Drive link — edit each one in wp-admin and paste in the real Google Drive share URL.
