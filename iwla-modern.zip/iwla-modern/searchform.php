<?php
/**
 * Search form.
 */
$iwla_uid = wp_unique_id( 'search-' );
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label for="<?php echo esc_attr( $iwla_uid ); ?>" class="screen-reader-text">Search the site</label>
	<input type="search" id="<?php echo esc_attr( $iwla_uid ); ?>" class="search-field" placeholder="Search the site" value="<?php echo esc_attr( get_search_query() ); ?>" name="s">
	<button type="submit" class="btn btn-primary btn-sm">Search</button>
</form>
