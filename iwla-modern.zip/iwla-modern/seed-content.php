<?php
/**
 * One-time content seed script for the IWLA Modern rebuild.
 * Run via: wp eval-file seed-content.php --allow-root
 */

function iwla_upsert_page( $args ) {
	$existing_posts = get_posts( array(
		'post_type'      => 'page',
		'name'           => $args['post_name'],
		'post_parent'    => $args['post_parent'] ?? 0,
		'post_status'    => 'any',
		'posts_per_page' => 1,
	) );
	$existing = $existing_posts ? $existing_posts[0] : null;
	$postarr  = array(
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_title'   => $args['post_title'],
		'post_name'    => $args['post_name'],
		'post_content' => $args['post_content'],
		'post_excerpt' => $args['post_excerpt'] ?? '',
		'post_parent'  => $args['post_parent'] ?? 0,
		'menu_order'   => $args['menu_order'] ?? 0,
	);
	if ( $existing ) {
		$postarr['ID'] = $existing->ID;
		wp_update_post( $postarr );
		return $existing->ID;
	}
	return wp_insert_post( $postarr );
}

/* ---------------- HOME ---------------- */
$home_id = iwla_upsert_page( array(
	'post_title'   => 'Home',
	'post_name'    => 'home',
	'post_content' => '',
	'post_excerpt' => 'Conserving land, water & wildlife in Northern Virginia since 1936.',
) );

/* ---------------- ABOUT ---------------- */
$about_content = <<<HTML
<h2>Who we are</h2>
<p>The Arlington-Fairfax Chapter, Inc. was originally chartered as the Falls Church Chapter by the Izaak Walton League of America in February 1936, and renamed to its current name in 1938. On March 4, 1947 the chapter incorporated as a not-for-profit corporation under Virginia law, and the IRS later approved it as a 501(c)(3) nonprofit educational corporation.</p>
<p>Today the chapter holds 110 acres in Fairfax County, Virginia, obtained in 1952. The Conservation Field House was built in 1965. In the 1960s, Fairfax County acquired land to build Interstate 66, leaving a small ~4.5-acre parcel on the far side of I-66. In the 1990s the chapter acquired a small parcel beside the Skeet &amp; Trap range.</p>
<p>The Air Range began in 1994 as a public youth shooting outreach program &mdash; a seven-lane range in a three-stall garage. A 26-lane expansion, started in 2014, finished in 2015 in time for the World Police and Fire Games held that year in Fairfax County; the range is now home to seven air rifle teams.</p>

<h2>Our mission</h2>
<p>To conserve, restore, and promote the sustainable use and enjoyment of our natural resources &mdash; soil, air, woods, waters, and wildlife.</p>
<blockquote>"To strive for the purity of water, the clarity of air, and the wise stewardship of the land and its resources; to know the beauty and understanding of nature and the value of wildlife, woodlands, and open space; to the preservation of this heritage and to man's sharing in it. I pledge myself as a member of the Izaak Walton League of America." &mdash; IWLA Member Pledge</blockquote>
<p>The Izaak Walton League of America is a national environmental organization founded in 1922 in Chicago by a group of sportsmen who wanted to protect fishing opportunities for the future. With nearly 270 local chapters nationwide, it remains one of the country's oldest grassroots conservation organizations.</p>

<h2>What the chapter offers</h2>
<ul>
<li>An Olympic-style target archery range</li>
<li>A shotgun range with 4 fields (1 trap-only, 3 skeet or trap)</li>
<li>An indoor 26-position air gun range</li>
<li>A 17-point outdoor rifle &amp; pistol range with target placements at 25, 50, 75, and 100 yards</li>
<li>An indoor archery range</li>
<li>Three outdoor field archery ranges &mdash; two 14-point walking ranges and a sighting-in range with a crossbow station</li>
<li>A 2-acre catch-and-release fishing pond</li>
<li>Campgrounds with rustic camp sites</li>
<li>Picnic areas with pavilions, a playground, and a playing field</li>
</ul>
<p>Facility use requires chapter membership, being an escorted guest of a member, or attending an open public/special event (such as the annual Women on Target clinic, monthly Bullseye pistol matches, or a Youth Activities program).</p>

<h2>Governance &amp; bylaws</h2>
<p>The chapter is run by an elected Board of Directors under its governing bylaws and policies.</p>
<div class="fact-grid">
<div class="fact"><span class="k">Bylaws booklet</span><span class="v">Issued/revised November 2024</span></div>
<div class="fact"><span class="k">Chapter policies</span><span class="v">Revised April 2026</span></div>
</div>
<p>Both documents are version-controlled and maintained by the Bylaws/Policy Committee (Chair: Mark Gauntner; Members: Keith Kuck, Pamela Meara).</p>
[iwla_documents category="governance" limit="10"]

<h2>Chapter elections</h2>
<p>Elections are held annually for half of the Board of Directors' positions; members serve two-year terms.</p>
<ul>
<li>Nominations close at the June general membership meeting, where the nominating committee presents a slate; additional floor nominations are also accepted that meeting.</li>
<li>Election polls are open two consecutive weekends in July, 9&nbsp;a.m.&ndash;5&nbsp;p.m., before the July regular membership meeting.</li>
<li>Results are announced at the July general membership meeting.</li>
<li>Newly elected board members are sworn in at the August general membership meeting.</li>
</ul>
<p><strong>2026 election:</strong> results were announced at the July 21, 2026 membership meeting; new board members are sworn in at the August 18, 2026 General Membership Meeting.</p>
<p>Election Committee: Chair Tom Pike, Member Oscar Starz. Questions about running for an open position can go to the Chapter Nomination/Election Chairmen via the <a href="/contact/">contact page</a>.</p>
HTML;

$about_id = iwla_upsert_page( array(
	'post_title'   => 'About',
	'post_name'    => 'about',
	'post_content' => $about_content,
	'post_excerpt' => 'A 90-year-old member-run conservation chapter on 110 acres in Fairfax County — our history, mission, and governance.',
) );

/* ---------------- MEMBERSHIP ---------------- */
$membership_content = <<<HTML
<div class="callout">
<span class="icon">&#9989;</span>
<div><strong>2027 renewals open October 15, 2026</strong>
<p>Renew online between October 15 and December 31, 2026. Any renewal received after 12/31/2026 incurs a $40 late fee &mdash; no exceptions. Renew online, by mailed renewal form, or by dropping off payment at the membership office.</p></div>
</div>

<h2>Joining the chapter</h2>
<p>New members join in four steps:</p>
<ol>
<li><strong>Attend a 3-hour New Member Orientation class.</strong> A reservation is required through SignUpGenius &mdash; see the <a href="/resources/#calendar">chapter calendar</a> for upcoming dates.</li>
<li><strong>Pay your initiation fee and first year's dues</strong> at the orientation class (checks, cash, or PayPal credit card accepted).</li>
<li><strong>Attend a General Membership meeting</strong> to be voted in.</li>
<li><strong>Complete 6 hours of service to the chapter</strong> &mdash; grounds or range maintenance, project support, or indoor service &mdash; to receive your permanent range badge.</li>
</ol>

<div class="fact-grid">
<div class="fact"><span class="k">Initiation fee</span><span class="v">$190, one-time</span></div>
<div class="fact"><span class="k">Individual membership</span><span class="v">$211/yr &middot; 1 range badge</span></div>
<div class="fact"><span class="k">Family membership</span><span class="v">$310.50/yr &middot; 2 range badges, both adults 18+</span></div>
</div>

<h2>What membership includes</h2>
<p>One membership gives access to every range and program on the property: Olympic-style target archery, a 4-field shotgun range, an indoor 26-lane air range, a 17-point rifle &amp; pistol range, an indoor archery range, three field archery ranges, a catch-and-release fishing pond, and campgrounds. Members may also join monthly Bullseye pistol and air pistol matches, the Bull Run Muzzle Loaders shoot, High Power rifle practice, registered ATA/NSSA shoots, JOAD archery, NoVA Sharpshooters, and the annual Women on Target clinic.</p>
<p>Range-qualified members may bring a guest up to three times a year (some ranges charge a guest fee); immediate family may be brought as guests an unlimited number of times, fee-free. Firearm ranges may only be used when a Range Safety Officer is present.</p>

<h2>Membership office</h2>
<div class="fact-grid">
<div class="fact"><span class="k">Location</span><span class="v">Chapter Field House</span></div>
<div class="fact"><span class="k">Tuesday</span><span class="v">1&ndash;4 p.m.</span></div>
<div class="fact"><span class="k">Saturday</span><span class="v">9 a.m.&ndash;1 p.m.</span></div>
<div class="fact"><span class="k">Closed</span><span class="v">Easter &amp; Christmas</span></div>
</div>
<p>Phone <a href="tel:7036314495">703-631-4495</a> during office hours (leave a message with your name and number if you miss us), or email <a href="mailto:membershipscy@arlingtonfairfax-iwla.org">membershipscy@arlingtonfairfax-iwla.org</a> &mdash; include a subject line; we respond weekly.</p>

<h2>Renewing your membership</h2>
<p>Save time by renewing online each October. Renewal issues can be directed to the membership office at <a href="tel:7036314495">703-631-4495</a>.</p>
[iwla_documents category="forms" limit="10"]
<a class="btn btn-primary" href="/contact/">Contact the membership office</a>
HTML;

$membership_id = iwla_upsert_page( array(
	'post_title'   => 'Membership',
	'post_name'    => 'membership',
	'post_content' => $membership_content,
	'post_excerpt' => 'How to join, what it costs, and everything one membership unlocks.',
) );

/* ---------------- CONTACT ---------------- */
$contact_content = <<<HTML
<h2>Visit the chapter</h2>
<div class="fact-grid">
<div class="fact"><span class="k">Property address</span><span class="v">14708 Mount Olive Road, Centreville, VA 20121</span></div>
<div class="fact"><span class="k">Mailing address</span><span class="v">PO Box 366, Centreville, VA 20122</span></div>
<div class="fact"><span class="k">Main phone</span><span class="v"><a href="tel:7036314495">703-631-4495</a></span></div>
</div>

<h3>Hours of operation</h3>
<ul>
<li>Outdoor recreation &amp; outdoor ranges: 8&nbsp;a.m.&ndash;9&nbsp;p.m.</li>
<li>Indoor uses &amp; indoor ranges: 8&nbsp;a.m.&ndash;12 midnight</li>
</ul>
<p>Extended hours apply for staffed, scheduled events (camping, etc). See each range's page for its specific operating days and times.</p>

<h3>Facility phone numbers</h3>
<div class="table-scroll"><table>
<tr><th>Facility</th><th>Phone</th></tr>
<tr><td>Chapter Field House</td><td><a href="tel:7036314495">703-631-4495</a></td></tr>
<tr><td>Rifle-Pistol Range</td><td><a href="tel:7036314496">703-631-4496</a></td></tr>
<tr><td>Skeet &amp; Trap Range</td><td><a href="tel:7036314497">703-631-4497</a></td></tr>
<tr><td>Sills Air Range</td><td><a href="tel:7036314818">703-631-4818</a></td></tr>
<tr><td>Field Archery Range</td><td><a href="tel:7036314498">703-631-4498</a></td></tr>
</table></div>

<h3>Directions</h3>
<div class="map-embed"><iframe src="https://maps.google.com/maps?q=14708+Mount+Olive+Road%2C+Centreville%2C+VA+20121&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="Map showing the Arlington-Fairfax Chapter property at 14708 Mount Olive Road, Centreville, VA"></iframe></div>
<p><a href="https://www.google.com/maps/search/?api=1&query=14708+Mount+Olive+Road+Centreville+VA+20121" target="_blank" rel="noopener">Open in Google Maps &rarr;</a></p>

<h2>Officers &amp; Directors</h2>
<p>Each director oversees a chapter discipline; committee liaisons are noted on their program's page. All emails are @arlingtonfairfax-iwla.org unless noted.</p>
<div class="table-scroll"><table>
<tr><th>Role</th><th>Name</th><th>Contact</th><th>Term ends</th></tr>
<tr><td>President</td><td>Pamela Meara</td><td><a href="tel:7033627293">703-362-7293</a> &middot; <a href="mailto:Pam.Meara@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Vice-President</td><td>Brian Hickerson</td><td><a href="tel:7039265711">703-926-5711</a> &middot; <a href="mailto:Brian.Hickerson@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Secretary</td><td>Bruce Crandlemire</td><td><a href="tel:7039270090">703-927-0090</a> &middot; <a href="mailto:Bruce.Crandlemire@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Treasurer</td><td>Bob Crisman</td><td><a href="tel:7037271946">703-727-1946</a> &middot; <a href="mailto:Bob.Crisman@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Membership Chairman</td><td>Jeff Tackett</td><td><a href="tel:7036314495">703-631-4495</a> &middot; <a href="mailto:Jeff.Tackett@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Director &ndash; Air Range</td><td>Keith Kuck</td><td><a href="tel:7034058935">703-405-8935</a> &middot; <a href="mailto:Keith.Kuck@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Director &ndash; Conservation</td><td>Jack Scheible</td><td><a href="tel:7039636059">703-963-6059</a> &middot; <a href="mailto:jack.scheible@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Director &ndash; Education</td><td>John Seaberg</td><td><a href="tel:7038250685">703-825-0685</a> &middot; <a href="mailto:John.Seaberg@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Director &ndash; Field Archery</td><td>Dick Riemer</td><td><a href="tel:7035438585">703-543-8585</a> &middot; <a href="mailto:Dick.Riemer@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Director &ndash; Rifle/Pistol</td><td>Chip Chidester</td><td><a href="tel:7039667369">703-966-7369</a> &middot; <a href="mailto:Chip.Chidester@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Director &ndash; Skeet &amp; Trap</td><td>Bob Brino</td><td><a href="tel:7033684934">703-368-4934</a> &middot; <a href="mailto:Bob.Brino@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Director &ndash; Target Archery</td><td>Jeff DelVecchio</td><td><a href="tel:7578137545">757-813-7545</a> &middot; <a href="mailto:Jeff.DelVecchio@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Director &ndash; Youth Activities</td><td>Joe Turner</td><td><a href="tel:7036284808">703-628-4808</a> &middot; <a href="mailto:Joe.Turner@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Director-at-Large</td><td>Benn Crandall</td><td><a href="mailto:Benn.Crandall@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Director-at-Large</td><td>Mark Gauntner</td><td><a href="tel:7039439946">703-943-9946</a> &middot; <a href="mailto:Mark.Gauntner@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Director-at-Large</td><td>John Lindamood</td><td><a href="tel:7032013667">703-201-3667</a> &middot; <a href="mailto:John.Lindamood@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Director-at-Large</td><td>Chencho Orta</td><td><a href="tel:5717236716">571-723-6716</a> &middot; <a href="mailto:Chencho.Orta@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Director-at-Large</td><td>Tom Pike</td><td><a href="tel:7038020740">703-802-0740</a> &middot; <a href="mailto:Tom.Pike@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Director-at-Large</td><td>Oscar Starz</td><td><a href="tel:7033218626">703-321-8626</a> &middot; <a href="mailto:Oscar.Starz@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
</table></div>
HTML;

$contact_id = iwla_upsert_page( array(
	'post_title'   => 'Contact',
	'post_name'    => 'contact',
	'post_content' => $contact_content,
	'post_excerpt' => 'Directions, hours, facility phone numbers, and the full Officers & Directors list.',
) );

/* ---------------- RANGES (parent + children) ---------------- */
$ranges_content = <<<HTML
<div class="callout">
<span class="icon">&#9888;&#65039;</span>
<div><strong>Range badge required on every range</strong>
<p>All members must display their range badge whenever they access or use any chapter range, archery or firearm. Firearm ranges may only be used when a Range Safety Officer is on duty.</p></div>
</div>
<p>The chapter's five member ranges sit on 110 acres in Centreville. All are closed Easter and Christmas, and all firearm ranges are closed when no Range Safety Officer is present. Choose a range below for its hours, rules, and leagues.</p>
<div class="grid grid-3">
<div class="card"><h3><a href="/ranges/rifle-pistol/">Rifle &amp; Pistol</a></h3><p>17-position outdoor range, target placements at 25&ndash;100 yards, plus Bullseye pistol leagues.</p></div>
<div class="card"><h3><a href="/ranges/skeet-trap/">Skeet &amp; Trap</a></h3><p>4-field shotgun range hosting the Winter League and the Crush'n Clays charity shoot.</p></div>
<div class="card"><h3><a href="/ranges/archery/">Archery</a></h3><p>Target, field, and indoor air archery, plus Cub Run Archers and JOAD training.</p></div>
<div class="card"><h3><a href="/ranges/facilities-use/">Facility Use Requests</a></h3><p>Ground rules for members, nonprofits, and youth groups using chapter property.</p></div>
</div>
HTML;

$ranges_id = iwla_upsert_page( array(
	'post_title'   => 'Ranges & Training',
	'post_name'    => 'ranges',
	'post_content' => $ranges_content,
	'post_excerpt' => 'Five member ranges on 110 acres — rifle & pistol, skeet & trap, and archery — plus facility use rules.',
) );

$rifle_content = <<<HTML
<div class="fact-grid">
<div class="fact"><span class="k">Director</span><span class="v">Chip Chidester</span></div>
<div class="fact"><span class="k">Field house phone</span><span class="v"><a href="tel:7036314496">703-631-4496</a></span></div>
<div class="fact"><span class="k">Range size</span><span class="v">17 shooting positions, targets at 25/50/75/100 yd</span></div>
</div>

<h2>Hours of operation</h2>
<p><em>RSO availability permitting &mdash; always check the <a href="/resources/#calendar">online calendar</a>.</em></p>
<div class="table-scroll"><table>
<tr><th></th><th>Regular season</th><th>Winter (Nov&ndash;Feb)</th></tr>
<tr><td>Weekdays</td><td>8 a.m.&ndash;5 p.m.</td><td>9 a.m.&ndash;4 p.m.</td></tr>
<tr><td>Saturday</td><td>8 a.m.&ndash;5 p.m.</td><td>9 a.m.&ndash;4 p.m.</td></tr>
<tr><td>Sunday</td><td>12&ndash;5 p.m.</td><td>12&ndash;4 p.m.</td></tr>
</table></div>
<p>Closed Easter &amp; Christmas. If Fairfax County schools close for weather, hours may vary. Short Range Day is currently suspended until further notice (as of August 21, 2026).</p>

<h2>On the range</h2>
<ul>
<li>Wear your range qualification badge at all times.</li>
<li>No steel-core ammunition &mdash; if it sticks to the provided magnet, it isn't allowed.</li>
<li>Recycle spent brass in the brass bucket (no steel, aluminum, nickel-plated cases, or shotgun shells); aluminum cans go in the separate firing-line bin.</li>
<li>No targets may be posted between the firing line and 25 yards.</li>
</ul>

<h2>Bullseye Pistol Leagues</h2>
<p>Two leagues run at the Rifle/Pistol range &mdash; newcomers are welcome and the matches are relaxed and social:</p>
<ul>
<li><strong>Rimfire League:</strong> usually the 1st Sunday, March&ndash;August.</li>
<li><strong>Centerfire League:</strong> usually the 1st Sunday, September&ndash;December.</li>
</ul>
<p>Contact Rich Sirois at <a href="mailto:rich.sirois@gmail.com">rich.sirois@gmail.com</a> or <a href="tel:4013658950">401-365-8950</a> for current flyers and schedule.</p>

<p>Full range rules are set out in the chapter bylaws (issued/revised November 19, 2024); direct questions to the Director above or the <a href="/contact/">Officers &amp; Directors</a> page.</p>
HTML;

$rifle_id = iwla_upsert_page( array(
	'post_title'   => 'Rifle & Pistol Range',
	'post_name'    => 'rifle-pistol',
	'post_content' => $rifle_content,
	'post_excerpt' => 'Hours, on-range rules, and the chapter\'s Bullseye Pistol leagues.',
	'post_parent'  => $ranges_id,
	'menu_order'   => 1,
) );

$skeet_content = <<<HTML
<div class="fact-grid">
<div class="fact"><span class="k">Director</span><span class="v">Bob Brino</span></div>
<div class="fact"><span class="k">Field house phone</span><span class="v"><a href="tel:7036314497">703-631-4497</a></span></div>
<div class="fact"><span class="k">Fields</span><span class="v">4 fields &mdash; 1 trap-only, 3 skeet or trap</span></div>
</div>

<h2>Hours of operation</h2>
<div class="table-scroll"><table>
<tr><th>Monday</th><td>8 a.m.&ndash;2 p.m.</td></tr>
<tr><th>Wednesday</th><td>8 a.m.&ndash;2 p.m.</td></tr>
<tr><th>Friday</th><td>8 a.m.&ndash;2 p.m.</td></tr>
<tr><th>Saturday</th><td>8 a.m.&ndash;5 p.m.</td></tr>
<tr><th>Sunday</th><td>12&ndash;5 p.m.</td></tr>
</table></div>
<p>Closed Easter &amp; Christmas, and any day without a Range Safety Officer present.</p>

<h2>Leagues &amp; events</h2>
<ul>
<li><strong>'Bucky' Sills Winter Skeet &amp; Trap League</strong> &mdash; begins the first Sunday after New Year's Day and runs 13 weeks. Started in the mid-1980s, it now fields 28 six-shooter teams (168 members) across six 50-target rounds of skeet and trap.</li>
<li><strong>28th Annual Crush'n Clays</strong> &mdash; VSSA charity shoot benefiting St. Jude Children's Research Hospital, co-sponsored with the Virginia Shooting Sports Association. Save the date: <strong>Saturday, June 12, 2027.</strong></li>
<li><strong>NRA Women on Target Clinic</strong> &mdash; see the <a href="/youth/">Youth &amp; Programs</a> page for the current date and registration link.</li>
</ul>
<p>Questions: Skeet &amp; Trap Director Bob Brino, <a href="tel:7033684934">703-368-4934</a> or <a href="mailto:Bob.Brino@arlingtonfairfax-iwla.org">Bob.Brino@arlingtonfairfax-iwla.org</a>.</p>
<p>Full range rules are set out in the chapter bylaws (issued/revised November 19, 2024); direct questions to the Director above or the <a href="/contact/">Officers &amp; Directors</a> page.</p>
HTML;

$skeet_id = iwla_upsert_page( array(
	'post_title'   => 'Skeet & Trap Range',
	'post_name'    => 'skeet-trap',
	'post_content' => $skeet_content,
	'post_excerpt' => 'Hours, the Winter League, and the 28th Annual Crush\'n Clays charity shoot.',
	'post_parent'  => $ranges_id,
	'menu_order'   => 2,
) );

$archery_content = <<<HTML
<h2>Target Archery</h2>
<div class="fact-grid">
<div class="fact"><span class="k">Director</span><span class="v">Ryan Johnson</span></div>
<div class="fact"><span class="k">Outdoor range hours</span><span class="v">8 a.m.&ndash;9 p.m. daily, incl. Easter &amp; Christmas</span></div>
</div>
<p>The 90-meter outdoor target field sits next to the field house; the chapter also shoots indoors during winter months. The Junior Olympic Archery Development (JOAD) program and Adult Archery Program (AAP) &mdash; together called the Competition Archery Team &mdash; train youth and adults in Olympic-style archery through 12-week sessions, and periodically run U.S. Archery Level 1&ndash;3 Instructor/Coach classes. Open shooting and instruction run Thursday evenings, 7&ndash;9 p.m.</p>
<p>The chapter also hosts 'STAR FITA' tournaments &mdash; national-record-eligible events at 18 meters indoors (fall and winter weekends) and up to 90 meters outdoors (May/June, 11 lanes). Register via the form linked on the chapter calendar; results and range records are posted after each event.</p>

<h2>Field Archery</h2>
<div class="fact-grid">
<div class="fact"><span class="k">Director</span><span class="v">Dick Riemer</span></div>
<div class="fact"><span class="k">Field house phone</span><span class="v"><a href="tel:7036314498">703-631-4498</a></span></div>
<div class="fact"><span class="k">Indoor range</span><span class="v">Mon&ndash;Sun, 8 a.m.&ndash;midnight (member-attended)</span></div>
<div class="fact"><span class="k">Outdoor range</span><span class="v">8 a.m.&ndash;9 p.m. daily</span></div>
</div>
<ul>
<li>Main outdoor range, 5&ndash;60 yards, lighted; crossbow sighting-in station on the left side.</li>
<li>Two 14-point walk-through 3D/field ranges to 80 yards (28 targets total).</li>
<li>Two elevated tree stands (safety harness required).</li>
<li>Indoor range: 11 lanes at 20 yards.</li>
</ul>

<h2>Air Range</h2>
<p>See the <a href="/about/">About</a> page for the range's history. Rules for the indoor air range are set out in the chapter bylaws (issued/revised November 2024) &mdash; direct questions to the Director &ndash; Air Range on the <a href="/contact/">Officers &amp; Directors</a> page.</p>

<h2>Cub Run Archers Club</h2>
<p>The Cub Run Archers (CRA) is a chapter-authorized club promoting field archery to National Field Archery Association (NFAA) standards, and is a chartered member of the Virginia Field Archery Association and Virginia Bowhunter's Association. Monthly meetings are the first Sunday of the month, 1&ndash;3 p.m., at the Field Archery house.</p>
<p><strong>2026 chapter archery shoots:</strong> Spring Fling &mdash; May 3; Summer Sizzler &mdash; June 27; Buck Buster &mdash; August 9.</p>
<p>Contact CRA President Mark Gauntner at <a href="mailto:Gauntneriwla201@gmail.com">Gauntneriwla201@gmail.com</a>, or find the club on Facebook.</p>

<h2>Archery 101 / 201 &amp; instructor training</h2>
<p>Beginner classes (Archery 101) and 5-week 201 sessions run periodically for new archers, alongside U.S. Archery Level 1 and Level 2 Instructor Training &mdash; 8-hour courses covering the National Training System steps of shooting, equipment setup, and (Level 2) coaching methods needed to lead JOAD, AAP, or collegiate programs. No prior experience is required. Contact the Target Archery Director for scheduling and course payment.</p>
HTML;

$archery_id = iwla_upsert_page( array(
	'post_title'   => 'Archery',
	'post_name'    => 'archery',
	'post_content' => $archery_content,
	'post_excerpt' => 'Target, field, and air archery — hours, tournaments, Cub Run Archers, and instructor training.',
	'post_parent'  => $ranges_id,
	'menu_order'   => 3,
) );

$facuse_content = <<<HTML
<p>The chapter is not a commercial facility, but does allow use of its property by nonprofits, youth groups, and members.</p>
<div class="callout callout-danger">
<span class="icon">&#128663;</span>
<div><strong>Speed limit: 10 MPH, radar enforced</strong><p>Per chapter ground rules and posted signs, to protect members, guests, and wildlife.</p></div>
</div>
<h2>Ground rules for facility use</h2>
<ul>
<li>Do not park or drive on the athletic field.</li>
<li>Take all trash with you, or use the appropriate trash receptacle &mdash; don't leave trash in campgrounds, pavilions, or other chapter facilities.</li>
<li>Build fires only in existing fire pits; burn only wood, charcoal, or kindling (no cans, bottles, or food waste).</li>
<li>Don't throw rocks on pavilion roofs, tear down signs, dig holes, or otherwise damage chapter property.</li>
<li>Shooting is prohibited anywhere on chapter grounds except the designated ranges.</li>
<li>Leave the area cleaner than you found it.</li>
<li>No child or group of children may be left unsupervised.</li>
<li>Firewood near campsites 1 &amp; 2 is sometimes available for campground fire pits; otherwise bring your own. Do not take stacked/split wood that is for sale near the large pavilion.</li>
</ul>
<p>To request use of chapter facilities for a group or event, contact the chapter office via the <a href="/contact/">Contact page</a>.</p>
HTML;

$facuse_id = iwla_upsert_page( array(
	'post_title'   => 'Facility Use Requests',
	'post_name'    => 'facilities-use',
	'post_content' => $facuse_content,
	'post_excerpt' => 'Ground rules for members, nonprofits, and youth groups using chapter property.',
	'post_parent'  => $ranges_id,
	'menu_order'   => 4,
) );

/* ---------------- CONSERVATION ---------------- */
$conservation_content = <<<HTML
<p>The Izaak Walton League's founding mission is leadership in conserving woodlands, wildlife, water, and related natural resources. The Arlington-Fairfax Chapter pursues that through year-round formal and informal work:</p>
<ul>
<li>Preserving natural areas for members and the community</li>
<li>Providing sufficient natural habitat for wildlife</li>
<li>Ensuring the survival of native plants and animals</li>
<li>Enhancing chapter property for fishing, camping, and outdoor recreation</li>
<li>Improving environmental quality and promoting environmental responsibility through education</li>
</ul>
<p>Conservation work is coordinated with the chapter's Buildings &amp; Grounds committee to set project priorities, evaluate environmental impact, and stay compliant with applicable regulations. Members with a conservation or environmental science background are encouraged to get involved &mdash; contact Conservation Director Fred Bailey at <a href="mailto:Fred.Bailey@arlingtonfairfax-iwla.org">Fred.Bailey@arlingtonfairfax-iwla.org</a>.</p>

<h2>Save Our Streams (SOS)</h2>
<p>The chapter runs a Virginia Save Our Streams water-monitoring program, part of the national IWLA program founded alongside the League in 1922. Volunteers monitor local waterways for the health of the surrounding watershed. Interested members can email <a href="mailto:ARLFXSOS@gmail.com">ARLFXSOS@gmail.com</a>, or see the <a href="https://www.iwla.org/water/stream-monitoring" target="_blank" rel="noopener">IWLA Save Our Streams</a> and Virginia SOS sites for forms and gear.</p>

<h2>Environmental Management System (EMS)</h2>
<p>For over 15 years the chapter has run an EMS to keep range operations from harming local water and land. Lime and rock phosphate are applied to the Skeet/Trap shot-fall area to bind lead and prevent it from leaching into surface and groundwater, surface water quality is sampled regularly, and the chapter has run two lead-reclamation projects removing over 500,000&nbsp;lbs of lead from the environment, alongside a shift to biodegradable targets at Skeet/Trap.</p>
<p>On March 29, 2022 the chapter received a Bronze Medal Governor's Environmental Excellence Award (Sustainability Program) at the 32nd Annual Virginia Environment Symposium at VMI, in recognition of this work.</p>

<h2>Other conservation efforts</h2>
<ul>
<li>Virginia Adopt-a-Highway</li>
<li>Cub Run Stream Valley Park volunteer team</li>
<li>Northern Virginia Native Plant Program</li>
<li>Member-maintained food plots, bee hives, and woodland areas</li>
<li>Scout-led conservation service projects on chapter property</li>
</ul>
<p>All chapter volunteer opportunities, including conservation projects, are posted through SignUpGenius &mdash; sign up to get credit toward your membership service hours, or just to help out.</p>
HTML;

$conservation_id = iwla_upsert_page( array(
	'post_title'   => 'Conservation',
	'post_name'    => 'conservation',
	'post_content' => $conservation_content,
	'post_excerpt' => 'Stream monitoring, an award-winning environmental management system, and habitat stewardship on our 110 acres.',
) );

/* ---------------- YOUTH ---------------- */
$youth_content = <<<HTML
<div class="callout">
<span class="icon">&#127919;</span>
<div><strong>Women on Target Clinic &mdash; May 16, 2026</strong>
<p>A safe, welcoming introduction to rifles, pistols, shotguns, muzzleloaders, and archery, plus non-shooting seminars (Refuse to Be a Victim, buying &amp; caring for a handgun, firearms &amp; the law). See the NRA <a href="https://wot.nra.org" target="_blank" rel="noopener">Women on Target</a> program for details, or contact the chapter to register.</p></div>
</div>

<h2>Junior Chapter</h2>
<p>Established in 2016, the Arlington-Fairfax Junior Chapter has about 200 members under 18, run by a nine-member youth Board of Directors elected annually. Membership in the Junior Chapter is required for any minor participating in organized shooting sports at the chapter. The Junior Chapter co-sponsors the annual <strong>Wendel Thompson Memorial Precision Air Rifle/Pistol Match</strong>, which has drawn 60+ competitors and served as a Virginia Shooting Sports Association state championship.</p>
<p><strong>Note:</strong> Minors under 18 may only use chapter facilities when accompanied by an adult member or participating in a chapter-sanctioned activity.</p>

<h2>Junior Olympic Archery Development (JOAD)</h2>
<p>JOAD teaches archers age 8&ndash;18 the fundamentals of Olympic-style archery &mdash; technique, tournament participation, equipment setup, physical fitness, and mental preparation &mdash; across three 12-week sessions a year at the indoor and outdoor ranges. All coaches are U.S. Archery Level 2/3 certified with SafeSport training and background checks. Sessions traditionally meet Sundays, 3&ndash;5 p.m.; check the chapter calendar for exact dates.</p>

<h2>Youth Shotgun Team</h2>
<p>Started in 2014, the chapter's youth trapshooting team (ages 12&ndash;22) competes Saturday afternoons through the Virginia Youth Trapshooting League (VYTL), using the AIM (Academics Integrity Marksmanship) format &mdash; the official ATA youth program. The regular season runs mid-March through mid-May (50 competition + up to 50 practice targets weekly), followed by a state tournament in Winchester, VA each June.</p>

<h2>NoVA Sharpshooters (NVSS)</h2>
<p>Two junior programs for ages 10&ndash;18, both requiring the Sills Air Range consumables fee and Junior Chapter membership:</p>
<ul>
<li><strong>Junior Pistol Program</strong> &mdash; 10m air pistol, with advanced athletes progressing to 25m sport pistol (.22 LR). Contact <a href="mailto:novasharpshootersiwla@gmail.com">novasharpshootersiwla@gmail.com</a>.</li>
<li><strong>Paralympic Junior Air Rifle Program</strong> &mdash; prepares Paralympic junior athletes for CMP, NRA, and USA Shooting events. Contact Tom Ciarula at <a href="mailto:ciarulat@cox.net">ciarulat@cox.net</a> or <a href="tel:7032500947">703-250-0947</a>.</li>
</ul>

<h2>High School Air Rifle Teams</h2>
<p>The chapter sponsors and hosts the home range for seven Potomac High School Rifle League (PHSRL) teams: Centreville, Fairfax, Lake Braddock, Robinson, West Springfield, and Woodson high schools, plus the independent Mavericks team.</p>

<h2>Scouting partnerships</h2>
<p>The chapter charters several local Scouting units, giving scouts a place to meet and complete conservation-minded service projects on chapter property.</p>
<div class="table-scroll"><table>
<tr><th>Unit</th><th>Leadership</th><th>Meets</th></tr>
<tr><td>Troop 695</td><td>Scoutmaster Ryan Frazier &middot; Chair Pam Gercken</td><td>Wednesdays 7:30&ndash;8:30 p.m., Brookfield ES</td></tr>
<tr><td>Pack 864</td><td>Cubmaster Chad Cerar &middot; Chair Arnold Heck</td><td>Centreville, VA</td></tr>
<tr><td>Troop 1137 (Boys)</td><td>Scoutmaster Jeff Mauck &middot; Chair Jake Marshak</td><td>Monday nights 7 p.m., chapter grounds</td></tr>
<tr><td>Troop 1137 (Girls)</td><td>Scoutmaster Jeff Tackett &middot; Chair Elias El-Hage</td><td>Monday nights 7 p.m., chapter grounds</td></tr>
<tr><td>Venture Crew 1137</td><td>Advisor Todd Martin &middot; Chair Jake Marshak</td><td>Centreville, VA</td></tr>
</table></div>
<p>For chapter Scouting questions, contact liaison Tom Pike at <a href="mailto:Tom.Pike@arlingtonfairfax-iwla.org">Tom.Pike@arlingtonfairfax-iwla.org</a>.</p>
HTML;

$youth_id = iwla_upsert_page( array(
	'post_title'   => 'Youth Programs',
	'post_name'    => 'youth',
	'post_content' => $youth_content,
	'post_excerpt' => 'JOAD archery, youth shotgun, NoVA Sharpshooters, high school air rifle, and five chartered Scouting units.',
) );

/* ---------------- RESOURCES ---------------- */
$resources_content = <<<HTML
<h2 id="calendar">Chapter calendar</h2>
<p>All upcoming chapter events, pulled automatically from the calendar &mdash; ranges post their specific hours here too, and cancellations are added as soon as they're known.</p>
[iwla_events limit="-1"]

<h2>Newsletters</h2>
<p>Published quarterly by the Newsletter Committee (Editor-in-Chief Pamela Meara, Copy Editor Tim Terrell, Design &amp; Production Ellen MacBrayne).</p>
[iwla_documents category="newsletters" limit="8"]
<p>Since 2024, delivery is electronic by default &mdash; contact the office to opt into a printed copy. Story ideas or questions: <a href="mailto:newsletter@arlingtonfairfax-iwla.org">newsletter@arlingtonfairfax-iwla.org</a>.</p>

<h2>Meeting minutes</h2>
<p>General Membership (GM) meets the 3rd Tuesday and the Board of Directors (BOD) meets the 1st Tuesday of each month, both at 7:30&nbsp;p.m.</p>
[iwla_documents category="minutes" limit="12"]
<p>Questions: <a href="mailto:info@arlingtonfairfax-iwla.org">info@arlingtonfairfax-iwla.org</a>.</p>

<h2>Awards, grants &amp; scholarship</h2>
<p>The Awards &amp; Grants Committee (Chair Scott Meyer, BOD Liaison Pamela Meara) identifies and tracks grant opportunities for chapter programs. Recent awards include grants from the Amateur Trapshooting Association, The NRA Foundation, NSSA, USA Archery, and Friends of the NRA. Contact <a href="mailto:arlfxawardsgrants@gmail.com">arlfxawardsgrants@gmail.com</a> or <a href="tel:7039992581">703-999-2581</a> to get involved.</p>
<p>Since 1993 the chapter has also funded an <strong>Environmental Sciences Scholarship</strong> for tri-county (Arlington, Fairfax, Prince William) students pursuing environmental science or a related field &mdash; currently $5,000/year for up to 4 years, paid directly to the recipient's institution. The scholarship committee reviews applications each April and recommends awards to the Board.</p>
[iwla_documents category="grants" limit="10"]

<h2>Chapter clubs &amp; groups</h2>
<div class="grid grid-3">
<div class="card"><h3>Knife Club</h3><p>Quarterly meetups for knife, ax, tomahawk, and multitool enthusiasts &mdash; workshops, safe-use classes, and sharpening clinics. Contact host Lt. Col. Matt Michaelson, USA (Ret.) at <a href="mailto:mtmichaelson@hotmail.com">mtmichaelson@hotmail.com</a>.</p></div>
<div class="card"><h3>Bull Run Muzzle Loaders</h3><p>An NMLRA charter club since 1988, shooting the 3rd Sunday of each month at the Rifle/Pistol range. All muzzleloader types welcome, loaner rifles available, no membership required to shoot.</p></div>
<div class="card"><h3>Firewood for Sale</h3><p>Mixed oak and hickory, cut and split, $350/cord, available seasonally. Buyers haul their own &mdash; no delivery. Contact <a href="mailto:arlfxiwla@gmail.com">arlfxiwla@gmail.com</a> for availability.</p></div>
</div>
HTML;

$resources_id = iwla_upsert_page( array(
	'post_title'   => 'Resources',
	'post_name'    => 'resources',
	'post_content' => $resources_content,
	'post_excerpt' => 'Newsletters, meeting minutes, awards & scholarships, the chapter calendar, and member clubs.',
) );

/* ---------------- EVENTS (chapter calendar) ---------------- */
function iwla_upsert_event( $title, $date, $description, $end_date = '' ) {
	$existing_posts = get_posts( array(
		'post_type'      => 'iwla_event',
		'title'          => $title,
		'post_status'    => 'any',
		'posts_per_page' => 1,
	) );
	$postarr = array(
		'post_type'    => 'iwla_event',
		'post_status'  => 'publish',
		'post_title'   => $title,
		'post_content' => $description,
	);
	if ( $existing_posts ) {
		$postarr['ID'] = $existing_posts[0]->ID;
		$id = wp_update_post( $postarr );
	} else {
		$id = wp_insert_post( $postarr );
	}
	update_post_meta( $id, '_iwla_event_date', $date );
	if ( $end_date ) {
		update_post_meta( $id, '_iwla_event_end_date', $end_date );
	}
	return $id;
}

iwla_upsert_event( '2026 Annual Picnic', '2026-09-12', 'Chapter-wide picnic for members and their families.' );
iwla_upsert_event( 'Christmas Party for Foster Children', '2026-12-12', 'A chapter tradition bringing holiday cheer to local foster children.' );
iwla_upsert_event( "28th Annual Crush'n Clays Charity Event", '2027-06-12', "VSSA charity shoot benefiting St. Jude Children's Research Hospital. Save the date." );

echo "Events seeded.\n";

/* ---------------- DOCUMENTS (Google Drive links) ---------------- */
function iwla_upsert_document( $title, $category ) {
	$existing_posts = get_posts( array(
		'post_type'      => 'iwla_document',
		'title'          => $title,
		'post_status'    => 'any',
		'posts_per_page' => 1,
	) );
	$postarr = array(
		'post_type'   => 'iwla_document',
		'post_status' => 'publish',
		'post_title'  => $title,
	);
	if ( $existing_posts ) {
		$postarr['ID'] = $existing_posts[0]->ID;
		$id = wp_update_post( $postarr );
	} else {
		$id = wp_insert_post( $postarr );
	}
	wp_set_object_terms( $id, $category, 'iwla_doc_category' );
	// Note: leaves _iwla_doc_url empty on purpose — edit this Document in
	// wp-admin and paste the real Google Drive share link.
	return $id;
}

foreach ( array(
	'Chapter Bylaws Booklet — Nov 2024',
	'Chapter Policies — Apr 2026',
) as $doc ) {
	iwla_upsert_document( $doc, 'governance' );
}

foreach ( array(
	'64-3 · Aug–Oct 2026',
	'64-2 · May–Jul 2026',
	'64-1 · Feb–Apr 2026',
	'63-4 · Nov 2025–Jan 2026',
	'63-3 · Aug–Oct 2025',
) as $doc ) {
	iwla_upsert_document( $doc, 'newsletters' );
}

foreach ( array(
	'07-21-2026 General Membership Minutes',
	'06-16-2026 General Membership Minutes',
	'06-02-2026 Board of Directors Minutes',
	'05-19-2026 General Membership Minutes',
	'05-05-2026 Board of Directors Minutes',
	'04-21-2026 General Membership Minutes',
	'04-07-2026 Board of Directors Minutes',
) as $doc ) {
	iwla_upsert_document( $doc, 'minutes' );
}

foreach ( array(
	'2027 Membership Renewal Form',
	'Environmental Sciences Scholarship Application',
) as $doc ) {
	iwla_upsert_document( $doc, 'forms' );
}

echo "Documents seeded (edit each in wp-admin to add its Google Drive link).\n";

/* ---------------- SITE SETTINGS: front page + menu ---------------- */
update_option( 'show_on_front', 'page' );
update_option( 'page_on_front', $home_id );

update_option( 'blogname', 'Arlington-Fairfax Chapter, IWLA' );
update_option( 'blogdescription', 'Conserving land, water & wildlife in Northern Virginia since 1936' );

$menu_name = 'Primary';
$menu_obj  = wp_get_nav_menu_object( $menu_name );
if ( ! $menu_obj ) {
	$menu_id = wp_create_nav_menu( $menu_name );
} else {
	$menu_id = $menu_obj->term_id;
	foreach ( wp_get_nav_menu_items( $menu_id ) as $item ) {
		wp_delete_post( $item->ID, true );
	}
}

function iwla_add_menu_item( $menu_id, $page_id, $parent_item_id = 0, $position = 0, $label = null ) {
	return wp_update_nav_menu_item( $menu_id, 0, array(
		'menu-item-title'     => $label ?? get_the_title( $page_id ),
		'menu-item-object-id' => $page_id,
		'menu-item-object'    => 'page',
		'menu-item-type'      => 'post_type',
		'menu-item-status'    => 'publish',
		'menu-item-parent-id' => $parent_item_id,
		'menu-item-position'  => $position,
	) );
}

iwla_add_menu_item( $menu_id, $home_id, 0, 1 );
iwla_add_menu_item( $menu_id, $about_id, 0, 2 );
iwla_add_menu_item( $menu_id, $membership_id, 0, 3 );
$ranges_item_id = iwla_add_menu_item( $menu_id, $ranges_id, 0, 4, 'Ranges' );
iwla_add_menu_item( $menu_id, $rifle_id, $ranges_item_id, 1 );
iwla_add_menu_item( $menu_id, $skeet_id, $ranges_item_id, 2 );
iwla_add_menu_item( $menu_id, $archery_id, $ranges_item_id, 3 );
iwla_add_menu_item( $menu_id, $facuse_id, $ranges_item_id, 4 );
iwla_add_menu_item( $menu_id, $conservation_id, 0, 5 );
iwla_add_menu_item( $menu_id, $youth_id, 0, 6, 'Youth' );
iwla_add_menu_item( $menu_id, $resources_id, 0, 7 );
iwla_add_menu_item( $menu_id, $contact_id, 0, 8 );

$locations = get_theme_mod( 'nav_menu_locations' );
$locations['primary'] = $menu_id;
set_theme_mod( 'nav_menu_locations', $locations );

echo "Menu set up. Front page: $home_id\n";
echo "DONE\n";
