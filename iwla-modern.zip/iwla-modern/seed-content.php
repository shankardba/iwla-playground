<?php
/**
 * One-time content seed script for the IWLA Modern rebuild.
 * Run via: wp eval-file seed-content.php --allow-root
 */

function iwla_upsert_page( $args ) {
	$existing_posts = get_posts( array(
		'post_type'      => 'page',
		'name'           => $args['post_name'],
		'post_parent'    => $args['post_parent'] ?? 0,
		'post_status'    => 'any',
		'posts_per_page' => 1,
	) );
	$existing = $existing_posts ? $existing_posts[0] : null;
	$postarr  = array(
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_title'   => $args['post_title'],
		'post_name'    => $args['post_name'],
		'post_content' => $args['post_content'],
		'post_excerpt' => $args['post_excerpt'] ?? '',
		'post_parent'  => $args['post_parent'] ?? 0,
		'menu_order'   => $args['menu_order'] ?? 0,
	);
	if ( $existing ) {
		$postarr['ID'] = $existing->ID;
		wp_update_post( $postarr );
		return $existing->ID;
	}
	return wp_insert_post( $postarr );
}

/* ---------------- HOME ---------------- */
$home_id = iwla_upsert_page( array(
	'post_title'   => 'Home',
	'post_name'    => 'home',
	'post_content' => '',
	'post_excerpt' => 'Conserving land, water & wildlife in Northern Virginia since 1936.',
) );

/* ---------------- ABOUT ---------------- */
$about_content = <<<HTML
<h2>Who we are</h2>
<p>The Arlington-Fairfax Chapter, Inc. was originally chartered as the Falls Church Chapter by the Izaak Walton League of America in February 1936, and renamed to its current name in 1938. On March 4, 1947 the chapter incorporated as a not-for-profit corporation under Virginia law, and the IRS later approved it as a 501(c)(3) nonprofit educational corporation.</p>
<p>Today the chapter holds 110 acres in Fairfax County, Virginia, obtained in 1952. The Conservation Field House was built in 1965. In the 1960s, Fairfax County acquired land to build Interstate 66, leaving a small ~4.5-acre parcel on the far side of I-66. In the 1990s the chapter acquired a small parcel beside the Skeet &amp; Trap range.</p>
<p>The Air Range began in 1994 as a public youth shooting outreach program &mdash; a seven-lane range in a three-stall garage. A 26-lane expansion, started in 2014, finished in 2015 in time for the World Police and Fire Games held that year in Fairfax County; the range is now home to seven air rifle teams.</p>

<h2>Our mission</h2>
<p>To conserve, restore, and promote the sustainable use and enjoyment of our natural resources &mdash; soil, air, woods, waters, and wildlife.</p>
<blockquote>"To strive for the purity of water, the clarity of air, and the wise stewardship of the land and its resources; to know the beauty and understanding of nature and the value of wildlife, woodlands, and open space; to the preservation of this heritage and to man's sharing in it. I pledge myself as a member of the Izaak Walton League of America." &mdash; IWLA Member Pledge</blockquote>
<p>The Izaak Walton League of America is a national environmental organization founded in 1922 in Chicago by a group of sportsmen who wanted to protect fishing opportunities for the future. With nearly 270 local chapters nationwide, it remains one of the country's oldest grassroots conservation organizations.</p>

<p>The chapter also held a 50-plus-acre wooded property in Shenandoah County, acquired in 1997 when the Annandale-Springfield Chapter closed. It was sold in June 2026 and is no longer available to members.</p>

<h2>What the chapter offers</h2>
<ul>
<li>An Olympic-style target archery range</li>
<li>A shotgun range with 4 fields (1 trap-only, 3 skeet or trap)</li>
<li>An indoor 26-position air gun range</li>
<li>A 17-point outdoor rifle &amp; pistol range with target placements at 25, 50, 75, and 100 yards</li>
<li>An indoor archery range</li>
<li>Three outdoor field archery ranges &mdash; two 14-point walking ranges and a sighting-in range with a crossbow station</li>
<li>A 2-acre catch-and-release fishing pond</li>
<li>Campgrounds with rustic camp sites</li>
<li>Picnic areas with pavilions, a playground, and a playing field</li>
</ul>
<p>Facility use requires chapter membership, being an escorted guest of a member, or attending an open public/special event (such as the annual Women on Target clinic, monthly Bullseye pistol matches, or a Youth Activities program).</p>

<h2 id="governance">Governance &amp; bylaws</h2>
<p>The chapter is run by an elected Board of Directors under its governing bylaws and policies.</p>
<div class="fact-grid">
<div class="fact"><span class="k">Bylaws booklet</span><span class="v">Issued/revised November 2024</span></div>
<div class="fact"><span class="k">Chapter policies</span><span class="v">Revised April 2026</span></div>
</div>
<p>Both documents are version-controlled and maintained by the Bylaws/Policy Committee (Chair: Mark Gauntner; Members: Keith Kuck, Pamela Meara).</p>
[iwla_documents category="governance" limit="10"]

<h2 id="elections">Chapter elections</h2>
<p>Elections are held annually for half of the Board of Directors' positions; members serve two-year terms.</p>
<ul>
<li>Nominations close at the June general membership meeting, where the nominating committee presents a slate; additional floor nominations are also accepted that meeting.</li>
<li>Election polls are open two consecutive weekends in July, 9&nbsp;a.m.&ndash;5&nbsp;p.m., before the July regular membership meeting.</li>
<li>Results are announced at the July general membership meeting.</li>
<li>Newly elected board members are sworn in at the August general membership meeting.</li>
</ul>
<p><strong>2026 election:</strong> results were announced at the July 21, 2026 membership meeting; new board members are sworn in at the August 18, 2026 General Membership Meeting.</p>
<p>Election Committee: Chair Tom Pike, Member Oscar Starz. Questions about running for an open position can go to the Chapter Nomination/Election Chairmen via the <a href="/contact/">contact page</a>.</p>
HTML;

$about_id = iwla_upsert_page( array(
	'post_title'   => 'About',
	'post_name'    => 'about',
	'post_content' => $about_content,
	'post_excerpt' => 'A 90-year-old member-run conservation chapter on 110 acres in Fairfax County — our history, mission, and governance.',
) );

/* ---------------- MEMBERSHIP ---------------- */
$membership_content = <<<HTML
<div class="callout">
<span class="icon">&#9989;</span>
<div><strong>2027 renewals open October 15, 2026</strong>
<p>Renew online between October 15 and December 31, 2026. Any renewal received after 12/31/2026 incurs a $40 late fee &mdash; no exceptions. Renew online, by mailed renewal form, or by dropping off payment at the membership office.</p></div>
</div>

<h2>Joining the chapter</h2>
<p>New members join in four steps:</p>
<ol>
<li><strong>Attend a 3-hour New Member Orientation class.</strong> A reservation is required through SignUpGenius &mdash; see the <a href="/calendar/">chapter calendar</a> for upcoming dates.</li>
<li><strong>Pay your initiation fee and first year's dues</strong> at the orientation class (checks, cash, or PayPal credit card accepted).</li>
<li><strong>Attend a General Membership meeting</strong> to be voted in.</li>
<li><strong>Complete 6 hours of service to the chapter</strong> &mdash; grounds or range maintenance, project support, or indoor service &mdash; to receive your permanent range badge.</li>
</ol>

<div class="fact-grid">
<div class="fact"><span class="k">Initiation fee</span><span class="v">$190, one-time</span></div>
<div class="fact"><span class="k">Individual membership</span><span class="v">$211/yr &middot; 1 range badge</span></div>
<div class="fact"><span class="k">Family membership</span><span class="v">$310.50/yr &middot; 2 range badges, both adults 18+</span></div>
</div>

<h2>What membership includes</h2>
<p>One membership gives access to every range and program on the property: Olympic-style target archery, a 4-field shotgun range, an indoor 26-lane air range, a 17-point rifle &amp; pistol range, an indoor archery range, three field archery ranges, a catch-and-release fishing pond, and campgrounds. Members may also join monthly Bullseye pistol and air pistol matches, the Bull Run Muzzle Loaders shoot, High Power rifle practice, registered ATA/NSSA shoots, JOAD archery, NoVA Sharpshooters, and the annual Women on Target clinic.</p>
<p>Range-qualified members may bring a guest up to three times a year (some ranges charge a guest fee); immediate family may be brought as guests an unlimited number of times, fee-free. Firearm ranges may only be used when a Range Safety Officer is present.</p>

<h2>Membership office</h2>
<div class="fact-grid">
<div class="fact"><span class="k">Location</span><span class="v">Chapter Field House</span></div>
<div class="fact"><span class="k">Tuesday</span><span class="v">1&ndash;4 p.m.</span></div>
<div class="fact"><span class="k">Saturday</span><span class="v">9 a.m.&ndash;1 p.m.</span></div>
<div class="fact"><span class="k">Closed</span><span class="v">Easter &amp; Christmas</span></div>
</div>
<p>Phone <a href="tel:7036314495">703-631-4495</a> during office hours (leave a message with your name and number if you miss us), or email <a href="mailto:membershipscy@arlingtonfairfax-iwla.org">membershipscy@arlingtonfairfax-iwla.org</a> &mdash; include a subject line; we respond weekly.</p>

<h2 id="faq">Membership FAQ</h2>
<details class="faq"><summary>How much is it to join?</summary><p>Dues vary with age, location, and volunteer-hour discounts. Individual membership (one range badge) is $211 per year before discounts; family membership (two range badges) is $310.50. New members also pay a one-time $190 initiation fee that covers building maintenance and grounds upkeep. Dues are your only fees &mdash; there are no range fees &mdash; but you supply your own consumables (targets, ammunition, and so on).</p></details>
<details class="faq"><summary>When is the membership year, and when are dues due?</summary><p>The membership year runs January 1 to December 31, and all dues must be paid by December 31. A late fee applies after that. For new members, dues are pro-rated semi-annually by the month you join.</p></details>
<details class="faq"><summary>When are New Member Orientations?</summary><p>Classes are usually held on the first Saturday of each month, October through June, and last about three hours. They cover the chapter's history and goals, range safety rules and procedures, and more. Reserve a seat through SignUpGenius, and bring a check or cash for your initiation fee and first year's dues (PayPal credit card payments are also accepted).</p></details>
<details class="faq"><summary>Are service hours required?</summary><p>Yes. Each new member contributes 6 hours of service to the chapter &mdash; grounds or range maintenance, project work, or indoor service such as helping at orientations, assisting the membership office, or cleaning the chapter house.</p></details>
<details class="faq"><summary>Do I have to qualify for each range?</summary><p>No. Once you earn your range badge you can use any range.</p></details>
<details class="faq"><summary>Can my family come with me?</summary><p>Range-qualified members may bring any immediate family members; all range rules still apply and the badge holder must be present. Family members cannot attend on their own, unless you purchase a second range-qualified membership: each badge holder (who must be 18 or older) can then attend alone and bring a guest. A family membership means two adults, 18 or older, living in the same household.</p></details>
<details class="faq"><summary>Can I bring guests?</summary><p>Range-qualified members may bring a guest up to three times a year (some ranges charge a guest fee). Immediate family members can be brought as guests an unlimited number of times, with no guest fee. Firearm ranges are open only when a Range Safety Officer is present.</p></details>
<details class="faq"><summary>Do you accept credit cards?</summary><p>Yes, through PayPal, but the vendors charge fees. Checks and cash are also accepted. Questions: <a href="mailto:membershipscy@arlingtonfairfax-iwla.org">membershipscy@arlingtonfairfax-iwla.org</a> or <a href="tel:7036314495">703-631-4495</a>.</p></details>

<h2>Renewing your membership</h2>
<p>Save time by renewing online each October. Renewal issues can be directed to the membership office at <a href="tel:7036314495">703-631-4495</a>.</p>
[iwla_pay key="renewal" label="Renew online"]
[iwla_documents category="forms" limit="10"]
<a class="btn btn-primary" href="/contact/">Contact the membership office</a>
HTML;

$membership_id = iwla_upsert_page( array(
	'post_title'   => 'Membership',
	'post_name'    => 'membership',
	'post_content' => $membership_content,
	'post_excerpt' => 'How to join, what it costs, and everything one membership unlocks.',
) );

/* ---------------- CONTACT ---------------- */
/* ---------------- CAMPUS MAP (child of About) ---------------- */
$campus_img = get_template_directory_uri() . '/assets/img/aerial-campus-map.jpg';
$campus_content = <<<HTML
<figure class="wp-block-image"><img src="{$campus_img}" alt="Aerial facilities map of the Arlington-Fairfax Chapter property showing the pond, ranges, and field house" loading="lazy"><figcaption>Aerial view of the chapter property. (Placeholder image from the previous site.)</figcaption></figure>

<h2>Facilities and phone numbers</h2>
<div class="table-scroll"><table>
<tr><th>Facility</th><th>Phone</th></tr>
<tr><td>Chapter Field House (membership office)</td><td><a href="tel:7036314495">703-631-4495</a></td></tr>
<tr><td>Rifle-Pistol Range</td><td><a href="tel:7036314496">703-631-4496</a></td></tr>
<tr><td>Skeet &amp; Trap Range</td><td><a href="tel:7036314497">703-631-4497</a></td></tr>
<tr><td>Sills Air Range</td><td><a href="tel:7036314818">703-631-4818</a></td></tr>
<tr><td>Field Archery Range</td><td><a href="tel:7036314498">703-631-4498</a></td></tr>
</table></div>
<p>The property also has an Olympic-style target archery field, an indoor archery range, a two-acre catch-and-release pond, campgrounds, and picnic areas with pavilions, a playground, and a playing field. Remember the <strong>10 MPH speed limit</strong>, radar enforced.</p>
<p>Address, hours, and an interactive map are on the <a href="/contact/">Contact</a> page. To reserve a pavilion, campground, or field, see <a href="/ranges/facilities-use/">Facility Use Requests</a>.</p>
HTML;

$campus_id = iwla_upsert_page( array(
	'post_title'   => 'Campus Map',
	'post_name'    => 'campus-map',
	'post_content' => $campus_content,
	'post_excerpt' => 'Where things are on the chapter property, with facility phone numbers.',
	'post_parent'  => $about_id,
	'menu_order'   => 1,
) );

$contact_content = <<<HTML
<h2>Visit the chapter</h2>
<div class="fact-grid">
<div class="fact"><span class="k">Property address</span><span class="v">14708 Mount Olive Road, Centreville, VA 20121</span></div>
<div class="fact"><span class="k">Mailing address</span><span class="v">PO Box 366, Centreville, VA 20122</span></div>
<div class="fact"><span class="k">Main phone</span><span class="v"><a href="tel:7036314495">703-631-4495</a></span></div>
</div>

<h3>Hours of operation</h3>
<ul>
<li>Outdoor recreation &amp; outdoor ranges: 8&nbsp;a.m.&ndash;9&nbsp;p.m.</li>
<li>Indoor uses &amp; indoor ranges: 8&nbsp;a.m.&ndash;12 midnight</li>
</ul>
<p>Extended hours apply for staffed, scheduled events (camping, etc). See each range's page for its specific operating days and times.</p>

<h3>Facility phone numbers</h3>
<div class="table-scroll"><table>
<tr><th>Facility</th><th>Phone</th></tr>
<tr><td>Chapter Field House</td><td><a href="tel:7036314495">703-631-4495</a></td></tr>
<tr><td>Rifle-Pistol Range</td><td><a href="tel:7036314496">703-631-4496</a></td></tr>
<tr><td>Skeet &amp; Trap Range</td><td><a href="tel:7036314497">703-631-4497</a></td></tr>
<tr><td>Sills Air Range</td><td><a href="tel:7036314818">703-631-4818</a></td></tr>
<tr><td>Field Archery Range</td><td><a href="tel:7036314498">703-631-4498</a></td></tr>
</table></div>

<h3>Directions</h3>
<div class="map-embed"><iframe src="https://maps.google.com/maps?q=14708+Mount+Olive+Road%2C+Centreville%2C+VA+20121&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="Map showing the Arlington-Fairfax Chapter property at 14708 Mount Olive Road, Centreville, VA"></iframe></div>
<p><a href="https://www.google.com/maps/search/?api=1&query=14708+Mount+Olive+Road+Centreville+VA+20121" target="_blank" rel="noopener">Open in Google Maps &rarr;</a></p>

<h2 id="officers">Officers &amp; Directors</h2>
<p>Each director oversees a chapter discipline; committee liaisons are noted on their program's page. All emails are @arlingtonfairfax-iwla.org unless noted.</p>
<div class="table-scroll"><table>
<tr><th>Role</th><th>Name</th><th>Contact</th><th>Term ends</th></tr>
<tr><td>President</td><td>Pamela Meara</td><td><a href="tel:7033627293">703-362-7293</a> &middot; <a href="mailto:Pam.Meara@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Vice-President</td><td>Brian Hickerson</td><td><a href="tel:7039265711">703-926-5711</a> &middot; <a href="mailto:Brian.Hickerson@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Secretary</td><td>Bruce Crandlemire</td><td><a href="tel:7039270090">703-927-0090</a> &middot; <a href="mailto:Bruce.Crandlemire@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Treasurer</td><td>Bob Crisman</td><td><a href="tel:7037271946">703-727-1946</a> &middot; <a href="mailto:Bob.Crisman@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Membership Chairman</td><td>Jeff Tackett</td><td><a href="tel:7036314495">703-631-4495</a> &middot; <a href="mailto:Jeff.Tackett@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Director &ndash; Air Range</td><td>Keith Kuck</td><td><a href="tel:7034058935">703-405-8935</a> &middot; <a href="mailto:Keith.Kuck@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Director &ndash; Conservation</td><td>Jack Scheible</td><td><a href="tel:7039636059">703-963-6059</a> &middot; <a href="mailto:jack.scheible@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Director &ndash; Education</td><td>John Seaberg</td><td><a href="tel:7038250685">703-825-0685</a> &middot; <a href="mailto:John.Seaberg@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Director &ndash; Field Archery</td><td>Dick Riemer</td><td><a href="tel:7035438585">703-543-8585</a> &middot; <a href="mailto:Dick.Riemer@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Director &ndash; Rifle/Pistol</td><td>Chip Chidester</td><td><a href="tel:7039667369">703-966-7369</a> &middot; <a href="mailto:Chip.Chidester@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Director &ndash; Skeet &amp; Trap</td><td>Bob Brino</td><td><a href="tel:7033684934">703-368-4934</a> &middot; <a href="mailto:Bob.Brino@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Director &ndash; Target Archery</td><td>Jeff DelVecchio</td><td><a href="tel:7578137545">757-813-7545</a> &middot; <a href="mailto:Jeff.DelVecchio@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Director &ndash; Youth Activities</td><td>Joe Turner</td><td><a href="tel:7036284808">703-628-4808</a> &middot; <a href="mailto:Joe.Turner@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Director-at-Large</td><td>Benn Crandall</td><td><a href="mailto:Benn.Crandall@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Director-at-Large</td><td>Mark Gauntner</td><td><a href="tel:7039439946">703-943-9946</a> &middot; <a href="mailto:Mark.Gauntner@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Director-at-Large</td><td>John Lindamood</td><td><a href="tel:7032013667">703-201-3667</a> &middot; <a href="mailto:John.Lindamood@arlingtonfairfax-iwla.org">email</a></td><td>2028</td></tr>
<tr><td>Director-at-Large</td><td>Vacant</td><td>&mdash;</td><td>2028</td></tr>
<tr><td>Director-at-Large</td><td>Tom Pike</td><td><a href="tel:7038020740">703-802-0740</a> &middot; <a href="mailto:Tom.Pike@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
<tr><td>Director-at-Large</td><td>Oscar Starz</td><td><a href="tel:7033218626">703-321-8626</a> &middot; <a href="mailto:Oscar.Starz@arlingtonfairfax-iwla.org">email</a></td><td>2027</td></tr>
</table></div>

<h2 id="contacts">Other chapter contacts</h2>
<p>Committee chairs and program contacts. Roles marked vacant are open &mdash; if you would like to help, write to <a href="mailto:ARLFXIWLA@gmail.com">ARLFXIWLA@gmail.com</a>.</p>
<div class="table-scroll"><table>
<tr><th>Role</th><th>Name</th><th>Contact</th></tr>
<tr><td>Adopt-A-Highway</td><td>Steve Rumble</td><td><a href="tel:7033787176">703-378-7176</a> &middot; <a href="mailto:Steve.Rumble@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Angler (fishing) Club</td><td>Joseph Arevalo</td><td><a href="mailto:joseph.arevalo@gmail.com">email</a></td></tr>
<tr><td>Awards &amp; Grants Chair</td><td>Scott Meyer</td><td><a href="tel:7039992581">703-999-2581</a> &middot; <a href="mailto:arlfxawardsgrants@gmail.com">email</a></td></tr>
<tr><td>Buildings &amp; Grounds Chair</td><td>Brian Hickerson</td><td><a href="tel:7039265711">703-926-5711</a> &middot; <a href="mailto:Brian.Hickerson@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Bull Run Muzzle Loaders</td><td>Art Twichell</td><td><a href="tel:5712250989">571-225-0989</a> &middot; <a href="mailto:Art.Twichell@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Bullseye Pistol League</td><td>Rich Sirois</td><td><a href="tel:4013658950">401-365-8950</a> &middot; <a href="mailto:rich.sirois@gmail.com">email</a></td></tr>
<tr><td>By-Laws/Policy Chair</td><td>Mark Gauntner</td><td><a href="tel:7039439946">703-943-9946</a> &middot; <a href="mailto:Mark.Gauntner@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Calendar</td><td>Bill Clayton</td><td><a href="tel:7039560667">703-956-0667</a> &middot; <a href="mailto:arlfxcalendar@gmail.com">email</a></td></tr>
<tr><td>Chapter Annual Picnic</td><td>Bob Brino</td><td><a href="tel:7033684934">703-368-4934</a> &middot; <a href="mailto:Bob.Brino@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Chapter Caretaker</td><td>Brian Martin</td><td><a href="tel:7036256161">703-625-6161</a> &middot; <a href="mailto:Brian.Martin@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Chapter National Director</td><td>Pamela Meara</td><td><a href="tel:7033627293">703-362-7293</a> &middot; <a href="mailto:pam.meara@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Children/Adults with Disabilities Picnic</td><td>John Hsu</td><td><a href="tel:5712333501">571-233-3501</a> &middot; <a href="mailto:John.Hsu@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Christmas Party for Disadvantaged Children</td><td>Shawna Wood</td><td><a href="tel:7038305091">703-830-5091</a> &middot; <a href="mailto:Stwood1966@gmail.com">email</a></td></tr>
<tr><td>Communication Chair</td><td>Pamela Meara</td><td><a href="tel:7033627293">703-362-7293</a> &middot; <a href="mailto:pam.meara@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Conservation Activities</td><td>Vacant</td><td><a href="mailto:Arlfxiwla@gmail.com">email</a></td></tr>
<tr><td>Cub Run Archers</td><td>Mark Gauntner</td><td><a href="tel:7039439946">703-943-9946</a> &middot; <a href="mailto:Gauntneriwla201@gmail.com">email</a></td></tr>
<tr><td>DWR Hunter Education</td><td>Carl Hampton</td><td><a href="tel:7034089434">703-408-9434</a> &middot; <a href="mailto:champton3@cox.net">email</a></td></tr>
<tr><td>E-Blast (Communication)</td><td>Pamela Meara</td><td><a href="tel:7033627293">703-362-7293</a> &middot; <a href="mailto:ARLFXIWLA@gmail.com">email</a></td></tr>
<tr><td>Education &amp; Training Facility Trust</td><td>Trustees</td><td><a href="tel:7033627293">703-362-7293</a> &middot; <a href="mailto:etft.arlfx@gmail.com">email</a></td></tr>
<tr><td>Election/Nomination Chair</td><td>Tom Pike</td><td><a href="tel:5713084159">571-308-4159</a> &middot; <a href="mailto:Tom.Pike@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Facility Use Requests</td><td>Bill Clayton</td><td><a href="tel:7039560667">703-956-0667</a> &middot; <a href="mailto:Bill.Clayton@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Historian</td><td>Vacant</td><td><a href="mailto:ARLFXIWLA@gmail.com">email</a></td></tr>
<tr><td>Knife Club</td><td>Matt Michaelson</td><td><a href="tel:5712456075">571-245-6075</a> &middot; <a href="mailto:mtmichaelson@hotmail.com">email</a></td></tr>
<tr><td>New Member Orientations</td><td>Vacant</td><td><a href="tel:7036314495">703-631-4495</a> &middot; <a href="mailto:ARLFXIWLA@gmail.com">email</a></td></tr>
<tr><td>Newsletter Editor</td><td>Pamela Meara</td><td><a href="tel:7033627293">703-362-7293</a> &middot; <a href="mailto:newsletter@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>NoVA Sharpshooters</td><td>&mdash;</td><td><a href="mailto:novasharpshootersiwla@gmail.com">email</a></td></tr>
<tr><td>Office Membership Administration</td><td>Membership</td><td><a href="tel:7036314495">703-631-4495</a> &middot; <a href="mailto:membershipscy@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Open Firearm Matches</td><td>David Park</td><td><a href="tel:7033049416">703-304-9416</a> &middot; <a href="mailto:davidskpark@gmail.com">email</a></td></tr>
<tr><td>Public Relations Chair</td><td>Vacant</td><td><a href="mailto:ARLFXIWLA@gmail.com">email</a></td></tr>
<tr><td>Save Our Streams (SOS)</td><td>Vacant</td><td><a href="tel:7036314495">703-631-4495</a> &middot; <a href="mailto:ARLFXSOS@gmail.com">email</a></td></tr>
<tr><td>Scholarship Chair</td><td>Sean Gagnon</td><td><a href="tel:7036314495">703-631-4495</a> &middot; <a href="mailto:Sean.Gagnon@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Scouting Activities Chair</td><td>Tom Pike</td><td><a href="tel:7038020740">703-802-0740</a> &middot; <a href="mailto:Tom.Pike@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Security &amp; Gate Chair</td><td>Don Early</td><td><a href="tel:7033283431">703-328-3431</a> &middot; <a href="mailto:Don.Early@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Service Rifle Matches</td><td>Paul Kent</td><td><a href="mailto:Paul_Kent_II@protonmail.com">email</a></td></tr>
<tr><td>SignUpGenius</td><td>Benn Crandall</td><td><a href="tel:7036314495">703-631-4495</a> &middot; <a href="mailto:Benn.Crandall@arlingtonfairfax-iwla.org">email</a></td></tr>
<tr><td>Skeet Shoot Chair</td><td>Ashly Palles</td><td><a href="tel:7034007001">703-400-7001</a> &middot; <a href="mailto:IWLASkeet@yahoo.com">email</a></td></tr>
<tr><td>Trap Shoot Chair</td><td>Bob Brino</td><td><a href="tel:7033684934">703-368-4934</a> &middot; <a href="mailto:Bob.Brino@arlingtonfairfax-iwla.org">email</a></td></tr>
</table></div>
HTML;

$contact_id = iwla_upsert_page( array(
	'post_title'   => 'Contact',
	'post_name'    => 'contact',
	'post_content' => $contact_content,
	'post_excerpt' => 'Directions, hours, facility phone numbers, and the full Officers & Directors list.',
) );

/* ---------------- RANGES (parent + children) ---------------- */
$ranges_content = <<<HTML
<div class="callout">
<span class="icon">&#9888;&#65039;</span>
<div><strong>Range badge required on every range</strong>
<p>All members must display their range badge whenever they access or use any chapter range, archery or firearm. Firearm ranges may only be used when a Range Safety Officer is on duty.</p></div>
</div>
<p>The chapter's five member ranges sit on 110 acres in Centreville. All are closed Easter and Christmas, and all firearm ranges are closed when no Range Safety Officer is present. Choose a range below for its hours, rules, and leagues.</p>
<div class="grid grid-3">
<div class="card"><h3><a href="/ranges/rifle-pistol/">Rifle &amp; Pistol</a></h3><p>17-position outdoor range, target placements at 25&ndash;100 yards, plus Bullseye pistol leagues.</p></div>
<div class="card"><h3><a href="/ranges/skeet-trap/">Skeet &amp; Trap</a></h3><p>4-field shotgun range hosting the Winter League and the Crush'n Clays charity shoot.</p></div>
<div class="card"><h3><a href="/ranges/archery/">Archery</a></h3><p>Target, field, and indoor air archery, plus Cub Run Archers and JOAD training.</p></div>
<div class="card"><h3><a href="/ranges/air-range/">Air Range</a></h3><p>26-lane indoor range: school and junior teams, open practice, and adaptive shooting.</p></div>
<div class="card"><h3><a href="/ranges/education-training/">Education &amp; Training</a></h3><p>NRA courses, coach schools, and Archery 101/201 &mdash; schedule and registration.</p></div>
<div class="card"><h3><a href="/ranges/facilities-use/">Facility Use Requests</a></h3><p>Ground rules for members, nonprofits, and youth groups using chapter property.</p></div>
</div>
HTML;

$ranges_id = iwla_upsert_page( array(
	'post_title'   => 'Ranges & Training',
	'post_name'    => 'ranges',
	'post_content' => $ranges_content,
	'post_excerpt' => 'Five member ranges on 110 acres — rifle & pistol, skeet & trap, and archery — plus facility use rules.',
) );

$rifle_content = <<<HTML
<div class="fact-grid">
<div class="fact"><span class="k">Director</span><span class="v">Chip Chidester</span></div>
<div class="fact"><span class="k">Field house phone</span><span class="v"><a href="tel:7036314496">703-631-4496</a></span></div>
<div class="fact"><span class="k">Range size</span><span class="v">17 shooting positions, targets at 25/50/75/100 yd</span></div>
</div>

<h2>Hours of operation</h2>
<p><em>RSO availability permitting &mdash; always check the <a href="/calendar/">online calendar</a>.</em></p>
<div class="table-scroll"><table>
<tr><th>Days</th><th>Regular season</th><th>Winter (Nov&ndash;Feb)</th></tr>
<tr><td>Weekdays</td><td>8 a.m.&ndash;5 p.m.</td><td>9 a.m.&ndash;4 p.m.</td></tr>
<tr><td>Saturday</td><td>8 a.m.&ndash;5 p.m.</td><td>9 a.m.&ndash;4 p.m.</td></tr>
<tr><td>Sunday</td><td>12&ndash;5 p.m.</td><td>12&ndash;4 p.m.</td></tr>
</table></div>
<p>Closed Easter &amp; Christmas. If Fairfax County schools close for weather, hours may vary. Short Range Day is currently suspended until further notice (as of August 21, 2026).</p>

<h2>On the range</h2>
<ul>
<li>Wear your range qualification badge at all times.</li>
<li>No steel-core ammunition &mdash; if it sticks to the provided magnet, it isn't allowed.</li>
<li>Recycle spent brass in the brass bucket (no steel, aluminum, nickel-plated cases, or shotgun shells); aluminum cans go in the separate firing-line bin.</li>
<li>No targets may be posted between the firing line and 25 yards.</li>
</ul>

<h2>Bullseye Pistol Leagues</h2>
<p>Two leagues run at the Rifle/Pistol range &mdash; newcomers are welcome and the matches are relaxed and social:</p>
<ul>
<li><strong>Rimfire League:</strong> usually the 1st Sunday, March&ndash;August.</li>
<li><strong>Centerfire League:</strong> usually the 1st Sunday, September&ndash;December.</li>
</ul>
<p>Contact Rich Sirois at <a href="mailto:rich.sirois@gmail.com">rich.sirois@gmail.com</a> or <a href="tel:4013658950">401-365-8950</a> for current flyers and schedule.</p>

<h2>Matches and clubs on the range</h2>
<ul>
<li><strong>Service Rifle matches:</strong> 2nd Thursday of each month, April through October. First relay starts at 4:00 p.m., second at 5:30 p.m.; arrive after a relay has started and you can't join it. Contact Paul Kent at <a href="mailto:Paul_Kent_II@protonmail.com">Paul_Kent_II@protonmail.com</a>.</li>
<li><strong>Bullseye matches:</strong> usually the 1st Sunday morning of each month (see the leagues above).</li>
<li><strong>Open matches:</strong> 3rd Monday of each month. Contact David Park at <a href="tel:7033049416">703-304-9416</a> or <a href="mailto:davidskpark@gmail.com">davidskpark@gmail.com</a>.</li>
<li><strong>Bull Run Muzzle Loaders (BRML):</strong> 3rd Sunday of each month, 9 a.m.&ndash;2 p.m. (see below).</li>
</ul>
<p>Snacks and sodas are available for purchase.</p>

<h2>Bull Run Muzzle Loaders</h2>
<p>BRML is a National Muzzle Loading Rifle Association (NMLRA) charter club and a member of its 1 in 1,000 Endowment program. It began in 1987 as an informal group of ten enthusiasts shooting on Sunday mornings, and became an NMLRA charter club in June 1988. Shoots are held at the chapter's rifle/pistol range &mdash; minutes from the site of the First Battle of Bull Run, which gives the club its name &mdash; on the third Sunday of every month, 9 a.m. to 2 p.m.</p>
<p>Buckskinners, target shooters, novices, and the curious are all welcome. Cap-locks, flintlocks, underhammers, in-lines, rifled barrels and smoothbores are allowed in competition; the monthly shoots also offer a pistol competition, and only iron sights are permitted in competition. Membership isn't required to shoot. If you don't own a muzzle loader, the club has rifles and all the makings to loan, along with instruction, load development, troubleshooting, and sighting-in help. During its shoots the club has exclusive use of the range for muzzle loading firearms.</p>
<p>More at <a href="http://bullrunmuzzleloaders.com/" target="_blank" rel="noopener">bullrunmuzzleloaders.com</a>. Contact Art Twichell at <a href="mailto:Art.Twichell@arlingtonfairfax-iwla.org">Art.Twichell@arlingtonfairfax-iwla.org</a> or <a href="tel:5712250989">571-225-0989</a>.</p>

<p><strong>Range rules:</strong> the full rules are part of the <a href="/about/#governance">chapter bylaws booklet</a> (issued/revised November 19, 2024); direct questions to the Director above or the <a href="/contact/">Officers &amp; Directors</a> page.</p>
HTML;

$rifle_id = iwla_upsert_page( array(
	'post_title'   => 'Rifle & Pistol Range',
	'post_name'    => 'rifle-pistol',
	'post_content' => $rifle_content,
	'post_excerpt' => 'Hours, on-range rules, and the chapter\'s Bullseye Pistol leagues.',
	'post_parent'  => $ranges_id,
	'menu_order'   => 1,
) );

$skeet_content = <<<HTML
<div class="fact-grid">
<div class="fact"><span class="k">Director</span><span class="v">Bob Brino</span></div>
<div class="fact"><span class="k">Field house phone</span><span class="v"><a href="tel:7036314497">703-631-4497</a></span></div>
<div class="fact"><span class="k">Fields</span><span class="v">4 fields &mdash; 1 trap-only, 3 skeet or trap</span></div>
</div>

<h2>Hours of operation</h2>
<div class="table-scroll"><table>
<tr><th>Monday</th><td>8 a.m.&ndash;2 p.m.</td></tr>
<tr><th>Wednesday</th><td>8 a.m.&ndash;2 p.m.</td></tr>
<tr><th>Friday</th><td>8 a.m.&ndash;2 p.m.</td></tr>
<tr><th>Saturday</th><td>8 a.m.&ndash;5 p.m.</td></tr>
<tr><th>Sunday</th><td>12&ndash;5 p.m.</td></tr>
</table></div>
<p>Closed Easter &amp; Christmas, and any day without a Range Safety Officer present.</p>

<h2>Leagues &amp; events</h2>
<ul>
<li><strong>'Bucky' Sills Winter Skeet &amp; Trap League</strong> &mdash; begins the first Sunday after New Year's Day and runs 13 weeks. Started in the mid-1980s, it now fields 28 six-shooter teams (168 members) across six 50-target rounds of skeet and trap.</li>
<li><strong>28th Annual Crush'n Clays</strong> &mdash; VSSA charity shoot benefiting St. Jude Children's Research Hospital, co-sponsored with the Virginia Shooting Sports Association. Save the date: <strong>Saturday, June 12, 2027.</strong></li>
<li><strong>NRA Women on Target Clinic</strong> &mdash; see <a href="/youth/">Youth Programs</a> and the <a href="/calendar/">calendar</a> for the next date.</li>
</ul>
<h2 id="winter-league">Winter Skeet &amp; Trap League</h2>
<p>The league began in the mid-1980s and is one of the chapter's longest-running events. It now fields 28 teams of six shooters &mdash; 168 members, about 95% of them chapter members. It is a family-oriented recreational league: the rules encourage friendly competition and let shooters of every skill level compete for awards.</p>
<ul>
<li><strong>When:</strong> Sundays, beginning the first week of January. All chapter shotgun ranges are closed to open shooting on Sundays during the league season, and a designated range safety officer is always present.</li>
<li><strong>Format:</strong> each team shoots six skeet and six trap 50-target matches (two rounds), 600 targets in all. Any gauge legal for the shotgun sports may be used. Competition generally follows National Skeet Shooting Association and American Trapshooting Association rules, and all shooting follows the chapter's range procedures.</li>
<li><strong>Scoring:</strong> each shooter's skeet and trap scores are handicapped separately and updated weekly. A team's match score is the sum of its four best handicapped scores out of six, each round, accumulated over the whole season.</li>
<li><strong>Prizes:</strong> the top ten teams, plus individual prizes for high overall average (skeet and trap combined), high and runner-up skeet average, high and runner-up trap average, and most improved overall average.</li>
<li><strong>Signing up:</strong> first-come, first-served, with priority for teams returning from the previous season; substitutes are always needed to fill in for regular shooters. Members and their families make up most teams, and others are welcome.</li>
</ul>
<p>League contact: John Seaberg, <a href="mailto:jseaberg@cox.net">jseaberg@cox.net</a>.</p>

<p>Questions: Skeet &amp; Trap Director Bob Brino, <a href="tel:7033684934">703-368-4934</a> or <a href="mailto:Bob.Brino@arlingtonfairfax-iwla.org">Bob.Brino@arlingtonfairfax-iwla.org</a>.</p>
<p><strong>Range rules:</strong> the full rules are part of the <a href="/about/#governance">chapter bylaws booklet</a> (issued/revised November 19, 2024); direct questions to the Director above or the <a href="/contact/">Officers &amp; Directors</a> page.</p>
HTML;

$skeet_id = iwla_upsert_page( array(
	'post_title'   => 'Skeet & Trap Range',
	'post_name'    => 'skeet-trap',
	'post_content' => $skeet_content,
	'post_excerpt' => 'Hours, the Winter League, and the 28th Annual Crush\'n Clays charity shoot.',
	'post_parent'  => $ranges_id,
	'menu_order'   => 2,
) );

$archery_content = <<<HTML
<p>The chapter offers target archery on a 90-meter outdoor field and an indoor range, field archery on three outdoor ranges, and the Cub Run Archers club. Choose a program below.</p>
<div class="grid grid-3">
<div class="card"><h3><a href="/ranges/archery/target-archery/">Target Archery &amp; Tournaments</a></h3><p>Olympic-style target range, JOAD and the Adult Archery Program, and STAR FITA tournaments.</p></div>
<div class="card"><h3><a href="/ranges/archery/field-archery/">Field Archery</a></h3><p>Lighted main range, two 14-point walk-through 3D ranges, crossbow sighting-in, and an indoor range.</p></div>
<div class="card"><h3><a href="/ranges/archery/cub-run-archers/">Cub Run Archers</a></h3><p>The chapter's field archery club: meetings, shoots, dues, and useful links.</p></div>
</div>
<p>The indoor air gun range is covered on its own page: <a href="/ranges/air-range/">Air Range</a>.</p>

<h2>Archery 101 / 201 &amp; instructor training</h2>
<p>Beginner classes (Archery 101) and 5-week 201 sessions run periodically for new archers &mdash; see <a href="/ranges/education-training/">Education &amp; Training</a> for schedules and payment. The chapter also runs U.S. Archery Level 1 and Level 2 Instructor Training: 8-hour courses covering the National Training System steps of shooting, equipment setup, and (Level 2) the coaching methods needed to lead JOAD, AAP, or collegiate programs. No prior experience is required. Contact the Target Archery Director for scheduling.</p>
HTML;

$archery_id = iwla_upsert_page( array(
	'post_title'   => 'Archery',
	'post_name'    => 'archery',
	'post_content' => $archery_content,
	'post_excerpt' => 'Target, field, and air archery — hours, tournaments, Cub Run Archers, and instructor training.',
	'post_parent'  => $ranges_id,
	'menu_order'   => 3,
) );

$target_content = <<<HTML
<div class="fact-grid">
<div class="fact"><span class="k">Director</span><span class="v">Jeff DelVecchio</span></div>
<div class="fact"><span class="k">Questions</span><span class="v">Ryan Johnson, <a href="mailto:Ryan.Johnson@arlingtonfairfax-iwla.org">Ryan.Johnson@arlingtonfairfax-iwla.org</a></span></div>
<div class="fact"><span class="k">Outdoor range hours</span><span class="v">8 a.m.&ndash;9 p.m. daily, incl. Easter &amp; Christmas</span></div>
</div>
<p>The 90-meter outdoor target field sits next to the field house, and the chapter shoots at its indoor range during the winter months. Target archery is provided for archers who enjoy the sport recreationally and in competition.</p>

<h2>Programs and open shooting</h2>
<ul>
<li><strong>Open shooting and instruction:</strong> Thursday evenings, 7&ndash;9 p.m., at the indoor or outdoor range.</li>
<li><strong>JOAD</strong> (Junior Olympic Archery Development, ages 8&ndash;18): Sundays, 3&ndash;5 p.m.</li>
<li><strong>Adult Archery Program (AAP):</strong> Wednesday evenings, 7&ndash;9 p.m.</li>
</ul>
<p>JOAD and AAP together are the Competition Archery Team, training youth and adults in Olympic-style archery in 12-week sessions. The group includes several U.S. Archery Level 1 and 2 certified instructors and Level 3 coaches. Dates for classes are in the newsletter and on the <a href="/calendar/">chapter calendar</a>; see also <a href="/youth/">Youth Programs</a>.</p>

<h2>STAR FITA tournaments</h2>
<p>A STAR FITA tournament is one where national records can be set and recognized by U.S. Archery. The chapter holds several each year:</p>
<ul>
<li><strong>Indoor</strong> (18 meters; recurve, compound, or barebow): a two-day Fall tournament on a weekend in November and a two-day Winter tournament in February or March. Each draws nearly a hundred archers from Virginia and surrounding states.</li>
<li><strong>Outdoor</strong> (up to 90 meters, 11 lanes): in May or June, for all ages and bow types.</li>
</ul>
<p><strong>Registration:</strong> each announced tournament has a registration form and a waiver, which you mail to the registrar named on the form; you get an email confirming receipt and your shooting date and time. Fees are set per tournament &mdash; ask the Target Archery Director. Results and updated range records are posted after each event.</p>
HTML;

$target_id = iwla_upsert_page( array(
	'post_title'   => 'Target Archery & Tournaments',
	'post_name'    => 'target-archery',
	'post_content' => $target_content,
	'post_excerpt' => 'Outdoor and indoor target ranges, JOAD, the Adult Archery Program, and STAR FITA tournaments.',
	'post_parent'  => $archery_id,
	'menu_order'   => 1,
) );

$field_content = <<<HTML
<div class="fact-grid">
<div class="fact"><span class="k">Director</span><span class="v">Dick Riemer</span></div>
<div class="fact"><span class="k">Field house phone</span><span class="v"><a href="tel:7036314498">703-631-4498</a></span></div>
<div class="fact"><span class="k">Indoor range</span><span class="v">Mon&ndash;Sun, 8 a.m.&ndash;midnight (open when a card-carrying member is at the clubhouse)</span></div>
<div class="fact"><span class="k">Outdoor range</span><span class="v">8 a.m.&ndash;9 p.m. daily, incl. Easter &amp; Christmas</span></div>
</div>
<h2>The ranges</h2>
<ul>
<li>Main outdoor range with targets from 5 to 60 yards. It is lighted &mdash; the switches are on the light pole behind the firing line in the center of the range. The crossbow station on the left side is the only place crossbows may be shot from for sighting-in.</li>
<li>Two 14-point walk-through ranges with 3D and field targets out to 80 yards (28 targets in all).</li>
<li>Two elevated tree stands (a safety harness is required).</li>
<li>Indoor range: 11 lanes at 20 yards.</li>
</ul>
<p>Field archery follows the same <a href="/about/#governance">chapter bylaws</a> as the other ranges. Training, including Archery 101 and 201, is on the <a href="/ranges/education-training/">Education &amp; Training</a> page. The club that organizes field shoots is <a href="/ranges/archery/cub-run-archers/">Cub Run Archers</a>.</p>
HTML;

$field_id = iwla_upsert_page( array(
	'post_title'   => 'Field Archery',
	'post_name'    => 'field-archery',
	'post_content' => $field_content,
	'post_excerpt' => 'Lighted main range, 3D walk-through ranges, tree stands, crossbow sighting-in, and an indoor range.',
	'post_parent'  => $archery_id,
	'menu_order'   => 2,
) );

$cra_content = <<<HTML
<p>The AR-FX IWLA Cub Run Archers (CRA) club is authorized by the chapter to further the sport of archery and to provide facilities for its members' enjoyment. The field archery facilities are built to National Field Archery Association (NFAA) standards, and CRA is a chartered member of the Virginia Field Archery Association and the Virginia Bowhunters Association.</p>
<div class="fact-grid">
<div class="fact"><span class="k">President</span><span class="v">Mark Gauntner, <a href="mailto:Gauntneriwla201@gmail.com">Gauntneriwla201@gmail.com</a></span></div>
<div class="fact"><span class="k">Meetings</span><span class="v">First Sunday of each month, 1&ndash;3 p.m., Field Archery field house</span></div>
</div>
<p>Check the <a href="/calendar/">chapter calendar</a> for schedule changes. Find the club on <a href="http://www.facebook.com/cubrunarchers.org" target="_blank" rel="noopener">Facebook</a> and at <a href="http://www.cubrunarchers.org/index.html" target="_blank" rel="noopener">cubrunarchers.org</a>.</p>

<h2>Chapter archery shoots</h2>
<p>CRA runs the chapter's annual field archery shoots &mdash; the Spring Fling (early May), Summer Sizzler (late June), and Buck Buster (August). Exact dates are on the calendar.</p>

<h2>Dues</h2>
<div class="table-scroll"><table>
<tr><th>2026 membership</th><th>Dues</th></tr>
<tr><td>Cub Run Archers only</td><td>$22.00</td></tr>
<tr><td>CRA &amp; VBA, individual</td><td>$44.00</td></tr>
<tr><td>CRA &amp; VBA, adult with spouse</td><td>$52.00</td></tr>
<tr><td>CRA &amp; VBA, family (maximum)</td><td>$54.00</td></tr>
</table></div>
<p>Youth and adult-with-youth rates: ask CRA. Dues can be paid by check, cash, or online with PayPal (PayPal adds a $2 fee). Contact the CRA president for the current renewal form.</p>

<h2>Volunteer as a range officer</h2>
<p>Archery Range Officers sign up for range times through <a href="https://www.signupgenius.com/index.cfm?go=c.SignUpSearch&amp;eid=0AC7C0DFF5CAFE65&amp;cs=09B2BA" target="_blank" rel="noopener">SignUpGenius</a> (choose the Archery RSO sign-up).</p>

<h2>Useful archery links</h2>
<ul>
<li><a href="https://www.lancasterarchery.com/" target="_blank" rel="noopener">Lancaster Archery Supply</a> &middot; <a href="http://hoffmanarchery.com/" target="_blank" rel="noopener">Hoffman Archery</a></li>
<li><a href="http://www.vbarchers.com/" target="_blank" rel="noopener">Virginia Bowhunters Association</a> &middot; <a href="https://www.dgif.virginia.gov/" target="_blank" rel="noopener">Virginia Department of Wildlife Resources</a></li>
<li><a href="https://www.register-ed.com/programs/virginia/66-virginia-bowhunter-education-course-ibep" target="_blank" rel="noopener">Virginia Bowhunter Education Course (IBEP)</a></li>
<li>How to: <a href="https://www.archery360.com/2015/03/07/archery-for-beginners-bow-basics-and-how-to-shoot/" target="_blank" rel="noopener">Archery for beginners</a>, <a href="https://www.youtube.com/watch?v=bPoBm7FzMXY" target="_blank" rel="noopener">shooting a compound bow</a>, <a href="https://www.youtube.com/watch?v=NonjWwC9O7A" target="_blank" rel="noopener">using a bow press</a></li>
<li><a href="https://www.archery360.com/2014/12/03/10-archery-apps-for-archers-and-coaches/" target="_blank" rel="noopener">10 archery apps</a> &middot; <a href="https://www.r2sports.com/archery-software.asp" target="_blank" rel="noopener">R2 Sports archery software</a> &middot; <a href="https://www.bowhunting.com/blog/2017/05/06/asa-vs-ibo-3d-competition/" target="_blank" rel="noopener">ASA vs IBO 3D competition</a></li>
</ul>
HTML;

$cra_id = iwla_upsert_page( array(
	'post_title'   => 'Cub Run Archers',
	'post_name'    => 'cub-run-archers',
	'post_content' => $cra_content,
	'post_excerpt' => 'The chapter\'s field archery club: meetings, shoots, dues, and useful links.',
	'post_parent'  => $archery_id,
	'menu_order'   => 3,
) );

$facuse_content = <<<HTML
<p>The chapter is not a commercial facility, but does allow use of its property by nonprofits, youth groups, and members.</p>
<div class="callout callout-danger">
<span class="icon">&#128663;</span>
<div><strong>Speed limit: 10 MPH, radar enforced</strong><p>Per chapter ground rules and posted signs, to protect members, guests, and wildlife.</p></div>
</div>
<h2>Ground rules for facility use</h2>
<ul>
<li>Do not park or drive on the athletic field.</li>
<li>Take all trash with you, or use the appropriate trash receptacle &mdash; don't leave trash in campgrounds, pavilions, or other chapter facilities.</li>
<li>Build fires only in existing fire pits; burn only wood, charcoal, or kindling (no cans, bottles, or food waste).</li>
<li>Don't throw rocks on pavilion roofs, tear down signs, dig holes, or otherwise damage chapter property.</li>
<li>Shooting is prohibited anywhere on chapter grounds except the designated ranges.</li>
<li>Leave the area cleaner than you found it.</li>
<li>No child or group of children may be left unsupervised.</li>
<li>Firewood near campsites 1 &amp; 2 is sometimes available for campground fire pits; otherwise bring your own. Do not take stacked/split wood that is for sale near the large pavilion.</li>
</ul>
<p><strong>Pets:</strong> animals brought to the property must be on a leash at all times. No animals are allowed in buildings except service dogs.</p>
<p><strong>Outhouses:</strong> they use septic tanks &mdash; never put trash (plastic bottles, bags, etc.) in an outhouse. Clogged tanks cost the chapter money to clear, and groups may be charged.</p>
<p>If you see any issue or damage on the property, please email <a href="mailto:arlfxiwla@gmail.com">arlfxiwla@gmail.com</a> right away.</p>

<h2>How to request facility use</h2>
<p>Check the <a href="/calendar/">chapter calendar</a> first to see whether the facility you want is already reserved. Requests go by email to the <a href="mailto:arlfxcalendar@gmail.com">chapter calendar volunteer</a>.</p>

<h3>Chapter family requests</h3>
<p>For a group no larger than your immediate family (living in the same household). No Group Activities Permit is needed. Email your request for review and approval; once approved it is added to the chapter calendar. Include:</p>
<ul>
<li>Your name (first and last) and ARL-FX chapter membership number</li>
<li>The facility or facilities requested and the number of immediate family members</li>
<li>Dates, and confirmation that you checked the online calendar for availability</li>
</ul>

<h3>Larger groups, nonprofits, and youth groups</h3>
<p>For chapter members hosting a group larger than their household, and for non-profit and youth groups:</p>
<ul>
<li>Every request is presented to the Board of Directors, which meets the first Tuesday of each month at 7:30&nbsp;p.m. at the Chapter Field House.</li>
<li>Email your request with the dates, times, facilities, and number of participants.</li>
<li><strong>Requests to use a program facility (range) must be received 10 days before the Board meeting.</strong> Scout groups must request 90&nbsp;days in advance.</li>
<li>All forms and the designated Director's signature must be completed before the request goes to the Board.</li>
<li>Each participant must complete the Liability Release / Hold Harmless form and bring it to every range they use.</li>
</ul>
<h3>Forms</h3>
[iwla_documents category="facility-forms" limit="10"]
<p>Questions: <a href="/contact/">contact the chapter office</a>.</p>
HTML;

$facuse_id = iwla_upsert_page( array(
	'post_title'   => 'Facility Use Requests',
	'post_name'    => 'facilities-use',
	'post_content' => $facuse_content,
	'post_excerpt' => 'Ground rules for members, nonprofits, and youth groups using chapter property.',
	'post_parent'  => $ranges_id,
	'menu_order'   => 6,
) );

/* ---------------- CALENDAR ---------------- */
$calendar_content = <<<HTML
<p>Always check the calendar before you drive out &mdash; it is the best source for range hours, events, and closures. Use the facility list on the left to highlight a range's events.</p>
[iwla_calendar]
<p>Questions about the calendar: <a href="mailto:arlfxcalendar@gmail.com">arlfxcalendar@gmail.com</a>. To reserve a facility, see <a href="/ranges/facilities-use/">Facility Use Requests</a>.</p>
HTML;

$calendar_id = iwla_upsert_page( array(
	'post_title'   => 'Calendar',
	'post_name'    => 'calendar',
	'post_content' => $calendar_content,
	'post_excerpt' => 'Range hours, leagues, meetings, events, and closures.',
) );

/* ---------------- AIR RANGE ---------------- */
$air_content = <<<HTML
<div class="fact-grid">
<div class="fact"><span class="k">Director</span><span class="v">Keith Kuck</span></div>
<div class="fact"><span class="k">Range phone</span><span class="v"><a href="tel:7036314818">703-631-4818</a></span></div>
<div class="fact"><span class="k">Range</span><span class="v">26-position indoor air gun range</span></div>
</div>

<h2>About the range</h2>
<p>The Sills Air Range began in 1994 as a public youth shooting outreach program &mdash; a seven-lane range in a three-stall garage. A 26-lane expansion, started in 2014 and finished in 2015 in time for the World Police and Fire Games held in Fairfax County, made it the home range for seven high school air rifle teams and the chapter's junior programs.</p>
<p>The range has its own website with practice schedules and details: <a href="http://afc-iwla-sillsairrange.org/" target="_blank" rel="noopener">afc-iwla-sillsairrange.org</a>. Hours and open practice windows are also on the <a href="/calendar/">chapter calendar</a> (facility code <strong>AR</strong>).</p>

<h2>Who uses the range</h2>
<ul>
<li><strong>High school air rifle teams</strong> in the Potomac High School Rifle League &mdash; Centreville, Fairfax, Lake Braddock, Robinson, West Springfield, and Woodson high schools, plus the independent Mavericks.</li>
<li><strong>NoVA Sharpshooters</strong> junior pistol and Paralympic junior air rifle programs (see <a href="/youth/">Youth Programs</a>). Participants pay the Sills Air Range consumables fee and join the Junior Chapter.</li>
<li><strong>Open practice</strong> and adult air pistol league sessions, and adaptive shooting sessions &mdash; times are on the calendar.</li>
<li>Periodic hosted matches, such as the Wendel Thompson Memorial Precision Air Rifle/Pistol Match co-sponsored by the Junior Chapter.</li>
</ul>

<h2>Rules and questions</h2>
<p><strong>Range rules:</strong> the Air Range rules are part of the <a href="/about/#governance">chapter bylaws booklet</a> (issued/revised November 2024). Direct questions to the Director &ndash; Air Range, Keith Kuck, <a href="tel:7034058935">703-405-8935</a> or <a href="mailto:Keith.Kuck@arlingtonfairfax-iwla.org">Keith.Kuck@arlingtonfairfax-iwla.org</a>, or see the <a href="/contact/#officers">Officers &amp; Directors</a> list.</p>
HTML;

$air_id = iwla_upsert_page( array(
	'post_title'   => 'Air Range',
	'post_name'    => 'air-range',
	'post_content' => $air_content,
	'post_excerpt' => 'The 26-lane indoor Sills Air Range: school teams, junior programs, open practice, and adaptive shooting.',
	'post_parent'  => $ranges_id,
	'menu_order'   => 4,
) );

/* ---------------- EDUCATION & TRAINING ---------------- */
$et_content = <<<HTML
<p>The chapter runs a Firearm Education and Training Program of formal NRA courses and other shooting-oriented events, including archery. Courses are offered throughout the year by a volunteer team of NRA Certified Instructors, NRA Training Counselors, NRA/USA Shooting coaches, and USA Archery Certified Trainers.</p>

<h2>Course schedule</h2>
<p>Register and pay online with the links on each row. Questions: Director of Education &amp; Training John Seaberg, <a href="mailto:John.Seaberg@arlingtonfairfax-iwla.org">John.Seaberg@arlingtonfairfax-iwla.org</a>.</p>
[iwla_courses]

<h2>What we teach</h2>
<ul>
<li>Basic pistol, rifle, and shotgun</li>
<li>Intermediate personal protection courses</li>
<li>Metallic and shotshell reloading</li>
<li>Refuse To Be A Victim</li>
<li>Pistol, rifle, and shotgun coach development</li>
<li>Camps and clinics, including Shotgun Camp and the annual NRA <a href="/youth/">Women on Target</a> clinic</li>
</ul>

<h2>Archery 101 &amp; 201</h2>
<p>Archery 101 introduces new archers; Archery 201 is a 5-week session for beginners who want to keep going. Class dates are on the <a href="/calendar/">chapter calendar</a>. Fees depend on the number of participants &mdash; contact Field Archery Director Dick Riemer at <a href="mailto:Dick.Riemer@arlingtonfairfax-iwla.org">Dick.Riemer@arlingtonfairfax-iwla.org</a> for current pricing and openings. See also <a href="/ranges/archery/">Archery</a> for instructor training.</p>
[iwla_pay key="archery201" label="Archery 201 payment"]

<h2 id="etft">Education &amp; Training Facility Trust</h2>
<p>In 2003 the Board of Directors established a charitable trust, the Arlington-Fairfax Chapter Education and Training Facility Trust (ETFT), to raise the money to design, build, and equip a dedicated education and training facility. The project is separate from the chapter's general budget and capital funds. The planned site is across the main road from the Field House. The current design has a classroom plus a pistol and smallbore range that can be divided for separate events, and the building would be the main home for NRA basic firearms courses, concealed-carry training, coach schools, Refuse To Be A Victim seminars, Women on Target clinics, smallbore team practice, and IDPA/IPSA/USPSA-type matches.</p>
<p>The trustees are looking for chapter members with professional fund-raising experience. Contact the trustees at <a href="mailto:ARLFX-ETFT@arlingtonfairfax-iwla.org">ARLFX-ETFT@arlingtonfairfax-iwla.org</a>.</p>

<h2>NRA training resources</h2>
<ul>
<li><a href="https://firearmtraining.nra.org/" target="_blank" rel="noopener">NRA Firearm Training</a></li>
<li><a href="https://www.nrainstructors.org/CourseCatalog.aspx" target="_blank" rel="noopener">NRA course catalog</a> and <a href="https://www.nrainstructors.org/search.aspx" target="_blank" rel="noopener">find a course near you</a></li>
<li>Course details: <a href="https://www.nrainstructors.org/CatalogInfo.aspx?cid=56" target="_blank" rel="noopener">Basic Pistol</a>, <a href="https://www.nrainstructors.org/CatalogInfo.aspx?cid=1" target="_blank" rel="noopener">Basic Rifle</a>, <a href="https://www.nrainstructors.org/CatalogInfo.aspx?cid=3" target="_blank" rel="noopener">Basic Shotgun</a>, <a href="https://www.nrainstructors.org/CatalogInfo.aspx?cid=5" target="_blank" rel="noopener">Basic Range Safety Officer</a>, <a href="https://www.nrainstructors.org/CatalogInfo.aspx?cid=14" target="_blank" rel="noopener">Personal Protection in the Home</a>, <a href="https://www.nrainstructors.org/CatalogInfo.aspx?cid=15" target="_blank" rel="noopener">Personal Protection Outside the Home</a>, <a href="https://www.nrainstructors.org/CatalogInfo.aspx?cid=41" target="_blank" rel="noopener">Defensive Pistol</a></li>
<li><a href="https://coach.nra.org/" target="_blank" rel="noopener">NRA Coach</a> and <a href="https://firearmtraining.nra.org/become-an-instructor/" target="_blank" rel="noopener">become an NRA instructor</a></li>
</ul>
HTML;

$et_id = iwla_upsert_page( array(
	'post_title'   => 'Education & Training',
	'post_name'    => 'education-training',
	'post_content' => $et_content,
	'post_excerpt' => 'NRA courses, coach schools, and Archery 101/201: schedule, registration, and payment.',
	'post_parent'  => $ranges_id,
	'menu_order'   => 5,
) );

/* ---------------- CONSERVATION ---------------- */
$conservation_content = <<<HTML
<p>The Izaak Walton League's founding mission is leadership in conserving woodlands, wildlife, water, and related natural resources. The Arlington-Fairfax Chapter pursues that through year-round formal and informal work:</p>
<ul>
<li>Preserving natural areas for members and the community</li>
<li>Providing sufficient natural habitat for wildlife</li>
<li>Ensuring the survival of native plants and animals</li>
<li>Enhancing chapter property for fishing, camping, and outdoor recreation</li>
<li>Improving environmental quality and promoting environmental responsibility through education</li>
</ul>
<p>Conservation work is coordinated with the chapter's Buildings &amp; Grounds committee to set project priorities, evaluate environmental impact, and stay compliant with applicable regulations. Members with a conservation or environmental science background are encouraged to get involved &mdash; contact Conservation Director Fred Bailey at <a href="mailto:Fred.Bailey@arlingtonfairfax-iwla.org">Fred.Bailey@arlingtonfairfax-iwla.org</a>.</p>

<h2>Save Our Streams (SOS)</h2>
<p>The chapter runs a Virginia Save Our Streams water-monitoring program, part of the national IWLA program founded alongside the League in 1922. Volunteers monitor local waterways for the health of the surrounding watershed. Interested members can email <a href="mailto:ARLFXSOS@gmail.com">ARLFXSOS@gmail.com</a>, or see the <a href="https://www.iwla.org/water/stream-monitoring" target="_blank" rel="noopener">IWLA Save Our Streams</a> and Virginia SOS sites for forms and gear.</p>

<h2>Environmental Management System (EMS)</h2>
<p>For over 15 years the chapter has run an EMS to keep range operations from harming local water and land. Lime and rock phosphate are applied to the Skeet/Trap shot-fall area to bind lead and prevent it from leaching into surface and groundwater, surface water quality is sampled regularly, and the chapter has run two lead-reclamation projects removing over 500,000&nbsp;lbs of lead from the environment, alongside a shift to biodegradable targets at Skeet/Trap.</p>
<p>On March 29, 2022 the chapter received a Bronze Medal Governor's Environmental Excellence Award (Sustainability Program) at the 32nd Annual Virginia Environment Symposium at VMI, in recognition of this work.</p>

<h2 id="fishing">Fishing at Gilbert's Pond</h2>
<p>The chapter's two-acre pond is catch-and-release only. All Virginia Department of Wildlife Resources (<a href="https://dwr.virginia.gov/" target="_blank" rel="noopener">DWR</a>) regulations apply, and the chapter's Angler (fishing) Club is a good way to get involved &mdash; see <a href="/contact/#contacts">chapter contacts</a>.</p>

<h2>Other conservation efforts</h2>
<ul>
<li>Virginia Adopt-a-Highway</li>
<li>Cub Run Stream Valley Park volunteer team</li>
<li>Northern Virginia Native Plant Program</li>
<li>Member-maintained food plots, bee hives, and woodland areas</li>
<li>Scout-led conservation service projects on chapter property</li>
</ul>
<p>All chapter volunteer opportunities, including conservation projects, are posted through SignUpGenius &mdash; sign up to get credit toward your membership service hours, or just to help out.</p>
HTML;

$conservation_id = iwla_upsert_page( array(
	'post_title'   => 'Conservation',
	'post_name'    => 'conservation',
	'post_content' => $conservation_content,
	'post_excerpt' => 'Stream monitoring, an award-winning environmental management system, and habitat stewardship on our 110 acres.',
) );

/* ---------------- YOUTH ---------------- */
$youth_content = <<<HTML
<div class="callout">
<span class="icon">&#127919;</span>
<div><strong>Women on Target clinic</strong>
<p>The chapter hosts the NRA Women on Target clinic each spring (the 2026 clinic was May 16). Watch the <a href="/calendar/">calendar</a> and <a href="/ranges/education-training/">Education &amp; Training</a> for the next date and registration.</p></div>
</div>

<h2>Women on Target</h2>
<p>A safe, comfortable setting for learning about the shooting sports &mdash; rifles, pistols, shotguns, muzzleloaders, and archery &mdash; plus five seminars that don't involve shooting:</p>
<ul>
<li><strong>Refuse To Be A Victim</strong> (NRA): tips and techniques for recognizing and avoiding dangerous situations.</li>
<li><strong>Women &amp; Hunting</strong> (Virginia Department of Wildlife Resources): for women interested in hunting.</li>
<li><strong>Buying &amp; Caring for a Handgun:</strong> what to know before you shop.</li>
<li><strong>Firearms and the Law:</strong> the key provisions on purchase, sale, and possession.</li>
<li><strong>Legal Aspects of Self-Defense:</strong> your rights and restrictions on carrying and using a handgun for self-defense.</li>
</ul>
<p>Details about the national program: <a href="https://wot.nra.org/" target="_blank" rel="noopener">wot.nra.org</a>.</p>

<h2>Junior Chapter</h2>
<p>Established in 2016, the Arlington-Fairfax Junior Chapter has about 200 members under 18, run by a nine-member youth Board of Directors elected annually. Membership in the Junior Chapter is required for any minor participating in organized shooting sports at the chapter. The Junior Chapter co-sponsors the annual <strong>Wendel Thompson Memorial Precision Air Rifle/Pistol Match</strong>, which has drawn 60+ competitors and served as a Virginia Shooting Sports Association state championship.</p>
<p><strong>Note:</strong> Minors under 18 may only use chapter facilities when accompanied by an adult member or participating in a chapter-sanctioned activity.</p>
<p><strong>Join or renew:</strong> use the <a href="https://www.signupgenius.com/index.cfm?go=c.SignUpSearch&amp;eid=0AC7C0DFF5CAFE65&amp;cs=09B2BAD88FCD8B137B0A64765BB39BCB" target="_blank" rel="noopener">Junior Membership sign-up</a> and complete the membership release form. Questions: Director of Youth Activities Joe Turner, <a href="mailto:Joe.Turner@arlingtonfairfax-iwla.org">Joe.Turner@arlingtonfairfax-iwla.org</a>.</p>

<h2>Junior Olympic Archery Development (JOAD)</h2>
<p>JOAD teaches archers age 8&ndash;18 the fundamentals of Olympic-style archery &mdash; technique, tournament participation, equipment setup, physical fitness, and mental preparation &mdash; across three 12-week sessions a year at the indoor and outdoor ranges. All coaches are U.S. Archery Level 2/3 certified with SafeSport training and background checks. Sessions traditionally meet Sundays, 3&ndash;5 p.m.; check the chapter calendar for exact dates.</p>

<h2>Youth Shotgun Team</h2>
<p>Started in 2014, the chapter's youth trapshooting team (ages 12&ndash;22) competes Saturday afternoons through the Virginia Youth Trapshooting League (VYTL), using the AIM (Academics Integrity Marksmanship) format &mdash; the official ATA youth program. The regular season runs mid-March through mid-May (50 competition + up to 50 practice targets weekly), followed by a state tournament in Winchester, VA each June.</p>

<h2>NoVA Sharpshooters (NVSS)</h2>
<p>Two junior programs for ages 10&ndash;18, both requiring the Sills Air Range consumables fee and Junior Chapter membership:</p>
<ul>
<li><strong>Junior Pistol Program</strong> &mdash; 10m air pistol, with advanced athletes progressing to 25m sport pistol (.22 LR). Contact <a href="mailto:novasharpshootersiwla@gmail.com">novasharpshootersiwla@gmail.com</a>.</li>
<li><strong>Paralympic Junior Air Rifle Program</strong> &mdash; prepares Paralympic junior athletes for CMP, NRA, and USA Shooting events. Contact Tom Ciarula at <a href="mailto:ciarulat@cox.net">ciarulat@cox.net</a> or <a href="tel:7032500947">703-250-0947</a>.</li>
</ul>

<h2>High School Air Rifle Teams</h2>
<p>The chapter sponsors and hosts the home range for seven Potomac High School Rifle League (PHSRL) teams: Centreville, Fairfax, Lake Braddock, Robinson, West Springfield, and Woodson high schools, plus the independent Mavericks team.</p>

<h2>Scouting partnerships</h2>
<p>The chapter charters several local Scouting units, giving scouts a place to meet and complete conservation-minded service projects on chapter property.</p>
<div class="table-scroll"><table>
<tr><th>Unit</th><th>Leadership</th><th>Meets</th></tr>
<tr><td>Troop 695</td><td>Scoutmaster Ryan Frazier &middot; Chair Pam Gercken</td><td>Wednesdays 7:30&ndash;8:30 p.m., Brookfield ES</td></tr>
<tr><td>Pack 864</td><td>Cubmaster Chad Cerar &middot; Chair Arnold Heck</td><td>Centreville, VA</td></tr>
<tr><td>Troop 1137 (Boys)</td><td>Scoutmaster Jeff Mauck &middot; Chair Jake Marshak</td><td>Monday nights 7 p.m., chapter grounds</td></tr>
<tr><td>Troop 1137 (Girls)</td><td>Scoutmaster Jeff Tackett &middot; Chair Elias El-Hage</td><td>Monday nights 7 p.m., chapter grounds</td></tr>
<tr><td>Venture Crew 1137</td><td>Advisor Todd Martin &middot; Chair Jake Marshak</td><td>Centreville, VA</td></tr>
</table></div>
<p>For chapter Scouting questions, contact liaison Tom Pike at <a href="mailto:Tom.Pike@arlingtonfairfax-iwla.org">Tom.Pike@arlingtonfairfax-iwla.org</a>.</p>
HTML;

$youth_id = iwla_upsert_page( array(
	'post_title'   => 'Youth Programs',
	'post_name'    => 'youth',
	'post_content' => $youth_content,
	'post_excerpt' => 'JOAD archery, youth shotgun, NoVA Sharpshooters, high school air rifle, and five chartered Scouting units.',
) );

/* ---------------- RESOURCES ---------------- */
$resources_content = <<<HTML
<h2 id="calendar">Chapter calendar</h2>
<p>The full chapter calendar &mdash; ranges, leagues, meetings, and closures &mdash; has its own page.</p>
<p><a class="btn btn-primary btn-sm" href="/calendar/">Open the chapter calendar</a></p>

<h2 id="newsletters">Newsletters</h2>
<p>Published quarterly by the Newsletter Committee (Editor-in-Chief Pamela Meara, Copy Editor Tim Terrell, Design &amp; Production Ellen MacBrayne).</p>
[iwla_documents category="newsletters" limit="8"]
<p>Since 2024, delivery is electronic by default &mdash; contact the office to opt into a printed copy. Story ideas or questions: <a href="mailto:newsletter@arlingtonfairfax-iwla.org">newsletter@arlingtonfairfax-iwla.org</a>.</p>

<h2>Meeting minutes</h2>
<p>General Membership (GM) meets the 3rd Tuesday and the Board of Directors (BOD) meets the 1st Tuesday of each month, both at 7:30&nbsp;p.m.</p>
[iwla_documents category="minutes" limit="12"]
<p>Questions: <a href="mailto:info@arlingtonfairfax-iwla.org">info@arlingtonfairfax-iwla.org</a>.</p>

<h2 id="awards">Awards &amp; grants</h2>
<p>The Awards &amp; Grants Committee (Chair Scott Meyer, BOD Liaison Pamela Meara) identifies grants and awards the chapter can apply for, keeps current copies of the documents applications require, tracks application windows, and reports to the Board. Contact <a href="mailto:arlfxawardsgrants@gmail.com">arlfxawardsgrants@gmail.com</a> or <a href="tel:7039992581">703-999-2581</a> to get involved.</p>
<p>The chapter's newsletter has won the IWLA's Best Chapter Newsletter award (chapters with 500 or more members) in 2017, 2019, 2021, and 2024.</p>
<h3>Grants awarded to the chapter</h3>
<div class="table-scroll"><table>
<tr><th>Year</th><th>Program</th><th>Grantor</th></tr>
<tr><td>2025</td><td>Skeet &amp; Trap Range</td><td>Amateur Trapshooting Association (ATA) grant</td></tr>
<tr><td>2025</td><td>Skeet &amp; Trap Range</td><td>The NRA Foundation grant program</td></tr>
<tr><td>2024</td><td>Skeet &amp; Trap Range</td><td>NSSA Club Assistance grant</td></tr>
<tr><td>2022</td><td>Field Archery 3D Range</td><td>USA Archery (3D targets)</td></tr>
<tr><td>2022</td><td>Rifle-Pistol Range</td><td>Friends of the NRA (FONRA)</td></tr>
<tr><td>2021</td><td>AIM Youth Shotgun</td><td>Friends of the NRA (FONRA)</td></tr>
<tr><td>2021</td><td>Air Range</td><td>Friends of the NRA (FONRA)</td></tr>
<tr><td>2020</td><td>AIM Youth Shotgun</td><td>Friends of the NRA (FONRA)</td></tr>
<tr><td>2020</td><td>Air Range</td><td>Friends of the NRA (FONRA)</td></tr>
<tr><td>2019</td><td>AIM Youth Shotgun</td><td>Friends of the NRA (FONRA)</td></tr>
<tr><td>2018</td><td>AIM Youth Shotgun</td><td>IWLA Endowment</td></tr>
<tr><td>2018</td><td>Air Range</td><td>Friends of the NRA (FONRA)</td></tr>
<tr><td>2018</td><td>AIM Youth Shotgun</td><td>Friends of the NRA (FONRA)</td></tr>
</table></div>

<h2 id="scholarship">Environmental Sciences Scholarship</h2>
<p>In 1993 the Board of Directors established the scholarship to show the chapter's concern for the environment and for young people in the tri-county area (Arlington, Fairfax, and Prince William). It began at $750 per student per year, rose to $3,000 in 1999, and to <strong>$5,000 per student per year</strong> beginning in 2015. Awards are paid directly to the recipient's college in four annual installments, and since August 2020 each winner also receives a chapter student membership while the scholarship continues.</p>
<h3>Who can apply</h3>
<p>Applicants must plan to study at an accredited institution toward an associate (2-year) or bachelor's (4-year) degree in environmental sciences or a related field. The committee weighs financial need, academic achievement, individual character, community achievements or activities, and the ability to succeed in college. A letter describing your intended course of study and any environmental activities (through school, church, or community groups) is welcome.</p>
<h3>How to apply</h3>
<p>Complete the application and mail it so that it arrives <strong>no later than May 15</strong> to: Scholarship Committee (Sean Gagnon), Arlington-Fairfax Chapter, Inc., Izaak Walton League of America, P.O. Box 366, Centreville, VA 20122-0366. The committee reviews applications and recommends awards to the Board of Directors.</p>
[iwla_documents category="forms" limit="10"]
<p>The IWLA also offers a <a href="https://www.iwla.org/" target="_blank" rel="noopener">National Conservation Scholarship</a> for rising junior and senior undergraduates in conservation or environment-related programs.</p>

<h2 id="links">Links</h2>
<h3>Chapter-related sites</h3>
<ul>
<li><a href="http://www.cubrunarchers.org/index.html" target="_blank" rel="noopener">Cub Run Archers</a> &middot; <a href="http://bullrunmuzzleloaders.com/" target="_blank" rel="noopener">Bull Run Muzzle Loaders</a></li>
<li><a href="https://www.iwla.org/" target="_blank" rel="noopener">IWLA National</a> &middot; <a href="http://va-iwla.org/" target="_blank" rel="noopener">IWLA Virginia Division</a> &middot; <a href="http://iwla-endowment.org/" target="_blank" rel="noopener">IWLA Endowment</a> &middot; <a href="https://iwla.org/publications-media/" target="_blank" rel="noopener">IWLA publications &amp; media</a></li>
<li><a href="https://home.nra.org/" target="_blank" rel="noopener">National Rifle Association</a> &middot; <a href="http://women.nra.org/" target="_blank" rel="noopener">NRA Women's Programs</a> &middot; <a href="https://www.friendsofnra.org/" target="_blank" rel="noopener">Friends of NRA</a></li>
<li><a href="https://www.deq.virginia.gov/" target="_blank" rel="noopener">Virginia Department of Environmental Quality</a> &middot; <a href="https://dwr.virginia.gov/" target="_blank" rel="noopener">Virginia Department of Wildlife Resources</a> &middot; <a href="https://www.myvssa.org/" target="_blank" rel="noopener">Virginia Shooting Sports Association</a></li>
</ul>
<h3>Contact your representative</h3>
<ul>
<li><a href="https://www.house.gov/representatives" target="_blank" rel="noopener">U.S. Representatives</a> &middot; <a href="https://www.senate.gov/general/contact_information/senators_cfm.cfm?State=VA" target="_blank" rel="noopener">U.S. Senators (Virginia)</a></li>
<li><a href="https://virginiageneralassembly.gov/" target="_blank" rel="noopener">Virginia General Assembly</a> &middot; <a href="https://www.virginia.gov/services/whos-my-legislator/" target="_blank" rel="noopener">Who is my Virginia legislator?</a></li>
</ul>
<h3>Voter information</h3>
<ul>
<li><a href="https://www.elections.virginia.gov/index.html" target="_blank" rel="noopener">Virginia</a> &middot; <a href="https://elections.maryland.gov/" target="_blank" rel="noopener">Maryland</a> &middot; <a href="https://dcboe.org/" target="_blank" rel="noopener">District of Columbia</a></li>
</ul>

<h2>Chapter clubs &amp; groups</h2>
<div class="grid grid-3">
<div class="card"><h3>Knife Club</h3><p>Quarterly meetups for knife, ax, tomahawk, and multitool enthusiasts &mdash; workshops, safe-use classes, and sharpening clinics. Contact host Lt. Col. Matt Michaelson, USA (Ret.) at <a href="mailto:mtmichaelson@hotmail.com">mtmichaelson@hotmail.com</a>.</p></div>
<div class="card"><h3>Bull Run Muzzle Loaders</h3><p>An NMLRA charter club since 1988, shooting the 3rd Sunday of each month at the Rifle/Pistol range. All muzzleloader types welcome, loaner rifles available, no membership required to shoot. <a href="/ranges/rifle-pistol/">Full details &rarr;</a></p></div>
<div class="card"><h3>Firewood for Sale</h3><p>Mixed oak and hickory, cut and split, $350/cord, available seasonally. Buyers haul their own &mdash; no delivery. Contact <a href="mailto:arlfxiwla@gmail.com">arlfxiwla@gmail.com</a> for availability.</p></div>
</div>
HTML;

$resources_id = iwla_upsert_page( array(
	'post_title'   => 'Resources',
	'post_name'    => 'resources',
	'post_content' => $resources_content,
	'post_excerpt' => 'Newsletters, meeting minutes, awards & scholarships, the chapter calendar, and member clubs.',
) );

/* ---------------- EVENTS (chapter calendar) ---------------- */
function iwla_upsert_event( $title, $date, $description, $end_date = '' ) {
	$existing_posts = get_posts( array(
		'post_type'      => 'iwla_event',
		'title'          => $title,
		'post_status'    => 'any',
		'posts_per_page' => 1,
	) );
	$postarr = array(
		'post_type'    => 'iwla_event',
		'post_status'  => 'publish',
		'post_title'   => $title,
		'post_content' => $description,
	);
	if ( $existing_posts ) {
		$postarr['ID'] = $existing_posts[0]->ID;
		$id = wp_update_post( $postarr );
	} else {
		$id = wp_insert_post( $postarr );
	}
	update_post_meta( $id, '_iwla_event_date', $date );
	if ( $end_date ) {
		update_post_meta( $id, '_iwla_event_end_date', $end_date );
	}
	return $id;
}

iwla_upsert_event( '2026 Annual Picnic', '2026-09-12', 'Chapter-wide picnic for members and their families.' );
iwla_upsert_event( 'Christmas Party for Foster Children', '2026-12-12', 'A chapter tradition bringing holiday cheer to local foster children.' );
iwla_upsert_event( "28th Annual Crush'n Clays Charity Event", '2027-06-12', "VSSA charity shoot benefiting St. Jude Children's Research Hospital. Save the date." );

echo "Events seeded.\n";

/* ---------------- DOCUMENTS (Google Drive links) ---------------- */
function iwla_upsert_document( $title, $category ) {
	$existing_posts = get_posts( array(
		'post_type'      => 'iwla_document',
		'title'          => $title,
		'post_status'    => 'any',
		'posts_per_page' => 1,
	) );
	$postarr = array(
		'post_type'   => 'iwla_document',
		'post_status' => 'publish',
		'post_title'  => $title,
	);
	if ( $existing_posts ) {
		$postarr['ID'] = $existing_posts[0]->ID;
		$id = wp_update_post( $postarr );
	} else {
		$id = wp_insert_post( $postarr );
	}
	wp_set_object_terms( $id, $category, 'iwla_doc_category' );
	// Note: leaves _iwla_doc_url empty on purpose — edit this Document in
	// wp-admin and paste the real Google Drive share link.
	return $id;
}

foreach ( array(
	'Chapter Bylaws Booklet — Nov 2024',
	'Chapter Policies — Apr 2026',
) as $doc ) {
	iwla_upsert_document( $doc, 'governance' );
}

foreach ( array(
	'64-3 · Aug–Oct 2026',
	'64-2 · May–Jul 2026',
	'64-1 · Feb–Apr 2026',
	'63-4 · Nov 2025–Jan 2026',
	'63-3 · Aug–Oct 2025',
) as $doc ) {
	iwla_upsert_document( $doc, 'newsletters' );
}

foreach ( array(
	'07-21-2026 General Membership Minutes',
	'06-16-2026 General Membership Minutes',
	'06-02-2026 Board of Directors Minutes',
	'05-19-2026 General Membership Minutes',
	'05-05-2026 Board of Directors Minutes',
	'04-21-2026 General Membership Minutes',
	'04-07-2026 Board of Directors Minutes',
) as $doc ) {
	iwla_upsert_document( $doc, 'minutes' );
}

foreach ( array(
	'2027 Membership Renewal Form',
	'Environmental Sciences Scholarship Application',
) as $doc ) {
	iwla_upsert_document( $doc, 'forms' );
}

echo "Documents seeded (edit each in wp-admin to add its Google Drive link).\n";

/* ---------------- FACILITY FORMS (Drive links added in wp-admin) ---------------- */
foreach ( array(
	'Group Activities Permit',
	'Group Activities Permit Checklist',
	'Guest Liability Release (Facilities)',
) as $doc ) {
	iwla_upsert_document( $doc, 'facility-forms' );
}

/* ---------------- COURSES ---------------- */
$iwla_courses = array(
	array( 'NRA FIRST Steps Rifle for Modern Sporting Rifle', '2026-10-10', '', '$100', 'https://www.nrainstructors.org/CourseDetails.aspx?Courseid=934589', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=RXZSLBQEHSAGW', '' ),
	array( 'NRA Level 1 Pistol Coach School', '2026-10-24', '2026-10-25', '$225', 'https://www.nrainstructors.org/CourseDetails.aspx?Courseid=936532', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=YF7GA75C453SQ', '' ),
	array( 'NRA Level 1 Shotgun Coach School', '2026-10-24', '2026-10-25', '$225', 'https://www.nrainstructors.org/CourseDetails.aspx?Courseid=900033', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=SMGP73PMDDV9W', '' ),
	array( 'NRA Level 1 Rifle Coach School (Smallbore and Air)', '2026-10-24', '2026-10-25', '$225', 'https://www.nrainstructors.org/CourseDetails.aspx?Courseid=897616', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=NSVBE4WYW7LZY', '' ),
	array( 'NRA Basic Range Safety Officer Course', '2026-11-14', '', '$100', 'https://www.nrainstructors.org/CourseDetails.aspx?Courseid=931275', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=KLCQD8M4F3CY8', '' ),
	array( 'NRA Basic Shotgun Shooting Course', '2026-11-21', '', '$100', 'https://www.nrainstructors.org/CourseDetails.aspx?Courseid=909410', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ZUVTDF353J4UJ', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=YBDD99RLZZTRW' ),
	array( 'NRA Basic Shotgun Shell Reloading Course', '2026-12-12', '', '$100', 'https://www.nrainstructors.org/CourseDetails.aspx?Courseid=900034', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=TRGDZKZLSNFJC', '' ),
	array( 'NRA Level 1 Pistol Coach School', '2027-02-20', '2027-02-21', '$225', 'https://www.nrainstructors.org/CourseDetails.aspx?Courseid=936532&seats=20&State=n&zip=20214&radius=25.1&id=43&bsa=&youth=&women=', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=PJBD56CL2TQLS', '' ),
	array( 'NRA Level 1 Rifle Coach School (Smallbore and Air)', '2027-03-13', '2027-03-14', '$225', 'https://www.nrainstructors.org/CourseDetails.aspx?Courseid=940006&seats=20&State=n&zip=20214&radius=25.1&id=44&bsa=&youth=&women=', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=4F3TVUKYDTUKL', '' ),
	array( 'NRA Personal Protection In the Home Course', '2027-05-22', '', '$125', 'https://www.nrainstructors.org/CourseDetails.aspx?Courseid=940296', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=9PPBG6KFDUB2W', '' ),
	array( 'NRA Basic Range Safety Officer Course', '2027-06-06', '', '$100', 'https://www.nrainstructors.org/CourseDetails.aspx?Courseid=940232&seats=20&State=n&zip=22015&radius=25.1&id=5&bsa=&youth=&women=', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ZRX7BHNGHR3JA', '' ),
	array( 'NRA Personal Protection Outside The Home Course', '2027-06-26', '2027-06-27', '$150', 'https://www.nrainstructors.org/CourseDetails.aspx?Courseid=940297', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=9THGECQVWLLWL', '' ),
	array( 'NRA Basics of Shotgun Shooting Course', '2027-07-25', '', '$100', 'https://www.nrainstructors.org/CourseDetails.aspx?Courseid=940235&seats=20&State=n&zip=22015&radius=25.1&id=3&bsa=&youth=&women=', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=JJRVVKZBRGHAJ', '' ),
	array( 'NRA Level 1 Rifle Coach School (Smallbore and Air)', '2027-11-20', '2027-11-21', '$225', 'https://www.nrainstructors.org/CourseDetails.aspx?Courseid=940007&seats=20&State=n&zip=20214&radius=25.1&id=44&bsa=&youth=&women=', 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ZCNG6SG2B7P7N', '' ),
);
foreach ( $iwla_courses as $c ) {
	$existing = get_posts( array( 'post_type' => 'iwla_course', 'title' => $c[0], 'post_status' => 'any', 'posts_per_page' => 1, 'meta_key' => '_iwla_course_date', 'meta_value' => $c[1] ) );
	$postarr  = array( 'post_type' => 'iwla_course', 'post_status' => 'publish', 'post_title' => $c[0] );
	if ( $existing ) {
		$postarr['ID'] = $existing[0]->ID;
	}
	$cid = $existing ? wp_update_post( $postarr ) : wp_insert_post( $postarr );
	update_post_meta( $cid, '_iwla_course_date', $c[1] );
	update_post_meta( $cid, '_iwla_course_end_date', $c[2] );
	update_post_meta( $cid, '_iwla_course_cost', $c[3] );
	update_post_meta( $cid, '_iwla_course_reg', $c[4] );
	update_post_meta( $cid, '_iwla_course_pay', $c[5] );
	update_post_meta( $cid, '_iwla_course_rental', $c[6] );
}
echo "Courses seeded.\n";

/* ---------------- ANNOUNCEMENTS ---------------- */
function iwla_upsert_announcement( $title, $body, $severity, $end, $link, $label ) {
	$existing = get_posts( array( 'post_type' => 'iwla_announcement', 'title' => $title, 'post_status' => 'any', 'posts_per_page' => 1 ) );
	$postarr  = array( 'post_type' => 'iwla_announcement', 'post_status' => 'publish', 'post_title' => $title, 'post_content' => $body );
	if ( $existing ) {
		$postarr['ID'] = $existing[0]->ID;
	}
	$id = $existing ? wp_update_post( $postarr ) : wp_insert_post( $postarr );
	update_post_meta( $id, '_iwla_ann_severity', $severity );
	update_post_meta( $id, '_iwla_ann_end', $end );
	update_post_meta( $id, '_iwla_ann_link', $link );
	update_post_meta( $id, '_iwla_ann_link_label', $label );
	return $id;
}
iwla_upsert_announcement( '2027 membership renewals open October 15, 2026', 'Renew between October 15 and December 31, 2026. Any renewal received after 12/31/2026 incurs a $40 late fee — no exceptions.', 'notice', '2026-12-31', home_url( '/membership/' ), 'See renewal details' );
iwla_upsert_announcement( 'Rifle & Pistol Range: Short Range Day suspended', 'Short Range Day remains suspended until further notice (as of August 21, 2026). Always check the chapter calendar before you visit.', 'alert', '', home_url( '/ranges/rifle-pistol/' ), 'Range details' );
echo "Announcements seeded.\n";

/* ---------------- CHAPTER SETTINGS (calendar demo feed; replace with the real Google Calendar address) ---------------- */
update_option( 'timezone_string', 'America/New_York' );
if ( ! get_option( 'iwla_settings' ) ) {
	update_option( 'iwla_settings', array(
		'status'         => 'open',
		'calendar_feeds' => 'Demo calendar|' . get_template_directory_uri() . '/assets/demo-calendar.ics',
		'calendar_cache' => 15,
	) );
}

/* ---------------- SITE SETTINGS: front page + menu ---------------- */
update_option( 'show_on_front', 'page' );
update_option( 'page_on_front', $home_id );

update_option( 'blogname', 'Arlington-Fairfax Chapter, IWLA' );
update_option( 'blogdescription', 'Conserving land, water & wildlife in Northern Virginia since 1936' );

$menu_name = 'Primary';
$menu_obj  = wp_get_nav_menu_object( $menu_name );
if ( ! $menu_obj ) {
	$menu_id = wp_create_nav_menu( $menu_name );
} else {
	$menu_id = $menu_obj->term_id;
	foreach ( wp_get_nav_menu_items( $menu_id ) as $item ) {
		wp_delete_post( $item->ID, true );
	}
}

function iwla_add_menu_item( $menu_id, $page_id, $parent_item_id = 0, $position = 0, $label = null ) {
	return wp_update_nav_menu_item( $menu_id, 0, array(
		'menu-item-title'     => $label ?? get_the_title( $page_id ),
		'menu-item-object-id' => $page_id,
		'menu-item-object'    => 'page',
		'menu-item-type'      => 'post_type',
		'menu-item-status'    => 'publish',
		'menu-item-parent-id' => $parent_item_id,
		'menu-item-position'  => $position,
	) );
}

iwla_add_menu_item( $menu_id, $home_id, 0, 1 );
iwla_add_menu_item( $menu_id, $calendar_id, 0, 2 );
iwla_add_menu_item( $menu_id, $about_id, 0, 3 );
iwla_add_menu_item( $menu_id, $membership_id, 0, 4 );
$ranges_item_id = iwla_add_menu_item( $menu_id, $ranges_id, 0, 5, 'Ranges' );
iwla_add_menu_item( $menu_id, $rifle_id, $ranges_item_id, 1 );
iwla_add_menu_item( $menu_id, $skeet_id, $ranges_item_id, 2 );
iwla_add_menu_item( $menu_id, $archery_id, $ranges_item_id, 3 );
iwla_add_menu_item( $menu_id, $air_id, $ranges_item_id, 4 );
iwla_add_menu_item( $menu_id, $et_id, $ranges_item_id, 5 );
iwla_add_menu_item( $menu_id, $facuse_id, $ranges_item_id, 6 );
iwla_add_menu_item( $menu_id, $conservation_id, 0, 6 );
iwla_add_menu_item( $menu_id, $youth_id, 0, 7, 'Youth' );
iwla_add_menu_item( $menu_id, $resources_id, 0, 8 );
iwla_add_menu_item( $menu_id, $contact_id, 0, 9 );

$locations = get_theme_mod( 'nav_menu_locations' );
$locations['primary'] = $menu_id;
set_theme_mod( 'nav_menu_locations', $locations );

echo "Menu set up. Front page: $home_id\n";
echo "DONE\n";
