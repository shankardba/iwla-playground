<?php
/**
 * Home page template.
 */
get_header();
?>

<section class="hero">
  <div class="container hero-inner">
    <span class="eyebrow">Izaak Walton League of America &middot; Chartered 1936</span>
    <h1 style="color:#fff">Conserving land, water &amp; wildlife in Northern Virginia</h1>
    <p class="lead">The Arlington-Fairfax Chapter is a member-run conservation and outdoor recreation club on 110 acres in Fairfax County &mdash; home to shooting ranges, archery, fishing, camping, and stream conservation programs since 1936.</p>
    <div class="hero-actions">
      <a href="<?php echo esc_url( home_url( '/membership/' ) ); ?>" class="btn btn-primary">Become a Member <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
      <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn btn-outline">Visit the Chapter</a>
    </div>
    <div class="hero-stats">
      <div class="hero-stat"><span class="num">1936</span><span class="label">Chartered</span></div>
      <div class="hero-stat"><span class="num">110+</span><span class="label">Acres in Fairfax Co.</span></div>
      <div class="hero-stat"><span class="num">5</span><span class="label">Member Ranges</span></div>
      <div class="hero-stat"><span class="num">200+</span><span class="label">Junior Members</span></div>
    </div>
  </div>
</section>

<?php $iwla_announcements = iwla_render_announcements( 5 ); ?>
<?php if ( $iwla_announcements ) : ?>
<section class="tight">
  <div class="container">
    <?php echo $iwla_announcements; // phpcs:ignore WordPress.Security.EscapeOutput ?>
  </div>
</section>
<?php endif; ?>

<section class="bg-alt">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">What's happening</span>
      <h2>Upcoming chapter events</h2>
    </div>
    <?php echo iwla_render_events_list( iwla_get_upcoming_events( 3 ) ); ?>
    <p style="margin-top:20px;"><a href="<?php echo esc_url( home_url( '/calendar/' ) ); ?>" class="btn btn-outline-dark btn-sm">See the full chapter calendar &rarr;</a></p>
  </div>
</section>

<section class="bg-panel">
  <div class="container grid grid-2">
    <div class="card">
      <span class="icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3.5" y="5" width="17" height="15.5" rx="2.2"/><path d="M8 3v4M16 3v4M3.5 10h17"/></svg></span>
      <h3>Regular chapter meetings</h3>
      <p>Board of Directors: 1st Tuesday of each month, 7:30&nbsp;p.m.<br>General Membership: 3rd Tuesday of each month, 7:30&nbsp;p.m. Both meet at the Chapter Field House.</p>
    </div>
    <div class="card">
      <span class="icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/></svg></span>
      <h3>Range badge required</h3>
      <p>All members must display their range badge whenever they access or use any chapter range, archery or firearm. <a href="<?php echo esc_url( home_url( '/ranges/' ) ); ?>">Range rules &rarr;</a></p>
    </div>
  </div>
</section>

<section class="bg-alt">
  <div class="container">
    <div class="section-head center">
      <span class="eyebrow">Chapter life</span>
      <h2>Shooting sports, conservation, and community</h2>
      <p>One membership gives you access to every range and program on the property.</p>
    </div>
    <div class="grid grid-4">
      <div class="card">
        <span class="icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/></svg></span>
        <h3>Ranges &amp; Training</h3>
        <p>Rifle &amp; pistol, skeet &amp; trap, target and field archery, and an indoor air range.</p>
        <a href="<?php echo esc_url( home_url( '/ranges/' ) ); ?>">Explore ranges <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
      </div>
      <div class="card">
        <span class="icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 21c8-1 14-7 15-16-9 1-15 7-16 16Z"/><path d="M5 21c0-5 2-9 6-12"/></svg></span>
        <h3>Conservation</h3>
        <p>Stream monitoring, native plant restoration, and habitat stewardship on our 110 acres.</p>
        <a href="<?php echo esc_url( home_url( '/conservation/' ) ); ?>">See our work <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
      </div>
      <div class="card">
        <span class="icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="9" cy="8" r="3.2"/><path d="M2.5 20c1-4 4-6 6.5-6s5.5 2 6.5 6"/><circle cx="17.5" cy="9" r="2.6"/><path d="M15 20c.6-2.6 2-4.5 4-5.2"/></svg></span>
        <h3>Youth Programs</h3>
        <p>Junior Chapter, JOAD archery, and five chartered Scouting units meet on our grounds.</p>
        <a href="<?php echo esc_url( home_url( '/youth/' ) ); ?>">Youth activities <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
      </div>
      <div class="card">
        <span class="icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M8 9c0-3 1.8-5 4-5s4 2 4 5"/><path d="M6.5 9h11c.6 3-1 8-5.5 12-4.5-4-6.1-9-5.5-12Z"/></svg></span>
        <h3>Membership</h3>
        <p>Join a 90-year-old chapter of the nation's oldest conservation organization.</p>
        <a href="<?php echo esc_url( home_url( '/membership/' ) ); ?>">How to join <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
      </div>
    </div>
  </div>
</section>

<section class="bg-panel">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">Chapter information</span>
      <h2>Quick links</h2>
    </div>
    <ul class="quick-links">
      <li><a href="<?php echo esc_url( home_url( '/calendar/' ) ); ?>"><strong>Chapter calendar</strong><span>Range hours, events, and closures</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/membership/#faq' ) ); ?>"><strong>Membership FAQ</strong><span>Dues, orientation, guests, service hours</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/ranges/facilities-use/' ) ); ?>"><strong>Facility use requests</strong><span>Reserve pavilions, fields, or ranges</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/resources/#newsletters' ) ); ?>"><strong>Chapter newsletter</strong><span>Delivered electronically by default</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/resources/#scholarship' ) ); ?>"><strong>Scholarship</strong><span>Environmental Sciences, $5,000 a year</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/conservation/#fishing' ) ); ?>"><strong>Fishing at Gilbert's Pond</strong><span>Catch and release; DWR rules apply</span></a></li>
      <li><a href="https://www.signupgenius.com/index.cfm?go=c.SignUpSearch&amp;eid=0AC7C0DFF5CAFE65&amp;cs=09B2BAD88FCD8B137B0A64765BB39BCB" target="_blank" rel="noopener"><strong>Volunteer sign-ups</strong><span>SignUpGenius: earn service credit</span></a></li>
      <li><a href="https://members.iwla.org/apps/#QuickSub" target="_blank" rel="noopener"><strong>IWLA national newsletter</strong><span>Conservation Currents and action alerts</span></a></li>
      <li><a href="https://members.iwla.org/apps/#Store" target="_blank" rel="noopener"><strong>IWLA online store</strong><span>Apparel and member items</span></a></li>
    </ul>
  </div>
</section>
<section class="bg-dark">
  <div class="container split">
    <div>
      <span class="eyebrow">On the property</span>
      <h2>Please observe the chapter speed limit</h2>
      <p>The chapter speed limit is 10&nbsp;MPH and is radar enforced, per chapter ground rules and posted signs &mdash; this protects our members, guests, and the wildlife that shares the property.</p>
      <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn btn-outline">Get directions <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
    </div>
    <div class="split-media">
      <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/aerial-campus-map.jpg' ); ?>" alt="Aerial facilities map of the Arlington-Fairfax Chapter property showing the pond, ranges, and field house" loading="lazy">
    </div>
  </div>
</section>

<?php get_footer(); ?>
