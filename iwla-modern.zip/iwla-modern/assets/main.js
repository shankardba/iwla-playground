(function () {
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('primary-menu');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  document.querySelectorAll('.sub-toggle').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      var li = btn.closest('li');
      var open = li.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  });

  var cal = document.querySelector('.iwla-cal');
  if (cal) {
    var legBtns = cal.querySelectorAll('.leg');
    var clear = cal.querySelector('.leg-clear');
    var apply = function () {
      var on = [];
      legBtns.forEach(function (b) { if (b.getAttribute('aria-pressed') === 'true') { on.push(b.getAttribute('data-code')); } });
      cal.classList.toggle('has-hl', on.length > 0);
      cal.querySelectorAll('.cal-ev').forEach(function (ev) {
        var code = ev.getAttribute('data-code');
        ev.classList.toggle('hl', on.indexOf(code) !== -1);
      });
      if (clear) { clear.hidden = on.length === 0; }
    };
    legBtns.forEach(function (b) {
      b.addEventListener('click', function () {
        b.setAttribute('aria-pressed', b.getAttribute('aria-pressed') === 'true' ? 'false' : 'true');
        apply();
      });
    });
    if (clear) {
      clear.addEventListener('click', function () {
        legBtns.forEach(function (b) { b.setAttribute('aria-pressed', 'false'); });
        apply();
      });
    }

    // Month/list changes load in place. The page itself only contains the
    // current month; neighbouring months are fetched after it is up, so moving
    // back or forward is instant and never reloads the page.
    var endpoint = cal.getAttribute('data-endpoint');
    var page = cal.getAttribute('data-page');
    var bar = cal.querySelector('.cal-bar');
    var main = cal.querySelector('.cal-main');
    var store = {};
    var state = {
      m: cal.getAttribute('data-m'), v: cal.getAttribute('data-v'),
      prev: cal.getAttribute('data-prev'), next: cal.getAttribute('data-next')
    };
    var fetchPart = function (m, v) {
      var key = m + '|' + v;
      if (!store[key]) {
        var q = '?m=' + encodeURIComponent(m) + '&v=' + encodeURIComponent(v) + '&p=' + encodeURIComponent(page);
        store[key] = fetch(endpoint + q, { credentials: 'same-origin' }).then(function (r) {
          if (!r.ok) { throw new Error('bad response'); }
          return r.json();
        });
        store[key].catch(function () { delete store[key]; });
      }
      return store[key];
    };
    var warm = function () {
      var run = function () {
        fetchPart(state.prev, state.v).catch(function () {});
        fetchPart(state.next, state.v).catch(function () {});
      };
      if (window.requestIdleCallback) { window.requestIdleCallback(run, { timeout: 3000 }); } else { setTimeout(run, 1200); }
    };
    var show = function (d) {
      bar.innerHTML = d.bar;
      main.innerHTML = d.main;
      state = { m: d.m, v: d.v, prev: d.prev, next: d.next };
      cal.classList.remove('is-loading');
      apply();
      warm();
    };
    var go = function (m, v, href) {
      cal.classList.add('is-loading');
      fetchPart(m, v).then(function (d) {
        show(d);
        if (href) { history.pushState({ iwlaCal: true }, '', href); }
      }).catch(function () {
        if (href) { window.location.href = href; } else { window.location.reload(); }
      });
    };
    cal.addEventListener('click', function (e) {
      var a = e.target.closest ? e.target.closest('.cal-bar a') : null;
      if (!a || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button) { return; }
      var u;
      try { u = new URL(a.href); } catch (err) { return; }
      e.preventDefault();
      go(u.searchParams.get('cal_m') || '', u.searchParams.get('cal_v') || state.v, a.href);
    });
    window.addEventListener('popstate', function () {
      var u = new URL(window.location.href);
      go(u.searchParams.get('cal_m') || '', u.searchParams.get('cal_v') || 'month', null);
    });
    warm();
  }
})();

/* Click-to-play chapter video: the link works without JS; with JS it swaps in a privacy-friendly YouTube player on click. */
(function () {
  document.addEventListener('click', function (e) {
    var a = e.target.closest ? e.target.closest('a.yt-play') : null;
    if (!a || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button) { return; }
    var m = /[?&]v=([\w-]{6,20})/.exec(a.getAttribute('href') || '');
    if (!m) { return; }
    e.preventDefault();
    var f = document.createElement('iframe');
    f.src = 'https://www.youtube-nocookie.com/embed/' + m[1] + '?autoplay=1&rel=0';
    f.title = 'Chapter video';
    f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
    f.setAttribute('allowfullscreen', '');
    var box = a.parentNode;
    box.classList.add('is-playing');
    box.replaceChild(f, a);
  });
})();
