(function () {
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('primary-menu');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  document.querySelectorAll('.sub-toggle').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      var li = btn.closest('li');
      var open = li.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  });

  var cal = document.querySelector('.iwla-cal');
  if (cal) {
    var legBtns = cal.querySelectorAll('.leg');
    var clear = cal.querySelector('.leg-clear');
    var apply = function () {
      var on = [];
      legBtns.forEach(function (b) { if (b.getAttribute('aria-pressed') === 'true') { on.push(b.getAttribute('data-code')); } });
      cal.classList.toggle('has-hl', on.length > 0);
      cal.querySelectorAll('.cal-ev').forEach(function (ev) {
        var code = ev.getAttribute('data-code');
        ev.classList.toggle('hl', on.indexOf(code) !== -1);
      });
      if (clear) { clear.hidden = on.length === 0; }
    };
    legBtns.forEach(function (b) {
      b.addEventListener('click', function () {
        b.setAttribute('aria-pressed', b.getAttribute('aria-pressed') === 'true' ? 'false' : 'true');
        apply();
      });
    });
    if (clear) {
      clear.addEventListener('click', function () {
        legBtns.forEach(function (b) { b.setAttribute('aria-pressed', 'false'); });
        apply();
      });
    }
  }
})();
