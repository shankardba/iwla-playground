<?php
/**
 * Footer template.
 */
?>
</main>
<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand" style="margin-bottom:14px;">
          <span class="footer-logo-badge"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/logo-seal.png' ); ?>" alt=""></span>
          <span>
            <span class="brand-text-main">Arlington-Fairfax Chapter</span>
            <span class="brand-text-sub">Izaak Walton League of America</span>
          </span>
        </a>
        <p>Conserving land, water, and wildlife in Fairfax County, Virginia since 1936. A 501(c)(3) nonprofit educational corporation.</p>
      </div>
      <div>
        <h3>Explore</h3>
        <ul>
          <li><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>">About the Chapter</a></li>
          <li><a href="<?php echo esc_url( home_url( '/ranges/' ) ); ?>">Ranges &amp; Training</a></li>
          <li><a href="<?php echo esc_url( home_url( '/conservation/' ) ); ?>">Conservation</a></li>
          <li><a href="<?php echo esc_url( home_url( '/youth/' ) ); ?>">Youth Programs</a></li>
        </ul>
      </div>
      <div>
        <h3>Membership</h3>
        <ul>
          <li><a href="<?php echo esc_url( home_url( '/membership/' ) ); ?>">Membership Info</a></li>
          <li><a href="<?php echo esc_url( home_url( '/resources/' ) ); ?>">Newsletters &amp; Minutes</a></li>
          <li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Officers &amp; Directors</a></li>
        </ul>
      </div>
      <div>
        <h3>Contact</h3>
        <ul>
          <li>14708 Mount Olive Road<br>Centreville, VA 20121</li>
          <li><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1.1-.3 1.2.4 2.5.6 3.8.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C11.6 21 3 12.4 3 2.1c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.6.6 3.8.1.4 0 .8-.3 1.1L6.6 10.8Z"/></svg> 703-631-4495</li>
          <li><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2.5" y="4.5" width="19" height="15" rx="2.2"/><path d="m3.5 6 8.5 7 8.5-7"/></svg> <a href="mailto:membershipscy@arlingtonfairfax-iwla.org">membershipscy@<wbr>arlingtonfairfax-iwla.org</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <?php echo esc_html( date( 'Y' ) ); ?> Arlington-Fairfax Chapter Inc., IWLA. All rights reserved.</span>
      <span>A member chapter of the <a href="https://www.iwla.org" target="_blank" rel="noopener">Izaak Walton League of America</a>, founded 1922.</span>
    </div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
