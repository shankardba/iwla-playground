<?php
/**
 * Generic page template: hero + typographic content.
 * Pages that are part of a section (have a parent, or have children)
 * get a two-column layout with a section sub-navigation box.
 */
get_header();

while ( have_posts() ) :
	the_post();

	$has_children = count( get_pages( array( 'parent' => get_the_ID() ) ) ) > 0;
	$has_parent   = 0 !== wp_get_post_parent_id( get_the_ID() );
	$is_section   = $has_children || $has_parent;
	$excerpt      = get_the_excerpt();
	?>

	<section class="page-hero">
		<div class="container">
			<?php iwla_breadcrumb(); ?>
			<h1><?php the_title(); ?></h1>
			<?php if ( $excerpt ) : ?>
				<p class="lead"><?php echo esc_html( $excerpt ); ?></p>
			<?php endif; ?>
		</div>
	</section>

	<?php if ( has_post_thumbnail() ) : ?>
		<div class="page-banner">
			<?php the_post_thumbnail( 'large' ); ?>
		</div>
	<?php endif; ?>

	<div class="container">
		<?php if ( $is_section ) : ?>
			<div class="content-wrap wide section-layout">
				<?php iwla_subpage_nav(); ?>
				<div class="entry-content">
					<?php the_content(); ?>
				</div>
			</div>
		<?php else : ?>
			<div class="content-wrap">
				<div class="entry-content">
					<?php the_content(); ?>
				</div>
			</div>
		<?php endif; ?>
	</div>

	<?php
endwhile;

get_footer();
