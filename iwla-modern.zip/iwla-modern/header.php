<?php
/**
 * Header template.
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main">Skip to content</a>

<div class="topbar">
  <div class="container">
    <span class="topbar-status"><?php echo iwla_topbar_status_html(); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
    <span class="topbar-contact">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1.1-.3 1.2.4 2.5.6 3.8.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C11.6 21 3 12.4 3 2.1c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.6.6 3.8.1.4 0 .8-.3 1.1L6.6 10.8Z"/></svg>
      703-631-4495 &nbsp;&middot;&nbsp; <a href="<?php echo esc_url( home_url( '/membership/' ) ); ?>">2027 renewals open Oct 15</a>
    </span>
  </div>
</div>

<header class="site-header">
  <div class="container nav-row">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand">
      <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/logo-transparent.png' ); ?>" alt="Arlington-Fairfax Chapter, Izaak Walton League of America seal">
      <span>
        <span class="brand-text-main">Arlington-Fairfax Chapter</span>
        <span class="brand-text-sub">Izaak Walton League of America</span>
      </span>
    </a>
    <button class="nav-toggle" aria-label="Toggle navigation menu" aria-expanded="false" aria-controls="primary-menu">
      <span></span><span></span><span></span>
    </button>
    <nav class="main-nav" id="primary-menu" aria-label="Primary">
      <?php
      wp_nav_menu(
        array(
          'theme_location' => 'primary',
          'container'      => false,
          'walker'         => new IWLA_Nav_Walker(),
          'fallback_cb'    => false,
        )
      );
      ?>
      <a href="<?php echo esc_url( home_url( '/membership/' ) ); ?>" class="btn btn-primary nav-cta">Join / Renew</a>
    </nav>
  </div>
</header>
<main id="main">
