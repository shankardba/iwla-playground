<?php
/**
 * IWLA Modern theme functions.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'IWLA_THEME_VERSION', '0.8.3' );

require get_template_directory() . '/inc/documents.php';
require get_template_directory() . '/inc/events.php';
require get_template_directory() . '/inc/settings.php';
require get_template_directory() . '/inc/announcements.php';
require get_template_directory() . '/inc/courses.php';
require get_template_directory() . '/inc/calendar.php';
require get_template_directory() . '/inc/redirects.php';
require get_template_directory() . '/inc/roles.php';
if ( is_admin() ) {
	require get_template_directory() . '/inc/setup.php';
}

function iwla_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );

	register_nav_menus(
		array(
			'primary' => __( 'Primary Navigation', 'iwla-modern' ),
			'footer'  => __( 'Footer Explore Links', 'iwla-modern' ),
		)
	);
}
add_action( 'after_setup_theme', 'iwla_setup' );

function iwla_scripts() {
	wp_enqueue_style(
		'iwla-google-fonts',
		'https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 'iwla-modern-style', get_stylesheet_uri(), array(), IWLA_THEME_VERSION );
	wp_enqueue_script( 'iwla-modern-main', get_template_directory_uri() . '/assets/main.js', array(), IWLA_THEME_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'iwla_scripts' );

/**
 * Minimal walker: adds dropdown-friendly classes/markup for top-level items with children.
 */
class IWLA_Nav_Walker extends Walker_Nav_Menu {
	public function start_lvl( &$output, $depth = 0, $args = null ) {
		$output .= '<ul class="sub-menu">';
	}

	public function end_lvl( &$output, $depth = 0, $args = null ) {
		$output .= '</ul>';
	}

	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$classes   = empty( $item->classes ) ? array() : (array) $item->classes;
		$has_children = in_array( 'menu-item-has-children', $classes, true );
		$li_classes = implode( ' ', array_filter( $classes ) );

		$output .= '<li class="' . esc_attr( $li_classes ) . '">';
		$output .= '<a href="' . esc_url( $item->url ) . '">' . esc_html( $item->title ) . '</a>';
		if ( $has_children ) {
			$output .= '<button class="sub-toggle" aria-label="' . esc_attr__( 'Show submenu', 'iwla-modern' ) . '" aria-expanded="false">&#9662;</button>';
		}
	}

	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		$output .= '</li>';
	}
}

/**
 * Small helper: render a breadcrumb for non-front pages.
 */
function iwla_breadcrumb() {
	if ( is_front_page() ) {
		return;
	}
	echo '<nav class="breadcrumb" aria-label="Breadcrumb"><a href="' . esc_url( home_url( '/' ) ) . '">Home</a>';
	if ( is_page() ) {
		global $post;
		$ancestors = array_reverse( get_post_ancestors( $post ) );
		foreach ( $ancestors as $ancestor_id ) {
			echo ' <span aria-hidden="true">/</span> <a href="' . esc_url( get_permalink( $ancestor_id ) ) . '">' . esc_html( get_the_title( $ancestor_id ) ) . '</a>';
		}
		echo ' <span aria-hidden="true">/</span> <span>' . esc_html( get_the_title() ) . '</span>';
	}
	echo '</nav>';
}

/**
 * Render child + sibling page navigation in a sidebar-style box for section landing pages.
 */
function iwla_subpage_nav() {
	global $post;
	if ( ! is_page() ) {
		return;
	}
	$parent_id = $post->post_parent ? $post->post_parent : $post->ID;
	$siblings  = get_pages(
		array(
			'parent'    => $parent_id,
			'sort_column' => 'menu_order',
		)
	);
	if ( empty( $siblings ) ) {
		return;
	}
	$parent_title = get_the_title( $parent_id );
	echo '<nav class="subpage-nav" aria-label="Section pages"><h2>' . esc_html( $parent_title ) . '</h2><ul>';
	if ( $post->post_parent ) {
		printf(
			'<li class="%s"><a href="%s">%s overview</a></li>',
			$post->ID === $parent_id ? 'current' : '',
			esc_url( get_permalink( $parent_id ) ),
			esc_html( $parent_title )
		);
	}
	foreach ( $siblings as $sibling ) {
		printf(
			'<li class="%s"><a href="%s">%s</a></li>',
			$post->ID === $sibling->ID ? 'current' : '',
			esc_url( get_permalink( $sibling->ID ) ),
			esc_html( $sibling->post_title )
		);
	}
	echo '</ul></nav>';
}

/**
 * Meta description and Open Graph / Twitter card tags (page excerpt, featured image).
 */
function iwla_seo_meta() {
	if ( is_admin() ) {
		return;
	}
	$title = wp_get_document_title();
	$desc  = '';
	$image = get_template_directory_uri() . '/assets/img/og-share.jpg?v=' . IWLA_THEME_VERSION;
	$img_w = 1200;
	$img_h = 630;
	if ( is_singular() ) {
		$desc = has_excerpt() ? get_the_excerpt() : '';
		if ( has_post_thumbnail() ) {
			$image = get_the_post_thumbnail_url( null, 'large' );
			$img_w = 0;
		}
	}
	if ( ! $desc ) {
		$desc = get_bloginfo( 'description' );
	}
	$desc = wp_strip_all_tags( $desc );
	if ( is_search() || is_404() ) {
		echo '<meta name="robots" content="noindex,follow">' . "\n";
	}
	echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	echo '<meta property="og:type" content="website">' . "\n";
	echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
	echo '<meta property="og:url" content="' . esc_url( is_singular() ? get_permalink() : home_url( '/' ) ) . '">' . "\n";
	echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n";
	if ( $img_w ) {
		echo '<meta property="og:image:width" content="' . (int) $img_w . '">' . "\n";
		echo '<meta property="og:image:height" content="' . (int) $img_h . '">' . "\n";
	}
	echo '<meta property="og:image:alt" content="' . esc_attr( get_bloginfo( 'name' ) . ': conserving land, water and wildlife in Northern Virginia' ) . '">' . "\n";
	echo '<meta name="theme-color" content="#163023">' . "\n";
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
}
add_action( 'wp_head', 'iwla_seo_meta', 5 );

/**
 * Open the connection to Google Fonts early.
 */
function iwla_font_preconnect( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type ) {
		$urls[] = 'https://fonts.googleapis.com';
		$urls[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' => 'anonymous' );
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'iwla_font_preconnect', 10, 2 );

/**
 * Trim default WordPress front-end extras this theme doesn't use (emoji
 * script, block-library styles) to keep pages light.
 */
function iwla_trim_frontend() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
}
add_action( 'init', 'iwla_trim_frontend' );

function iwla_dequeue_block_styles() {
	wp_dequeue_style( 'wp-block-library' );
	wp_dequeue_style( 'wp-block-library-theme' );
	wp_dequeue_style( 'global-styles' );
	wp_dequeue_style( 'classic-theme-styles' );
}
add_action( 'wp_enqueue_scripts', 'iwla_dequeue_block_styles', 100 );

/**
 * Browser-tab and phone home-screen icon: the chapter seal, used on the site,
 * the admin and the login page unless an admin sets their own Site Icon
 * (Appearance > Customize > Site Identity), which then takes over.
 */
function iwla_fallback_icons() {
	if ( has_site_icon() ) {
		return;
	}
	$u = get_template_directory_uri() . '/assets/img/';
	$v = '?v=' . IWLA_THEME_VERSION;
	echo '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url( $u . 'site-icon-32.png' . $v ) . '">' . "\n";
	echo '<link rel="icon" type="image/png" sizes="192x192" href="' . esc_url( $u . 'site-icon-192.png' . $v ) . '">' . "\n";
	echo '<link rel="apple-touch-icon" href="' . esc_url( $u . 'apple-touch-icon.png' . $v ) . '">' . "\n";
}
add_action( 'wp_head', 'iwla_fallback_icons', 4 );
add_action( 'admin_head', 'iwla_fallback_icons', 4 );
add_action( 'login_head', 'iwla_fallback_icons', 4 );
