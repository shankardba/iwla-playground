<?php
/**
 * IWLA Modern theme functions.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'IWLA_THEME_VERSION', '0.3.1' );

require get_template_directory() . '/inc/documents.php';
require get_template_directory() . '/inc/events.php';

function iwla_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );

	register_nav_menus(
		array(
			'primary' => __( 'Primary Navigation', 'iwla-modern' ),
			'footer'  => __( 'Footer Explore Links', 'iwla-modern' ),
		)
	);
}
add_action( 'after_setup_theme', 'iwla_setup' );

function iwla_scripts() {
	wp_enqueue_style(
		'iwla-google-fonts',
		'https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600;700&family=Inter:wght@400;500;600;700;800&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 'iwla-modern-style', get_stylesheet_uri(), array(), IWLA_THEME_VERSION );
	wp_enqueue_script( 'iwla-modern-main', get_template_directory_uri() . '/assets/main.js', array(), IWLA_THEME_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'iwla_scripts' );

/**
 * Minimal walker: adds dropdown-friendly classes/markup for top-level items with children.
 */
class IWLA_Nav_Walker extends Walker_Nav_Menu {
	public function start_lvl( &$output, $depth = 0, $args = null ) {
		$output .= '<ul class="sub-menu">';
	}

	public function end_lvl( &$output, $depth = 0, $args = null ) {
		$output .= '</ul>';
	}

	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$classes   = empty( $item->classes ) ? array() : (array) $item->classes;
		$has_children = in_array( 'menu-item-has-children', $classes, true );
		$li_classes = implode( ' ', array_filter( $classes ) );

		$output .= '<li class="' . esc_attr( $li_classes ) . '">';
		$output .= '<a href="' . esc_url( $item->url ) . '">' . esc_html( $item->title ) . '</a>';
		if ( $has_children ) {
			$output .= '<button class="sub-toggle" aria-label="' . esc_attr__( 'Show submenu', 'iwla-modern' ) . '" aria-expanded="false">&#9662;</button>';
		}
	}

	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		$output .= '</li>';
	}
}

/**
 * Small helper: render a breadcrumb for non-front pages.
 */
function iwla_breadcrumb() {
	if ( is_front_page() ) {
		return;
	}
	echo '<nav class="breadcrumb" aria-label="Breadcrumb"><a href="' . esc_url( home_url( '/' ) ) . '">Home</a>';
	if ( is_page() ) {
		global $post;
		$ancestors = array_reverse( get_post_ancestors( $post ) );
		foreach ( $ancestors as $ancestor_id ) {
			echo ' <span aria-hidden="true">/</span> <a href="' . esc_url( get_permalink( $ancestor_id ) ) . '">' . esc_html( get_the_title( $ancestor_id ) ) . '</a>';
		}
		echo ' <span aria-hidden="true">/</span> <span>' . esc_html( get_the_title() ) . '</span>';
	}
	echo '</nav>';
}

/**
 * Render child + sibling page navigation in a sidebar-style box for section landing pages.
 */
function iwla_subpage_nav() {
	global $post;
	if ( ! is_page() ) {
		return;
	}
	$parent_id = $post->post_parent ? $post->post_parent : $post->ID;
	$siblings  = get_pages(
		array(
			'parent'    => $parent_id,
			'sort_column' => 'menu_order',
		)
	);
	if ( empty( $siblings ) ) {
		return;
	}
	$parent_title = get_the_title( $parent_id );
	echo '<nav class="subpage-nav" aria-label="Section pages"><h2>' . esc_html( $parent_title ) . '</h2><ul>';
	if ( $post->post_parent ) {
		printf(
			'<li class="%s"><a href="%s">%s overview</a></li>',
			$post->ID === $parent_id ? 'current' : '',
			esc_url( get_permalink( $parent_id ) ),
			esc_html( $parent_title )
		);
	}
	foreach ( $siblings as $sibling ) {
		printf(
			'<li class="%s"><a href="%s">%s</a></li>',
			$post->ID === $sibling->ID ? 'current' : '',
			esc_url( get_permalink( $sibling->ID ) ),
			esc_html( $sibling->post_title )
		);
	}
	echo '</ul></nav>';
}
