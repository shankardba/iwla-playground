# Project instructions

## ClaudeHub knowledge base

- Do **not** read or recall anything from ClaudeHub (the `claude-hub` MCP server's cross-project knowledge base — `kb_search`, `kb_read`, `kb_list`, etc.) for this project. Treat it as unavailable.
- Do **not** write to ClaudeHub without the user's **explicit approval** for that specific entry.
- When approved, only record general **webapp conventions, architecture, and technical patterns** (e.g. theme structure, CPT/meta-box patterns, build/deploy approach) — never anything about the **content** of the site (chapter programs, events, page copy, photos, contact info, etc.).
