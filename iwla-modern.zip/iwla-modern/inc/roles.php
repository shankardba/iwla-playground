<?php
/**
 * "Chapter Editor" role: lets volunteers manage Documents, Events,
 * Announcements and Courses (and upload files) without being able to change
 * pages, themes, plugins, users or Chapter Settings.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function iwla_ensure_editor_role() {
	if ( get_option( 'iwla_roles_version' ) === '1' ) {
		return;
	}
	remove_role( 'iwla_editor' );
	add_role( 'iwla_editor', 'Chapter Editor', array(
		'read'                   => true,
		'upload_files'           => true,
		'edit_posts'             => true,
		'edit_published_posts'   => true,
		'edit_others_posts'      => true,
		'publish_posts'          => true,
		'delete_posts'           => true,
		'delete_published_posts' => true,
		'delete_others_posts'    => true,
		'manage_categories'      => true,
	) );
	update_option( 'iwla_roles_version', '1' );
}
add_action( 'init', 'iwla_ensure_editor_role' );
