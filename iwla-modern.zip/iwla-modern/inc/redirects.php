<?php
/**
 * 301 redirects from the legacy site's page addresses (e.g. /rifle-and-pistol-range/)
 * to their new locations. Only runs when WordPress would otherwise show a 404,
 * so it never overrides a real page.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function iwla_legacy_redirect_map() {
	return array(
		// Home
		'home' => '/', 'home-2' => '/', 'testing' => '/membership/',
		// Calendar
		'chapter-calendars' => '/calendar/', 'chapter-calendar-new' => '/calendar/', 'my-calendar' => '/calendar/', 'calendar-of-events' => '/calendar/',
		// About / information
		'about' => '/about/', 'location' => '/contact/', 'chapter-campus-map' => '/about/campus-map/', 'chapter-photo-gallery' => '/about/campus-map/',
		'bylaws' => '/governance/#bylaws', 'chapter-election-information' => '/governance/#elections',
		'officersanddirectors' => '/governance/#officers', 'other-chapter-contact-information' => '/governance/#contacts', 'chapter-contacts' => '/governance/#contacts',
		'shenandoah-county-property' => '/about/', 'chapter-covid-19-information' => '/about/', 'email-from-iwla-virginia-president' => '/about/',
		'general-membership-meeting-june-16-2020' => '/resources/', 'caretaker-rfp-october-2019' => '/about/', 'caretaker-rfp-fall-2021' => '/about/',
		// Membership
		'membership-information' => '/membership/#faq', 'membership-general-information' => '/membership/', 'online-membership-renewal' => '/membership/',
		'membership-renewal-2020' => '/membership/',
		// Ranges
		'rifle-and-pistol-range' => '/ranges/rifle-pistol/', 'rifle-pistol-range-rules' => '/ranges/rifle-pistol/', 'bullseye-pistol' => '/ranges/rifle-pistol/',
		'bull-run-muzzle-loaders' => '/ranges/rifle-pistol/', 'skeet-trap-range' => '/ranges/skeet-trap/', 'skeet-trap-range-rules' => '/ranges/skeet-trap/',
		'winter-league' => '/ranges/skeet-trap/#winter-league', 'crush-n-clays-st-jude-childrens-research-hospital-charity-event' => '/ranges/skeet-trap/',
		'target-archery' => '/ranges/target-archery/', 'archery-range-rules' => '/ranges/target-archery/', 'target-archery-tournaments' => '/ranges/target-archery/',
		'archery-tournament-fees' => '/ranges/target-archery/', 'archery-development-programs' => '/ranges/target-archery/', '1452-2' => '/ranges/target-archery/',
		'archery-matches' => '/ranges/target-archery/', 'field-archery' => '/ranges/field-archery/', 'field-archery-range-rules' => '/ranges/field-archery/',
		'cub-run-archers' => '/ranges/cub-run-archers/', 'cub-run-archery-bylaws' => '/ranges/cub-run-archers/', 'cub-run-archers-meeting-minutes' => '/ranges/cub-run-archers/',
		'archery-201-course-payment' => '/education-training/', 'archery-201-paypal' => '/education-training/',
		'air-range-rules' => '/ranges/air-range/',
		'facilities-use-request' => '/ranges/facilities-use/',
		// Education & training
		'education-and-training-2' => '/education-training/', 'education-training-course-schedule' => '/education-training/',
		'education-and-training' => '/education-training/', 'nra-courses' => '/education-training/', 'education-training-facility-trust' => '/education-training/#etft',
		// Conservation
		'conservationinaction' => '/conservation/', 'conservationinaction-2' => '/conservation/', 'ems' => '/conservation/',
		// Youth
		'youth' => '/youth/', 'youth-chapter' => '/youth/', 'youth-contact-list' => '/youth/', 'high-school-air-rifle-teams' => '/youth/',
		'nova-sharpshooter-youth-pistol-program' => '/youth/', 'shotgun-youth-program' => '/youth/', 'scouting' => '/youth/', 'women-on-target' => '/youth/',
		// Resources
		'awards-grants' => '/about/awards-grants/', 'award-grants-test' => '/about/awards-grants/', 'iwla-scholarship' => '/resources/#scholarship', 'newsletters' => '/resources/',
		'newslettersarchived' => '/resources/', 'minutes' => '/resources/', 'meeting-minutes' => '/resources/', 'minutesarchived' => '/resources/',
		'knife-club' => '/resources/', 'firewood-for-sale' => '/resources/', 'outdoor-america-magazine' => '/resources/',
	);
}

/**
 * Addresses that existed on the new site before the November 2026 reorganisation.
 */
function iwla_moved_page_map() {
	return array(
		'ranges/archery'                  => '/ranges/target-archery/',
		'ranges/archery/target-archery'   => '/ranges/target-archery/',
		'ranges/archery/field-archery'    => '/ranges/field-archery/',
		'ranges/archery/cub-run-archers'  => '/ranges/cub-run-archers/',
		'ranges/education-training'       => '/education-training/',
	);
}

function iwla_legacy_redirects() {
	if ( ! is_404() ) {
		return;
	}
	$req = rawurldecode( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ) );
	if ( false !== ( $pos = strpos( $req, '/wp-content/uploads/' ) ) ) {
		iwla_redirect_legacy_file( strtolower( str_replace( '/./', '/', substr( $req, $pos + strlen( '/wp-content/uploads/' ) ) ) ) );
	}
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' );
	$home = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
	if ( $home && 0 === strpos( $path, $home ) ) {
		$path = trim( substr( $path, strlen( $home ) ), '/' );
	}
	$moved = iwla_moved_page_map();
	if ( isset( $moved[ $path ] ) ) {
		wp_safe_redirect( home_url( $moved[ $path ] ), 301 );
		exit;
	}
	if ( '' === $path || false !== strpos( $path, '/' ) ) {
		return;
	}
	$map = iwla_legacy_redirect_map();
	if ( isset( $map[ $path ] ) ) {
		wp_safe_redirect( home_url( $map[ $path ] ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'iwla_legacy_redirects' );

/**
 * Old document addresses (e.g. /wp-content/uploads/iwla/Minutes/Archived/2019/12-17-2019-GM.pdf)
 * go to the document's Google Drive link.
 */
function iwla_redirect_legacy_file( $path_lc ) {
	$docs = get_posts( array(
		'post_type'      => 'iwla_document',
		'posts_per_page' => 1,
		'meta_key'       => '_iwla_doc_legacy_lc',
		'meta_value'     => $path_lc,
	) );
	if ( ! $docs ) {
		$aliases = json_decode( (string) file_get_contents( get_template_directory() . '/data/document-aliases.json' ), true );
		foreach ( (array) $aliases as $old => $file ) {
			if ( strtolower( $old ) === $path_lc && ( $doc = iwla_doc_find_by_file( $file ) ) ) {
				$docs = array( $doc );
			}
		}
	}
	if ( $docs ) {
		$url = get_post_meta( $docs[0]->ID, '_iwla_doc_url', true );
		if ( $url ) {
			wp_redirect( $url, 301 );
			exit;
		}
	}
}
