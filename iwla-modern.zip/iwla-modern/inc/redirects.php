<?php
/**
 * 301 redirects from the legacy site's page addresses (e.g. /rifle-and-pistol-range/)
 * to their new locations. Only runs when WordPress would otherwise show a 404,
 * so it never overrides a real page.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function iwla_legacy_redirect_map() {
	return array(
		// Home
		'home' => '/', 'home-2' => '/', 'testing' => '/membership/',
		// Calendar
		'chapter-calendars' => '/calendar/', 'chapter-calendar-new' => '/calendar/', 'my-calendar' => '/calendar/', 'calendar-of-events' => '/calendar/',
		// About / information
		'about' => '/about/', 'location' => '/contact/', 'chapter-campus-map' => '/contact/', 'chapter-photo-gallery' => '/about/',
		'bylaws' => '/about/#governance', 'chapter-election-information' => '/about/#elections',
		'officersanddirectors' => '/contact/#officers', 'other-chapter-contact-information' => '/contact/#contacts', 'chapter-contacts' => '/contact/#contacts',
		'shenandoah-county-property' => '/about/', 'chapter-covid-19-information' => '/about/', 'email-from-iwla-virginia-president' => '/about/',
		'general-membership-meeting-june-16-2020' => '/resources/', 'caretaker-rfp-october-2019' => '/about/', 'caretaker-rfp-fall-2021' => '/about/',
		// Membership
		'membership-information' => '/membership/#faq', 'membership-general-information' => '/membership/', 'online-membership-renewal' => '/membership/',
		'membership-renewal-2020' => '/membership/',
		// Ranges
		'rifle-and-pistol-range' => '/ranges/rifle-pistol/', 'rifle-pistol-range-rules' => '/ranges/rifle-pistol/', 'bullseye-pistol' => '/ranges/rifle-pistol/',
		'bull-run-muzzle-loaders' => '/ranges/rifle-pistol/', 'skeet-trap-range' => '/ranges/skeet-trap/', 'skeet-trap-range-rules' => '/ranges/skeet-trap/',
		'winter-league' => '/ranges/skeet-trap/', 'crush-n-clays-st-jude-childrens-research-hospital-charity-event' => '/ranges/skeet-trap/',
		'target-archery' => '/ranges/archery/target-archery/', 'archery-range-rules' => '/ranges/archery/target-archery/', 'target-archery-tournaments' => '/ranges/archery/target-archery/',
		'archery-tournament-fees' => '/ranges/archery/target-archery/', 'archery-development-programs' => '/ranges/archery/', '1452-2' => '/ranges/archery/',
		'archery-matches' => '/ranges/archery/', 'field-archery' => '/ranges/archery/field-archery/', 'field-archery-range-rules' => '/ranges/archery/field-archery/',
		'cub-run-archers' => '/ranges/archery/cub-run-archers/', 'cub-run-archery-bylaws' => '/ranges/archery/cub-run-archers/', 'cub-run-archers-meeting-minutes' => '/ranges/archery/cub-run-archers/',
		'archery-201-course-payment' => '/ranges/education-training/', 'archery-201-paypal' => '/ranges/education-training/',
		'air-range-rules' => '/ranges/air-range/',
		'facilities-use-request' => '/ranges/facilities-use/',
		// Education & training
		'education-and-training-2' => '/ranges/education-training/', 'education-training-course-schedule' => '/ranges/education-training/',
		'education-and-training' => '/ranges/education-training/', 'nra-courses' => '/ranges/education-training/', 'education-training-facility-trust' => '/ranges/education-training/',
		// Conservation
		'conservationinaction' => '/conservation/', 'conservationinaction-2' => '/conservation/', 'ems' => '/conservation/',
		// Youth
		'youth' => '/youth/', 'youth-chapter' => '/youth/', 'youth-contact-list' => '/youth/', 'high-school-air-rifle-teams' => '/youth/',
		'nova-sharpshooter-youth-pistol-program' => '/youth/', 'shotgun-youth-program' => '/youth/', 'scouting' => '/youth/', 'women-on-target' => '/youth/',
		// Resources
		'awards-grants' => '/resources/#awards', 'award-grants-test' => '/resources/', 'iwla-scholarship' => '/resources/#scholarship', 'newsletters' => '/resources/',
		'newslettersarchived' => '/resources/', 'minutes' => '/resources/', 'meeting-minutes' => '/resources/', 'minutesarchived' => '/resources/',
		'knife-club' => '/resources/', 'firewood-for-sale' => '/resources/', 'outdoor-america-magazine' => '/resources/',
	);
}

function iwla_legacy_redirects() {
	if ( ! is_404() ) {
		return;
	}
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' );
	$home = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
	if ( $home && 0 === strpos( $path, $home ) ) {
		$path = trim( substr( $path, strlen( $home ) ), '/' );
	}
	if ( '' === $path || false !== strpos( $path, '/' ) ) {
		return;
	}
	$map = iwla_legacy_redirect_map();
	if ( isset( $map[ $path ] ) ) {
		wp_safe_redirect( home_url( $map[ $path ] ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'iwla_legacy_redirects' );
