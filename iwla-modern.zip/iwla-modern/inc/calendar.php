<?php
/**
 * Chapter calendar: reads one or more Google Calendar (iCal) feeds set under
 * Settings > Chapter Settings and shows them as a month grid or list with a
 * facility filter. Use the [iwla_calendar] shortcode on any page.
 *
 * The feed is the single source of truth; volunteers keep using Google
 * Calendar exactly as they do today.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function iwla_facility_codes() {
	return array(
		'AR'   => 'Sills Air Range',
		'AF'   => 'Athletic Field',
		'CAMP' => 'Camping',
		'FA'   => 'Field Archery',
		'FH'   => 'Field House',
		'LP'   => 'Large Pavilion',
		'RP'   => 'Rifle/Pistol Range',
		'SP'   => 'Small Pavilion',
		'ST'   => 'Skeet & Trap Range',
		'TA'   => 'Target Archery',
	);
}

function iwla_facility_from_title( $title ) {
	$aliases = array( 'R/P' => 'RP', 'S&T' => 'ST', 'S/T' => 'ST', 'T/A' => 'TA', 'F/A' => 'FA', 'A/R' => 'AR' );
	$codes   = iwla_facility_codes();
	if ( preg_match_all( '/\(([A-Za-z&\/]{1,5})\)/', $title, $m ) ) {
		foreach ( $m[1] as $raw ) {
			$c = strtoupper( $raw );
			$c = $aliases[ $c ] ?? $c;
			if ( isset( $codes[ $c ] ) ) {
				return $c;
			}
		}
	}
	return '';
}

/* ---------------- Fetching ---------------- */

function iwla_calendar_feeds() {
	$feeds = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) iwla_opt( 'calendar_feeds', '' ) ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$parts   = array_map( 'trim', explode( '|', $line, 2 ) );
		$feeds[] = array(
			'label' => count( $parts ) > 1 ? $parts[0] : '',
			'url'   => end( $parts ),
		);
	}
	return $feeds;
}

function iwla_fetch_ics( $url ) {
	$bust = (string) get_option( 'iwla_cal_bust', '0' );
	$key  = 'iwla_ics_' . md5( $url . $bust );
	$hit  = get_transient( $key );
	if ( false !== $hit ) {
		return $hit;
	}
	$body = false;
	// A feed hosted inside this site (e.g. a demo file) is read from disk.
	$content_url = content_url();
	if ( 0 === strpos( $url, $content_url ) ) {
		$path = WP_CONTENT_DIR . substr( $url, strlen( $content_url ) );
		$path = strtok( $path, '?' );
		if ( is_readable( $path ) ) {
			$body = file_get_contents( $path );
		}
	} else {
		$res = wp_remote_get( $url, array( 'timeout' => 10 ) );
		if ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) {
			$body = wp_remote_retrieve_body( $res );
		}
	}
	$stale_key = 'iwla_ics_stale_' . md5( $url );
	if ( false === $body || false === strpos( $body, 'BEGIN:VCALENDAR' ) ) {
		$stale = get_option( $stale_key );
		return $stale ? $stale : '';
	}
	set_transient( $key, $body, max( 1, (int) iwla_opt( 'calendar_cache', 15 ) ) * MINUTE_IN_SECONDS );
	update_option( $stale_key, $body, false );
	return $body;
}

/* ---------------- Parsing ---------------- */

function iwla_ics_unfold( $text ) {
	$text = str_replace( array( "\r\n", "\r" ), "\n", $text );
	return preg_replace( "/\n[ \t]/", '', $text );
}

function iwla_ics_unescape( $v ) {
	return str_replace( array( '\\n', '\\N', '\\,', '\\;', '\\\\' ), array( "\n", "\n", ',', ';', '\\' ), $v );
}

/**
 * @return array{0:DateTimeImmutable,1:bool} start/end value and all-day flag.
 */
function iwla_ics_datetime( $value, $params ) {
	$wp_tz = wp_timezone();
	if ( preg_match( '/^(\d{4})(\d{2})(\d{2})$/', $value, $m ) ) {
		return array( new DateTimeImmutable( "$m[1]-$m[2]-$m[3] 00:00:00", $wp_tz ), true );
	}
	if ( ! preg_match( '/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})(Z?)$/', $value, $m ) ) {
		return array( null, false );
	}
	$str = "$m[1]-$m[2]-$m[3] $m[4]:$m[5]:$m[6]";
	if ( 'Z' === $m[7] ) {
		$dt = new DateTimeImmutable( $str, new DateTimeZone( 'UTC' ) );
	} elseif ( preg_match( '/TZID=([^;:]+)/i', $params, $tz ) ) {
		try {
			$dt = new DateTimeImmutable( $str, new DateTimeZone( trim( $tz[1], '"' ) ) );
		} catch ( Exception $e ) {
			$dt = new DateTimeImmutable( $str, $wp_tz );
		}
	} else {
		$dt = new DateTimeImmutable( $str, $wp_tz );
	}
	return array( $dt->setTimezone( $wp_tz ), false );
}

function iwla_ics_parse( $ics ) {
	$ics    = iwla_ics_unfold( $ics );
	$events = array();
	if ( ! preg_match_all( '/BEGIN:VEVENT\n(.*?)\nEND:VEVENT/s', $ics, $blocks ) ) {
		return $events;
	}
	foreach ( $blocks[1] as $block ) {
		$ev = array( 'exdate' => array(), 'rrule' => '', 'recurrence_id' => '' );
		foreach ( explode( "\n", $block ) as $line ) {
			if ( false === strpos( $line, ':' ) ) {
				continue;
			}
			list( $left, $val ) = explode( ':', $line, 2 );
			$parts  = explode( ';', $left, 2 );
			$name   = strtoupper( $parts[0] );
			$params = $parts[1] ?? '';
			switch ( $name ) {
				case 'SUMMARY':
					$ev['title'] = iwla_ics_unescape( $val );
					break;
				case 'DESCRIPTION':
					$ev['desc'] = iwla_ics_unescape( $val );
					break;
				case 'LOCATION':
					$ev['loc'] = iwla_ics_unescape( $val );
					break;
				case 'UID':
					$ev['uid'] = $val;
					break;
				case 'STATUS':
					$ev['status'] = strtoupper( $val );
					break;
				case 'RRULE':
					$ev['rrule'] = $val;
					break;
				case 'DTSTART':
					list( $ev['start'], $ev['allday'] ) = iwla_ics_datetime( $val, $params );
					break;
				case 'DTEND':
					list( $ev['end'] ) = iwla_ics_datetime( $val, $params );
					break;
				case 'RECURRENCE-ID':
					list( $rid ) = iwla_ics_datetime( $val, $params );
					$ev['recurrence_id'] = $rid ? $rid->format( 'Y-m-d H:i' ) : '';
					break;
				case 'EXDATE':
					foreach ( explode( ',', $val ) as $x ) {
						list( $xd ) = iwla_ics_datetime( trim( $x ), $params );
						if ( $xd ) {
							$ev['exdate'][] = $xd->format( 'Y-m-d' );
						}
					}
					break;
			}
		}
		if ( empty( $ev['start'] ) || empty( $ev['title'] ) || ( isset( $ev['status'] ) && 'CANCELLED' === $ev['status'] ) ) {
			continue;
		}
		if ( empty( $ev['end'] ) ) {
			$ev['end'] = $ev['allday'] ? $ev['start']->modify( '+1 day' ) : $ev['start'];
		}
		$events[] = $ev;
	}
	return $events;
}

/**
 * Expand a recurring event into occurrence start dates within [$from, $to].
 * Supports DAILY/WEEKLY/MONTHLY/YEARLY with INTERVAL, COUNT, UNTIL, BYDAY
 * (including ordinals like 1TU, -1FR), BYMONTHDAY and BYMONTH.
 */
function iwla_ics_expand( $ev, DateTimeImmutable $from, DateTimeImmutable $to ) {
	$start = $ev['start'];
	if ( '' === $ev['rrule'] ) {
		return array( $start );
	}
	$r = array();
	foreach ( explode( ';', $ev['rrule'] ) as $kv ) {
		$p = explode( '=', $kv, 2 );
		if ( 2 === count( $p ) ) {
			$r[ strtoupper( $p[0] ) ] = $p[1];
		}
	}
	$freq     = $r['FREQ'] ?? 'WEEKLY';
	$interval = max( 1, (int) ( $r['INTERVAL'] ?? 1 ) );
	$count    = isset( $r['COUNT'] ) ? (int) $r['COUNT'] : 0;
	$until    = null;
	if ( isset( $r['UNTIL'] ) ) {
		list( $until ) = iwla_ics_datetime( strlen( $r['UNTIL'] ) === 8 ? $r['UNTIL'] : ( substr( $r['UNTIL'], -1 ) === 'Z' ? $r['UNTIL'] : $r['UNTIL'] . 'Z' ), '' );
		if ( $until ) {
			$until = $until->setTime( 23, 59, 59 );
		}
	}
	$dayMap  = array( 'SU' => 0, 'MO' => 1, 'TU' => 2, 'WE' => 3, 'TH' => 4, 'FR' => 5, 'SA' => 6 );
	$byday   = array();
	if ( ! empty( $r['BYDAY'] ) ) {
		foreach ( explode( ',', $r['BYDAY'] ) as $d ) {
			if ( preg_match( '/^([+-]?\d{1,2})?(SU|MO|TU|WE|TH|FR|SA)$/', $d, $m ) ) {
				$byday[] = array( '' === $m[1] ? 0 : (int) $m[1], $dayMap[ $m[2] ] );
			}
		}
	}
	$bymonthday = ! empty( $r['BYMONTHDAY'] ) ? array_map( 'intval', explode( ',', $r['BYMONTHDAY'] ) ) : array();
	$bymonth    = ! empty( $r['BYMONTH'] ) ? array_map( 'intval', explode( ',', $r['BYMONTH'] ) ) : array();

	$time = $start->format( 'H:i:s' );
	$tz   = $start->getTimezone();
	$mk   = function ( $y, $m, $d ) use ( $time, $tz ) {
		return new DateTimeImmutable( sprintf( '%04d-%02d-%02d %s', $y, $m, $d, $time ), $tz );
	};

	$out   = array();
	$n     = 0;
	$guard = 0;
	$sy    = (int) $start->format( 'Y' );
	$sm    = (int) $start->format( 'n' );

	$emit = function ( DateTimeImmutable $d ) use ( &$out, &$n, $count, $until, $start, $from, $to, $ev ) {
		if ( $d < $start ) {
			return true;
		}
		if ( $until && $d > $until ) {
			return false;
		}
		$n++;
		if ( $count && $n > $count ) {
			return false;
		}
		if ( $d > $to ) {
			return false;
		}
		if ( $d >= $from && ! in_array( $d->format( 'Y-m-d' ), $ev['exdate'], true ) ) {
			$out[] = $d;
		}
		return true;
	};

	if ( 'DAILY' === $freq ) {
		$d = $start;
		while ( $guard++ < 4000 && $emit( $d ) ) {
			$d = $d->modify( "+$interval day" );
		}
	} elseif ( 'WEEKLY' === $freq ) {
		$days = $byday ? array_unique( array_column( $byday, 1 ) ) : array( (int) $start->format( 'w' ) );
		sort( $days );
		$week0 = $start->modify( '-' . (int) $start->format( 'w' ) . ' day' ); // Sunday of start week
		$w     = 0;
		$go    = true;
		while ( $go && $guard++ < 2000 ) {
			$base = $week0->modify( '+' . ( $w * $interval ) . ' week' );
			foreach ( $days as $dow ) {
				$d = $base->modify( "+$dow day" );
				if ( ! $emit( $d ) ) {
					$go = false;
					break;
				}
			}
			$w++;
		}
	} elseif ( 'MONTHLY' === $freq ) {
		$mi = 0;
		$go = true;
		while ( $go && $guard++ < 1500 ) {
			$mm  = $sm - 1 + $mi * $interval;
			$y   = $sy + intdiv( $mm, 12 );
			$m   = ( $mm % 12 ) + 1;
			$dim = (int) cal_days_in_month_safe( $m, $y );
			$dates = array();
			if ( $byday ) {
				foreach ( $byday as $bd ) {
					list( $ord, $dow ) = $bd;
					$matches = array();
					for ( $day = 1; $day <= $dim; $day++ ) {
						if ( (int) gmdate( 'w', gmmktime( 0, 0, 0, $m, $day, $y ) ) === $dow ) {
							$matches[] = $day;
						}
					}
					if ( 0 === $ord ) {
						$dates = array_merge( $dates, $matches );
					} elseif ( $ord > 0 && isset( $matches[ $ord - 1 ] ) ) {
						$dates[] = $matches[ $ord - 1 ];
					} elseif ( $ord < 0 && isset( $matches[ count( $matches ) + $ord ] ) ) {
						$dates[] = $matches[ count( $matches ) + $ord ];
					}
				}
			} elseif ( $bymonthday ) {
				foreach ( $bymonthday as $md ) {
					$dates[] = $md > 0 ? $md : $dim + 1 + $md;
				}
			} else {
				$dates[] = (int) $start->format( 'j' );
			}
			sort( $dates );
			foreach ( $dates as $day ) {
				if ( $day < 1 || $day > $dim ) {
					continue;
				}
				if ( ! $emit( $mk( $y, $m, $day ) ) ) {
					$go = false;
					break;
				}
			}
			$mi++;
		}
	} elseif ( 'YEARLY' === $freq ) {
		$yi = 0;
		$go = true;
		while ( $go && $guard++ < 200 ) {
			$y = $sy + $yi * $interval;
			$m = $bymonth ? $bymonth[0] : $sm;
			$d = $bymonthday ? $bymonthday[0] : (int) $start->format( 'j' );
			if ( $d <= cal_days_in_month_safe( $m, $y ) && ! $emit( $mk( $y, $m, $d ) ) ) {
				break;
			}
			$yi++;
		}
	} else {
		$emit( $start );
	}
	return $out;
}

function cal_days_in_month_safe( $m, $y ) {
	return (int) gmdate( 't', gmmktime( 0, 0, 0, $m, 1, $y ) );
}

/**
 * All occurrences within [$from, $to], merged across feeds, sorted by start.
 */
function iwla_calendar_occurrences( DateTimeImmutable $from, DateTimeImmutable $to ) {
	$all = array();
	foreach ( iwla_calendar_feeds() as $feed ) {
		$ics = iwla_fetch_ics( $feed['url'] );
		if ( '' === $ics ) {
			continue;
		}
		$parsed    = iwla_ics_parse( $ics );
		$overrides = array();
		foreach ( $parsed as $ev ) {
			if ( $ev['recurrence_id'] ) {
				$overrides[ ( $ev['uid'] ?? '' ) . '|' . substr( $ev['recurrence_id'], 0, 10 ) ] = true;
			}
		}
		foreach ( $parsed as $ev ) {
			$dur = max( 0, $ev['end']->getTimestamp() - $ev['start']->getTimestamp() );
			// Look back far enough to catch multi-day events that began before the window.
			$look = $from->modify( '-' . max( 1, (int) ceil( $dur / DAY_IN_SECONDS ) ) . ' day' );
			foreach ( iwla_ics_expand( $ev, $look, $to ) as $occ ) {
				if ( ! $ev['recurrence_id'] && '' !== $ev['rrule'] && isset( $overrides[ ( $ev['uid'] ?? '' ) . '|' . $occ->format( 'Y-m-d' ) ] ) ) {
					continue;
				}
				$end = $occ->modify( '+' . $dur . ' seconds' );
				if ( $end < $from && $occ < $from ) {
					continue;
				}
				$title = trim( $ev['title'] );
				$all[] = array(
					'start'  => $occ,
					'end'    => $end,
					'allday' => ! empty( $ev['allday'] ),
					'title'  => $title,
					'desc'   => trim( $ev['desc'] ?? '' ),
					'loc'    => trim( $ev['loc'] ?? '' ),
					'code'   => iwla_facility_from_title( $title ),
					'closed' => (bool) preg_match( '/\bclosed\b/i', $title ),
					'feed'   => $feed['label'],
				);
			}
		}
	}
	usort( $all, function ( $a, $b ) {
		return array( $a['start']->getTimestamp(), $a['title'] ) <=> array( $b['start']->getTimestamp(), $b['title'] );
	} );
	return $all;
}

/* ---------------- Rendering ---------------- */

function iwla_cal_url( $args = array() ) {
	global $post;
	$base = $post ? get_permalink( $post ) : home_url( '/calendar/' );
	$cur  = array();
	foreach ( array( 'cal_m', 'cal_v' ) as $k ) {
		if ( isset( $_GET[ $k ] ) && '' !== $_GET[ $k ] ) {
			$cur[ $k ] = sanitize_text_field( wp_unslash( $_GET[ $k ] ) );
		}
	}
	$q = array_filter( array_merge( $cur, $args ), function ( $v ) {
		return null !== $v && '' !== $v;
	} );
	return esc_url( add_query_arg( $q, $base ) . '#calendar' );
}

function iwla_event_time_label( $o ) {
	if ( $o['allday'] ) {
		return 'All day';
	}
	$t = $o['start']->format( 'g:i a' );
	return str_replace( array( ':00 ', ' am', ' pm' ), array( ' ', ' a.m.', ' p.m.' ), $t );
}

function iwla_event_detail_html( $o ) {
	$html = '';
	if ( $o['code'] ) {
		$codes = iwla_facility_codes();
		$html .= '<p><strong>Where:</strong> ' . esc_html( $codes[ $o['code'] ] ) . '</p>';
	}
	if ( $o['loc'] ) {
		$html .= '<p>' . esc_html( $o['loc'] ) . '</p>';
	}
	if ( $o['desc'] ) {
		$html .= wpautop( make_clickable( esc_html( $o['desc'] ) ) );
	}
	return $html;
}

function iwla_calendar_shortcode( $atts ) {
	$atts  = shortcode_atts( array( 'view' => 'month' ), $atts, 'iwla_calendar' );
	$feeds = iwla_calendar_feeds();
	if ( ! $feeds ) {
		$msg = current_user_can( 'manage_options' )
			? '<p class="callout-inline"><em>No calendar feed is connected yet &mdash; add one under Settings &rarr; Chapter Settings. Showing featured events meanwhile.</em></p>'
			: '';
		return $msg . iwla_render_events_list( iwla_get_upcoming_events( -1 ) );
	}

	$view = isset( $_GET['cal_v'] ) ? sanitize_key( wp_unslash( $_GET['cal_v'] ) ) : $atts['view'];
	$view = in_array( $view, array( 'month', 'list' ), true ) ? $view : 'month';

	$tz    = wp_timezone();
	$today = new DateTimeImmutable( 'today', $tz );
	$ym    = isset( $_GET['cal_m'] ) && preg_match( '/^\d{4}-\d{2}$/', wp_unslash( $_GET['cal_m'] ) ) ? wp_unslash( $_GET['cal_m'] ) : $today->format( 'Y-m' );
	$first = new DateTimeImmutable( $ym . '-01 00:00:00', $tz );
	$last  = $first->modify( 'last day of this month' )->setTime( 23, 59, 59 );

	if ( 'list' === $view ) {
		$from = $first->format( 'Y-m' ) === $today->format( 'Y-m' ) ? $today : $first;
		$occ  = iwla_calendar_occurrences( $from, $last );
	} else {
		$occ = iwla_calendar_occurrences( $first, $last );
	}

	$prev = $first->modify( '-1 month' )->format( 'Y-m' );
	$next = $first->modify( '+1 month' )->format( 'Y-m' );

	ob_start();
	echo '<div class="iwla-cal" id="calendar">';
	echo '<div class="cal-bar"><div class="cal-nav">';
	echo '<a class="btn btn-outline-dark btn-sm" href="' . iwla_cal_url( array( 'cal_m' => $prev ) ) . '" aria-label="Previous month">&larr;</a>';
	echo '<h2 class="cal-month">' . esc_html( $first->format( 'F Y' ) ) . '</h2>';
	echo '<a class="btn btn-outline-dark btn-sm" href="' . iwla_cal_url( array( 'cal_m' => $next ) ) . '" aria-label="Next month">&rarr;</a>';
	echo '<a class="btn btn-outline-dark btn-sm" href="' . iwla_cal_url( array( 'cal_m' => '' ) ) . '">Today</a>';
	echo '</div><div class="cal-views">';
	echo '<a class="' . ( 'month' === $view ? 'on' : '' ) . '" href="' . iwla_cal_url( array( 'cal_v' => 'month' ) ) . '">Month</a>';
	echo '<a class="' . ( 'list' === $view ? 'on' : '' ) . '" href="' . iwla_cal_url( array( 'cal_v' => 'list' ) ) . '">List</a>';
	echo '</div></div>';

	echo '<div class="cal-layout">';
	echo iwla_calendar_legend_html();
	echo '<div class="cal-main">';

	if ( 'list' === $view ) {
		if ( ! $occ ) {
			echo '<p><em>Nothing is scheduled for this month.</em></p>';
		}
		$cur_day = '';
		foreach ( $occ as $o ) {
			$dkey = $o['start']->format( 'Y-m-d' );
			if ( $dkey !== $cur_day ) {
				if ( '' !== $cur_day ) {
					echo '</div>';
				}
				echo '<div class="cal-day"><h3>' . esc_html( $o['start']->format( 'l, F j' ) ) . '</h3>';
				$cur_day = $dkey;
			}
			iwla_cal_event_html( $o, true );
		}
		if ( '' !== $cur_day ) {
			echo '</div>';
		}
	} else {
		$by_day = array();
		foreach ( $occ as $o ) {
			$d = clone $o['start'];
			$e = $o['allday'] ? $o['end']->modify( '-1 second' ) : $o['end'];
			$span = 0;
			while ( $d->format( 'Y-m-d' ) <= $e->format( 'Y-m-d' ) && $span++ < 31 ) {
				$by_day[ $d->format( 'Y-m-d' ) ][] = $o;
				$d = $d->modify( '+1 day' );
			}
		}
		$lead  = (int) $first->format( 'w' );
		$dim   = (int) $first->format( 't' );
		$cells = (int) ceil( ( $lead + $dim ) / 7 ) * 7;
		echo '<div class="cal-grid"><div class="cal-dow" aria-hidden="true">';
		foreach ( array( 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' ) as $dn ) {
			echo '<span>' . $dn . '</span>';
		}
		echo '</div><div class="cal-cells">';
		for ( $i = 0; $i < $cells; $i++ ) {
			$dnum = $i - $lead + 1;
			if ( $dnum < 1 || $dnum > $dim ) {
				echo '<div class="cal-cell void" aria-hidden="true"></div>';
				continue;
			}
			$dk    = sprintf( '%s-%02d', $first->format( 'Y-m' ), $dnum );
			$cls   = 'cal-cell' . ( $dk === $today->format( 'Y-m-d' ) ? ' today' : '' ) . ( empty( $by_day[ $dk ] ) ? ' empty' : '' );
			$stamp = strtotime( $dk . ' 12:00:00 UTC' );
			echo '<div class="' . $cls . '"><span class="num"><span class="wd">' . esc_html( gmdate( 'D', $stamp ) ) . ' </span>' . $dnum . '</span>';
			foreach ( $by_day[ $dk ] ?? array() as $o ) {
				iwla_cal_event_html( $o, false );
			}
			echo '</div>';
		}
		echo '</div></div>';
	}

	echo '</div></div>'; // .cal-main, .cal-layout
	echo '<p class="cal-sub">Always check the calendar before you drive out &mdash; cancellations and closures are added as soon as they are known.';
	$first_feed = $feeds[0]['url'];
	if ( 0 !== strpos( $first_feed, content_url() ) ) {
		echo ' <a href="' . esc_url( str_replace( 'https://', 'webcal://', $first_feed ) ) . '">Subscribe in your calendar app</a>.';
	}
	echo '</p></div>';
	return ob_get_clean();
}
add_shortcode( 'iwla_calendar', 'iwla_calendar_shortcode' );

function iwla_calendar_legend_html() {
	$out  = '<aside class="cal-legend-panel" aria-label="Facility legend"><h3>Facilities</h3>';
	$out .= '<p class="cal-hint">Select one or more to highlight them on the calendar.</p><ul>';
	foreach ( iwla_facility_codes() as $code => $name ) {
		$out .= '<li><button type="button" class="leg f-' . esc_attr( strtolower( $code ) ) . '" data-code="' . esc_attr( $code ) . '" aria-pressed="false"><span class="sw"></span><span class="lbl"><strong>' . esc_html( $code ) . '</strong> ' . esc_html( $name ) . '</span></button></li>';
	}
	$out .= '</ul><button type="button" class="leg-clear" hidden>Clear highlights</button></aside>';
	return $out;
}

function iwla_cal_event_html( $o, $show_day ) {
	$cls   = 'cal-ev' . ( $o['closed'] ? ' closed' : '' ) . ( $o['code'] ? ' f-' . strtolower( $o['code'] ) : '' );
	$time  = iwla_event_time_label( $o );
	$title = esc_html( $o['title'] );
	$det   = iwla_event_detail_html( $o );
	if ( $det ) {
		echo '<details class="' . $cls . '" data-code="' . esc_attr( $o['code'] ) . '"><summary><span class="t">' . esc_html( $time ) . '</span> ' . $title . '</summary><div class="cal-det">' . $det . '</div></details>';
	} else {
		echo '<div class="' . $cls . '" data-code="' . esc_attr( $o['code'] ) . '"><span class="t">' . esc_html( $time ) . '</span> ' . $title . '</div>';
	}
}
