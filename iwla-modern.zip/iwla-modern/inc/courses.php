<?php
/**
 * "Course" content type: the Education & Training schedule (NRA courses etc.).
 * Admins add a course with date, cost and optional registration / payment /
 * gun-rental links; the [iwla_courses] shortcode lists upcoming ones and
 * drops each automatically once its date has passed.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function iwla_register_course_type() {
	register_post_type( 'iwla_course', array(
		'labels' => array(
			'name'          => 'Courses',
			'singular_name' => 'Course',
			'add_new_item'  => 'Add New Course',
			'edit_item'     => 'Edit Course',
			'all_items'     => 'All Courses',
			'menu_name'     => 'Courses',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'menu_icon'       => 'dashicons-welcome-learn-more',
		'menu_position'   => 22,
		'supports'        => array( 'title', 'editor' ),
		'capability_type' => 'post',
		'hierarchical'    => false,
	) );
}
add_action( 'init', 'iwla_register_course_type' );

function iwla_course_fields() {
	return array(
		'_iwla_course_date'     => array( 'Start date', 'date' ),
		'_iwla_course_end_date' => array( 'End date (multi-day only)', 'date' ),
		'_iwla_course_cost'     => array( 'Cost (e.g. $100)', 'text' ),
		'_iwla_course_reg'      => array( 'Registration link', 'url' ),
		'_iwla_course_pay'      => array( 'Payment (PayPal) link', 'url' ),
		'_iwla_course_rental'   => array( 'Gun rental fee link (optional)', 'url' ),
	);
}

function iwla_course_meta_box() {
	add_meta_box( 'iwla_course_details', 'Course Details', 'iwla_course_meta_box_html', 'iwla_course', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'iwla_course_meta_box' );

function iwla_course_meta_box_html( $post ) {
	wp_nonce_field( 'iwla_course_save', 'iwla_course_nonce' );
	foreach ( iwla_course_fields() as $key => $def ) {
		$val = get_post_meta( $post->ID, $key, true );
		printf(
			'<p><label for="%1$s"><strong>%2$s</strong></label><br><input type="%3$s" id="%1$s" name="%1$s" value="%4$s" %5$s></p>',
			esc_attr( $key ),
			esc_html( $def[0] ),
			esc_attr( $def[1] ),
			esc_attr( $val ),
			'url' === $def[1] ? 'style="width:100%;max-width:560px;" placeholder="https://…"' : ( 'text' === $def[1] ? 'class="regular-text"' : '' )
		);
	}
	echo '<p class="description">Leave a link blank to hide that column entry. The text box above is optional notes shown under the course title.</p>';
}

function iwla_course_save_meta( $post_id ) {
	if ( ! isset( $_POST['iwla_course_nonce'] ) || ! wp_verify_nonce( $_POST['iwla_course_nonce'], 'iwla_course_save' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( iwla_course_fields() as $key => $def ) {
		$v = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : '';
		if ( 'url' === $def[1] ) {
			$v = esc_url_raw( $v );
		} elseif ( 'date' === $def[1] ) {
			$v = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : '';
		} else {
			$v = sanitize_text_field( $v );
		}
		update_post_meta( $post_id, $key, $v );
	}
}
add_action( 'save_post_iwla_course', 'iwla_course_save_meta' );

function iwla_course_admin_columns( $cols ) {
	$cols['iwla_course_date'] = 'Date';
	$cols['iwla_course_cost'] = 'Cost';
	return $cols;
}
add_filter( 'manage_iwla_course_posts_columns', 'iwla_course_admin_columns' );

function iwla_course_admin_column_content( $column, $post_id ) {
	if ( 'iwla_course_date' === $column ) {
		echo esc_html( get_post_meta( $post_id, '_iwla_course_date', true ) );
	} elseif ( 'iwla_course_cost' === $column ) {
		echo esc_html( get_post_meta( $post_id, '_iwla_course_cost', true ) );
	}
}
add_action( 'manage_iwla_course_posts_custom_column', 'iwla_course_admin_column_content', 10, 2 );

function iwla_courses_shortcode() {
	$courses = get_posts( array(
		'post_type'      => 'iwla_course',
		'posts_per_page' => -1,
		'meta_key'       => '_iwla_course_date',
		'orderby'        => 'meta_value',
		'order'          => 'ASC',
	) );
	$today   = current_time( 'Y-m-d' );
	$courses = array_values( array_filter( $courses, function ( $c ) use ( $today ) {
		$end = get_post_meta( $c->ID, '_iwla_course_end_date', true ) ?: get_post_meta( $c->ID, '_iwla_course_date', true );
		return $end >= $today;
	} ) );
	if ( empty( $courses ) ) {
		return '<p><em>No courses are scheduled right now &mdash; check back soon or contact the Director of Education &amp; Training.</em></p>';
	}
	$link = function ( $url, $label ) {
		return $url ? '<a class="btn btn-outline-dark btn-sm" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $label ) . '</a>' : '&mdash;';
	};
	$out = '<div class="table-scroll"><table class="course-table"><thead><tr><th>Date</th><th>Course</th><th>Cost</th><th>Register</th><th>Pay</th></tr></thead><tbody>';
	foreach ( $courses as $c ) {
		$d  = get_post_meta( $c->ID, '_iwla_course_date', true );
		$e  = get_post_meta( $c->ID, '_iwla_course_end_date', true );
		$ts = strtotime( $d );
		$te = $e ? strtotime( $e ) : false;
		$when = $ts ? date_i18n( 'M j', $ts ) . ( $te ? ' &ndash; ' . date_i18n( 'M j', $te ) : '' ) . ', ' . date_i18n( 'Y', $ts ) : '';
		$notes = trim( wp_strip_all_tags( $c->post_content ) );
		$rent  = get_post_meta( $c->ID, '_iwla_course_rental', true );
		$out .= '<tr><td>' . $when . '</td><td><strong>' . esc_html( get_the_title( $c ) ) . '</strong>';
		if ( $notes ) {
			$out .= '<br><span class="muted">' . esc_html( $notes ) . '</span>';
		}
		if ( $rent ) {
			$out .= '<br><a href="' . esc_url( $rent ) . '" target="_blank" rel="noopener">Gun rental fee</a>';
		}
		$out .= '</td><td>' . esc_html( get_post_meta( $c->ID, '_iwla_course_cost', true ) ) . '</td>';
		$out .= '<td>' . $link( get_post_meta( $c->ID, '_iwla_course_reg', true ), 'Register' ) . '</td>';
		$out .= '<td>' . $link( get_post_meta( $c->ID, '_iwla_course_pay', true ), 'Pay' ) . '</td></tr>';
	}
	return $out . '</tbody></table></div>';
}
add_shortcode( 'iwla_courses', 'iwla_courses_shortcode' );
