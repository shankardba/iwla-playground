<?php
/**
 * "Event" content type: the chapter calendar. Admins add/edit these from
 * wp-admin — Events in the sidebar — with no theme/code changes. The home
 * page and the Resources page's calendar section both pull from this list
 * automatically, always showing the soonest upcoming events first.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function iwla_register_event_type() {
	register_post_type( 'iwla_event', array(
		'labels' => array(
			'name'          => 'Events',
			'singular_name' => 'Event',
			'add_new_item'  => 'Add New Event',
			'edit_item'     => 'Edit Event',
			'all_items'     => 'All Events',
			'menu_name'     => 'Events',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'menu_icon'       => 'dashicons-calendar-alt',
		'supports'        => array( 'title', 'editor' ),
		'capability_type' => 'post',
		'hierarchical'    => false,
	) );
}
add_action( 'init', 'iwla_register_event_type' );

/* ---------------- Meta box: event date / location / link ---------------- */

function iwla_event_meta_box() {
	add_meta_box(
		'iwla_event_details',
		'Event Details',
		'iwla_event_meta_box_html',
		'iwla_event',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'iwla_event_meta_box' );

function iwla_event_meta_box_html( $post ) {
	wp_nonce_field( 'iwla_event_save', 'iwla_event_nonce' );
	$date     = get_post_meta( $post->ID, '_iwla_event_date', true );
	$end_date = get_post_meta( $post->ID, '_iwla_event_end_date', true );
	$location = get_post_meta( $post->ID, '_iwla_event_location', true );
	$link     = get_post_meta( $post->ID, '_iwla_event_link', true );
	?>
	<p>
		<label for="iwla_event_date"><strong>Event date</strong> (required — this is what's used to sort and to drop the event once it's past)</label><br>
		<input type="date" id="iwla_event_date" name="iwla_event_date" value="<?php echo esc_attr( $date ); ?>" required>
	</p>
	<p>
		<label for="iwla_event_end_date">End date <em>(optional — only for multi-day events)</em></label><br>
		<input type="date" id="iwla_event_end_date" name="iwla_event_end_date" value="<?php echo esc_attr( $end_date ); ?>">
	</p>
	<p>
		<label for="iwla_event_location">Location <em>(optional)</em></label><br>
		<input type="text" id="iwla_event_location" name="iwla_event_location" value="<?php echo esc_attr( $location ); ?>" style="width:100%;max-width:420px;" placeholder="e.g. Chapter Field House">
	</p>
	<p>
		<label for="iwla_event_link">More info / registration link <em>(optional — e.g. a SignUpGenius or flyer link)</em></label><br>
		<input type="url" id="iwla_event_link" name="iwla_event_link" value="<?php echo esc_attr( $link ); ?>" style="width:100%;max-width:640px;" placeholder="https://">
	</p>
	<p class="description">Use the description box below for the one-line summary shown on the site.</p>
	<?php
}

function iwla_event_save_meta( $post_id ) {
	if ( ! isset( $_POST['iwla_event_nonce'] ) || ! wp_verify_nonce( $_POST['iwla_event_nonce'], 'iwla_event_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$fields = array(
		'iwla_event_date'     => '_iwla_event_date',
		'iwla_event_end_date' => '_iwla_event_end_date',
		'iwla_event_location' => '_iwla_event_location',
	);
	foreach ( $fields as $field => $meta_key ) {
		if ( isset( $_POST[ $field ] ) ) {
			update_post_meta( $post_id, $meta_key, sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) );
		}
	}
	if ( isset( $_POST['iwla_event_link'] ) ) {
		update_post_meta( $post_id, '_iwla_event_link', esc_url_raw( wp_unslash( $_POST['iwla_event_link'] ) ) );
	}
}
add_action( 'save_post_iwla_event', 'iwla_event_save_meta' );

/* ---------------- Admin list columns ---------------- */

function iwla_event_admin_columns( $columns ) {
	$new = array();
	foreach ( $columns as $key => $label ) {
		$new[ $key ] = $label;
		if ( 'title' === $key ) {
			$new['iwla_event_date'] = 'Event Date';
		}
	}
	return $new;
}
add_filter( 'manage_iwla_event_posts_columns', 'iwla_event_admin_columns' );

function iwla_event_admin_column_content( $column, $post_id ) {
	if ( 'iwla_event_date' === $column ) {
		$date = get_post_meta( $post_id, '_iwla_event_date', true );
		echo $date ? esc_html( date_i18n( 'M j, Y', strtotime( $date ) ) ) : '—';
	}
}
add_action( 'manage_iwla_event_posts_custom_column', 'iwla_event_admin_column_content', 10, 2 );

function iwla_event_admin_sortable_columns( $columns ) {
	$columns['iwla_event_date'] = 'iwla_event_date';
	return $columns;
}
add_filter( 'manage_edit-iwla_event_sortable_columns', 'iwla_event_admin_sortable_columns' );

function iwla_event_admin_orderby( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( 'iwla_event_date' === $query->get( 'orderby' ) ) {
		$query->set( 'meta_key', '_iwla_event_date' );
		$query->set( 'orderby', 'meta_value' );
	}
}
add_action( 'pre_get_posts', 'iwla_event_admin_orderby' );

/* ---------------- Data + rendering helpers, shared by template + shortcode ---------------- */

/**
 * Get upcoming events, soonest first.
 *
 * @param int  $limit         Max events to return, -1 for all.
 * @param bool $include_past  Include events whose end/start date has passed.
 */
function iwla_get_upcoming_events( $limit = -1, $include_past = false ) {
	$args = array(
		'post_type'      => 'iwla_event',
		'posts_per_page' => $include_past ? $limit : -1,
		'meta_key'       => '_iwla_event_date',
		'orderby'        => 'meta_value',
		'order'          => 'ASC',
	);
	$events = get_posts( $args );

	if ( $include_past ) {
		return $events;
	}

	$today  = current_time( 'Y-m-d' );
	$future = array_values( array_filter( $events, function ( $event ) use ( $today ) {
		$end = get_post_meta( $event->ID, '_iwla_event_end_date', true );
		$end = $end ?: get_post_meta( $event->ID, '_iwla_event_date', true );
		return $end >= $today;
	} ) );

	if ( $limit > 0 ) {
		$future = array_slice( $future, 0, $limit );
	}

	return $future;
}

/**
 * Render a list of events using the existing .event-list/.event-row markup.
 */
function iwla_render_events_list( $events ) {
	if ( empty( $events ) ) {
		return '<p><em>No upcoming events are posted right now — check back soon.</em></p>';
	}

	$out = '<div class="event-list">';
	foreach ( $events as $event ) {
		$date = get_post_meta( $event->ID, '_iwla_event_date', true );
		$link = get_post_meta( $event->ID, '_iwla_event_link', true );
		$loc  = get_post_meta( $event->ID, '_iwla_event_location', true );
		$ts   = $date ? strtotime( $date ) : false;

		$title = esc_html( get_the_title( $event ) );
		if ( $link ) {
			$title = '<a href="' . esc_url( $link ) . '" target="_blank" rel="noopener">' . $title . '</a>';
		}

		$desc = trim( $event->post_content );
		$desc = $desc ? wpautop( $desc ) : '';
		if ( $loc ) {
			$desc .= '<p class="event-loc">' . esc_html( $loc ) . '</p>';
		}

		$out .= '<div class="event-row">';
		$out .= '<div class="event-date">';
		$out .= $ts ? '<span class="day">' . esc_html( date_i18n( 'j', $ts ) ) . '</span><span class="mon">' . esc_html( date_i18n( 'M Y', $ts ) ) . '</span>' : '';
		$out .= '</div>';
		$out .= '<div><h3>' . $title . '</h3>' . $desc . '</div>';
		$out .= '</div>';
	}
	$out .= '</div>';

	return $out;
}

/* ---------------- Shortcode: [iwla_events limit="3"] ---------------- */

function iwla_events_shortcode( $atts ) {
	$atts = shortcode_atts( array(
		'limit' => -1,
	), $atts, 'iwla_events' );

	$events = iwla_get_upcoming_events( (int) $atts['limit'] );
	return iwla_render_events_list( $events );
}
add_shortcode( 'iwla_events', 'iwla_events_shortcode' );
