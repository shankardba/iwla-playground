<?php
/**
 * "Announcement" content type: the notices at the top of the home page
 * (closures, renewal deadlines, changed hours). Admins add/edit these under
 * Announcements in wp-admin; each can have a start and end date so it
 * appears and disappears on its own.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function iwla_register_announcement_type() {
	register_post_type( 'iwla_announcement', array(
		'labels' => array(
			'name'          => 'Announcements',
			'singular_name' => 'Announcement',
			'add_new_item'  => 'Add New Announcement',
			'edit_item'     => 'Edit Announcement',
			'all_items'     => 'All Announcements',
			'menu_name'     => 'Announcements',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'menu_icon'       => 'dashicons-megaphone',
		'menu_position'   => 21,
		'supports'        => array( 'title', 'editor' ),
		'capability_type' => 'post',
		'hierarchical'    => false,
	) );
}
add_action( 'init', 'iwla_register_announcement_type' );

function iwla_announcement_meta_box() {
	add_meta_box( 'iwla_announcement_details', 'Display Options', 'iwla_announcement_meta_box_html', 'iwla_announcement', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'iwla_announcement_meta_box' );

function iwla_announcement_meta_box_html( $post ) {
	wp_nonce_field( 'iwla_announcement_save', 'iwla_announcement_nonce' );
	$sev   = get_post_meta( $post->ID, '_iwla_ann_severity', true ) ?: 'notice';
	$start = get_post_meta( $post->ID, '_iwla_ann_start', true );
	$end   = get_post_meta( $post->ID, '_iwla_ann_end', true );
	$link  = get_post_meta( $post->ID, '_iwla_ann_link', true );
	$label = get_post_meta( $post->ID, '_iwla_ann_link_label', true );
	?>
	<p>
		<label for="iwla_ann_severity"><strong>Style</strong></label><br>
		<select id="iwla_ann_severity" name="iwla_ann_severity">
			<option value="notice" <?php selected( $sev, 'notice' ); ?>>Notice (green)</option>
			<option value="alert" <?php selected( $sev, 'alert' ); ?>>Alert / closure (red)</option>
		</select>
	</p>
	<p>
		<label for="iwla_ann_start"><strong>Show from</strong> <em>(optional)</em></label>
		<input type="date" id="iwla_ann_start" name="iwla_ann_start" value="<?php echo esc_attr( $start ); ?>">
		&nbsp; <label for="iwla_ann_end"><strong>Hide after</strong> <em>(optional)</em></label>
		<input type="date" id="iwla_ann_end" name="iwla_ann_end" value="<?php echo esc_attr( $end ); ?>">
	</p>
	<p>
		<label for="iwla_ann_link"><strong>Link</strong> <em>(optional)</em></label><br>
		<input type="url" id="iwla_ann_link" name="iwla_ann_link" value="<?php echo esc_attr( $link ); ?>" style="width:100%;max-width:560px;" placeholder="https://…">
	</p>
	<p>
		<label for="iwla_ann_link_label"><strong>Link text</strong> <em>(optional, default "More information")</em></label><br>
		<input type="text" id="iwla_ann_link_label" name="iwla_ann_link_label" value="<?php echo esc_attr( $label ); ?>" class="regular-text">
	</p>
	<p class="description">The Title is the bold headline; the text box above is the detail line. Leave both dates blank to keep it up until you delete or unpublish it.</p>
	<?php
}

function iwla_announcement_save_meta( $post_id ) {
	if ( ! isset( $_POST['iwla_announcement_nonce'] ) || ! wp_verify_nonce( $_POST['iwla_announcement_nonce'], 'iwla_announcement_save' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$sev = isset( $_POST['iwla_ann_severity'] ) && 'alert' === $_POST['iwla_ann_severity'] ? 'alert' : 'notice';
	update_post_meta( $post_id, '_iwla_ann_severity', $sev );
	foreach ( array( 'start' => 'iwla_ann_start', 'end' => 'iwla_ann_end' ) as $k => $field ) {
		$v = isset( $_POST[ $field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) : '';
		update_post_meta( $post_id, '_iwla_ann_' . $k, preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : '' );
	}
	update_post_meta( $post_id, '_iwla_ann_link', isset( $_POST['iwla_ann_link'] ) ? esc_url_raw( wp_unslash( $_POST['iwla_ann_link'] ) ) : '' );
	update_post_meta( $post_id, '_iwla_ann_link_label', isset( $_POST['iwla_ann_link_label'] ) ? sanitize_text_field( wp_unslash( $_POST['iwla_ann_link_label'] ) ) : '' );
}
add_action( 'save_post_iwla_announcement', 'iwla_announcement_save_meta' );

function iwla_announcement_admin_columns( $cols ) {
	$cols['iwla_ann_window'] = 'Shows';
	return $cols;
}
add_filter( 'manage_iwla_announcement_posts_columns', 'iwla_announcement_admin_columns' );

function iwla_announcement_admin_column_content( $column, $post_id ) {
	if ( 'iwla_ann_window' !== $column ) {
		return;
	}
	$s = get_post_meta( $post_id, '_iwla_ann_start', true );
	$e = get_post_meta( $post_id, '_iwla_ann_end', true );
	echo esc_html( $s || $e ? ( $s ?: 'now' ) . ' to ' . ( $e ?: 'until removed' ) : 'Until removed' );
}
add_action( 'manage_iwla_announcement_posts_custom_column', 'iwla_announcement_admin_column_content', 10, 2 );

/**
 * Active announcements: alerts first, then newest first.
 */
function iwla_get_active_announcements( $limit = 5 ) {
	$items = get_posts( array( 'post_type' => 'iwla_announcement', 'posts_per_page' => -1, 'orderby' => 'date', 'order' => 'DESC' ) );
	$today = current_time( 'Y-m-d' );
	$items = array_values( array_filter( $items, function ( $p ) use ( $today ) {
		$s = get_post_meta( $p->ID, '_iwla_ann_start', true );
		$e = get_post_meta( $p->ID, '_iwla_ann_end', true );
		return ( ! $s || $s <= $today ) && ( ! $e || $e >= $today );
	} ) );
	usort( $items, function ( $a, $b ) {
		$sa = 'alert' === get_post_meta( $a->ID, '_iwla_ann_severity', true ) ? 0 : 1;
		$sb = 'alert' === get_post_meta( $b->ID, '_iwla_ann_severity', true ) ? 0 : 1;
		return $sa <=> $sb;
	} );
	return $limit > 0 ? array_slice( $items, 0, $limit ) : $items;
}

function iwla_render_announcements( $limit = 5 ) {
	$out = '';
	foreach ( iwla_get_active_announcements( $limit ) as $p ) {
		$alert = 'alert' === get_post_meta( $p->ID, '_iwla_ann_severity', true );
		$link  = get_post_meta( $p->ID, '_iwla_ann_link', true );
		$label = get_post_meta( $p->ID, '_iwla_ann_link_label', true ) ?: 'More information';
		$icon  = $alert
			? '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 9v4M12 17h.01M10.3 3.9 2.6 17.5c-.5.9.1 2 1.2 2h16.4c1.1 0 1.7-1.1 1.2-2L13.7 3.9c-.6-1-2-1-2.6 0Z"/></svg>'
			: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2.5 4.5 5.5v6c0 5 3.2 8.6 7.5 10 4.3-1.4 7.5-5 7.5-10v-6L12 2.5Z"/></svg>';
		$body  = trim( wp_strip_all_tags( $p->post_content ) );
		$out  .= '<div class="callout' . ( $alert ? ' callout-danger' : '' ) . '"><span class="icon">' . $icon . '</span><div><strong>' . esc_html( get_the_title( $p ) ) . '</strong>';
		if ( $body || $link ) {
			$out .= '<p>' . esc_html( $body );
			if ( $link ) {
				$out .= ( $body ? ' ' : '' ) . '<a href="' . esc_url( $link ) . '">' . esc_html( $label ) . ' &rarr;</a>';
			}
			$out .= '</p>';
		}
		$out .= '</div></div>';
	}
	return $out;
}
