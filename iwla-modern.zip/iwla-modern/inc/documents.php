<?php
/**
 * "Document" content type: chapter PDFs/forms hosted on Google Drive.
 * Admins add/edit these from wp-admin — Documents in the sidebar — with no
 * theme/code changes. Each entry is a title + category + Google Drive link.
 * Use the [iwla_documents category="slug"] shortcode inside any page's
 * content to list them.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function iwla_register_document_type() {
	register_post_type( 'iwla_document', array(
		'labels' => array(
			'name'               => 'Documents',
			'singular_name'      => 'Document',
			'add_new_item'       => 'Add New Document',
			'edit_item'          => 'Edit Document',
			'all_items'          => 'All Documents',
			'menu_name'          => 'Documents',
		),
		'public'             => false,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'menu_icon'          => 'dashicons-media-document',
		'supports'           => array( 'title' ),
		'capability_type'    => 'post',
		'hierarchical'       => false,
	) );

	register_taxonomy( 'iwla_doc_category', 'iwla_document', array(
		'labels' => array(
			'name'          => 'Document Categories',
			'singular_name' => 'Document Category',
		),
		'hierarchical'      => true,
		'show_ui'           => true,
		'show_admin_column' => true,
		'show_in_menu'      => true,
		'query_var'         => false,
		'rewrite'           => false,
		'public'            => false,
	) );
}
add_action( 'init', 'iwla_register_document_type' );

function iwla_seed_document_categories() {
	$terms = array(
		'newsletters' => 'Newsletters',
		'minutes'     => 'Meeting Minutes',
		'governance'  => 'Governance & Bylaws',
		'forms'       => 'Forms',
		'flyers'      => 'Event Flyers',
		'grants'      => 'Grants & Awards',
		'facility-forms' => 'Facility Use Forms',
	);
	foreach ( $terms as $slug => $name ) {
		if ( ! term_exists( $slug, 'iwla_doc_category' ) ) {
			wp_insert_term( $name, 'iwla_doc_category', array( 'slug' => $slug ) );
		}
	}
}
add_action( 'init', 'iwla_seed_document_categories', 11 );

/* ---------------- Meta box: Google Drive link ---------------- */

function iwla_document_meta_box() {
	add_meta_box(
		'iwla_document_link',
		'Google Drive Link',
		'iwla_document_meta_box_html',
		'iwla_document',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'iwla_document_meta_box' );

function iwla_document_meta_box_html( $post ) {
	wp_nonce_field( 'iwla_document_save', 'iwla_document_nonce' );
	$url = get_post_meta( $post->ID, '_iwla_doc_url', true );
	?>
	<p>
		<label for="iwla_doc_url"><strong>Drive share link</strong> (set sharing to "Anyone with the link can view")</label><br>
		<input type="url" id="iwla_doc_url" name="iwla_doc_url" value="<?php echo esc_attr( $url ); ?>" placeholder="https://drive.google.com/file/d/…/view" style="width:100%;max-width:640px;">
	</p>
	<p class="description">The document's Title above is what visitors see as the link text on the site (e.g. "64-3 · Aug–Oct 2026" or "Chapter Bylaws — Nov 2024").</p>
	<?php
}

function iwla_document_save_meta( $post_id ) {
	if ( ! isset( $_POST['iwla_document_nonce'] ) || ! wp_verify_nonce( $_POST['iwla_document_nonce'], 'iwla_document_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( isset( $_POST['iwla_doc_url'] ) ) {
		update_post_meta( $post_id, '_iwla_doc_url', esc_url_raw( wp_unslash( $_POST['iwla_doc_url'] ) ) );
	}
}
add_action( 'save_post_iwla_document', 'iwla_document_save_meta' );

/* ---------------- Admin list column ---------------- */

function iwla_document_admin_columns( $columns ) {
	$columns['iwla_doc_link'] = 'Drive Link';
	return $columns;
}
add_filter( 'manage_iwla_document_posts_columns', 'iwla_document_admin_columns' );

function iwla_document_admin_column_content( $column, $post_id ) {
	if ( 'iwla_doc_link' === $column ) {
		$url = get_post_meta( $post_id, '_iwla_doc_url', true );
		if ( $url ) {
			printf( '<a href="%1$s" target="_blank" rel="noopener">%1$s</a>', esc_url( $url ) );
		} else {
			echo '<span style="color:#a3372c;">No link set</span>';
		}
	}
}
add_action( 'manage_iwla_document_posts_custom_column', 'iwla_document_admin_column_content', 10, 2 );

/* ---------------- Shortcode: [iwla_documents category="slug" limit="10"] ---------------- */

function iwla_documents_shortcode( $atts ) {
	$atts = shortcode_atts( array(
		'category' => '',
		'limit'    => 10,
	), $atts, 'iwla_documents' );

	$query_args = array(
		'post_type'      => 'iwla_document',
		'posts_per_page' => (int) $atts['limit'],
		'orderby'        => 'date',
		'order'          => 'DESC',
	);

	if ( $atts['category'] ) {
		$query_args['tax_query'] = array( array(
			'taxonomy' => 'iwla_doc_category',
			'field'    => 'slug',
			'terms'    => sanitize_title( $atts['category'] ),
		) );
	}

	$docs = get_posts( $query_args );

	if ( empty( $docs ) ) {
		return current_user_can( 'edit_posts' )
			? '<p class="doc-list-empty"><em>No documents posted yet — add one under Documents in wp-admin.</em></p>'
			: '';
	}

	$icon = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/></svg> ';

	$out = '<ul class="doc-list">';
	foreach ( $docs as $doc ) {
		$url = get_post_meta( $doc->ID, '_iwla_doc_url', true );
		if ( $url ) {
			$out .= '<li><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . $icon . esc_html( get_the_title( $doc ) ) . '</a></li>';
		} elseif ( current_user_can( 'edit_posts' ) ) {
			// Only surface the "link pending" placeholder to logged-in editors, not the public.
			$out .= '<li><span class="doc-pending">' . $icon . esc_html( get_the_title( $doc ) ) . ' <em>(add Drive link)</em></span></li>';
		}
	}
	$out .= '</ul>';

	return $out;
}
add_shortcode( 'iwla_documents', 'iwla_documents_shortcode' );
