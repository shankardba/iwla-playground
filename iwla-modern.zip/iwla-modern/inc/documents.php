<?php
/**
 * "Document" content type: chapter PDFs/forms hosted on Google Drive.
 * Admins add/edit these from wp-admin — Documents in the sidebar — with no
 * theme/code changes. Each entry is a title + category + Google Drive link.
 * Use the [iwla_documents category="slug"] shortcode inside any page's
 * content to list them.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function iwla_register_document_type() {
	register_post_type( 'iwla_document', array(
		'labels' => array(
			'name'               => 'Documents',
			'singular_name'      => 'Document',
			'add_new_item'       => 'Add New Document',
			'edit_item'          => 'Edit Document',
			'all_items'          => 'All Documents',
			'menu_name'          => 'Documents',
		),
		'public'             => false,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'menu_icon'          => 'dashicons-media-document',
		'supports'           => array( 'title' ),
		'capability_type'    => 'post',
		'hierarchical'       => false,
	) );

	register_taxonomy( 'iwla_doc_category', 'iwla_document', array(
		'labels' => array(
			'name'          => 'Document Categories',
			'singular_name' => 'Document Category',
		),
		'hierarchical'      => true,
		'show_ui'           => true,
		'show_admin_column' => true,
		'show_in_menu'      => true,
		'query_var'         => false,
		'rewrite'           => false,
		'public'            => false,
	) );
}
add_action( 'init', 'iwla_register_document_type' );

function iwla_seed_document_categories() {
	$terms = array(
		'newsletters' => 'Newsletters',
		'minutes'     => 'Meeting Minutes',
		'governance'  => 'Governance & Bylaws',
		'forms'       => 'Forms',
		'flyers'      => 'Event Flyers',
		'grants'      => 'Grants & Awards',
		'facility-forms' => 'Facility Use Forms',
		'membership'  => 'Membership & Renewals',
		'officer-bios' => 'Officer Bios',
		'rifle-pistol' => 'Rifle & Pistol',
		'skeet-trap'   => 'Skeet & Trap',
		'archery'      => 'Archery',
		'cub-run-archers' => 'Cub Run Archers',
		'cra-minutes'  => 'Cub Run Archers Minutes',
		'youth'        => 'Youth Programs',
		'education-scholarship' => 'Education & Scholarship',
		'air-range'    => 'Air Range',
		'chapter-notices' => 'Chapter Notices',
		'history-maps' => 'History & Maps',
	);
	foreach ( $terms as $slug => $name ) {
		if ( ! term_exists( $slug, 'iwla_doc_category' ) ) {
			wp_insert_term( $name, 'iwla_doc_category', array( 'slug' => $slug ) );
		}
	}
}
add_action( 'init', 'iwla_seed_document_categories', 11 );

/* ---------------- Meta box: Google Drive link ---------------- */

function iwla_document_meta_box() {
	add_meta_box(
		'iwla_document_link',
		'Google Drive Link',
		'iwla_document_meta_box_html',
		'iwla_document',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'iwla_document_meta_box' );

function iwla_document_meta_box_html( $post ) {
	wp_nonce_field( 'iwla_document_save', 'iwla_document_nonce' );
	$url = get_post_meta( $post->ID, '_iwla_doc_url', true );
	?>
	<p>
		<label for="iwla_doc_url"><strong>Drive share link</strong> (set sharing to "Anyone with the link can view")</label><br>
		<input type="url" id="iwla_doc_url" name="iwla_doc_url" value="<?php echo esc_attr( $url ); ?>" placeholder="https://drive.google.com/file/d/…/view" style="width:100%;max-width:640px;">
	</p>
	<p class="description">The document's Title above is what visitors see as the link text on the site (e.g. "64-3 · Aug–Oct 2026" or "Chapter Bylaws — Nov 2024").</p>
	<?php
}

function iwla_document_save_meta( $post_id ) {
	if ( ! isset( $_POST['iwla_document_nonce'] ) || ! wp_verify_nonce( $_POST['iwla_document_nonce'], 'iwla_document_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( isset( $_POST['iwla_doc_url'] ) ) {
		update_post_meta( $post_id, '_iwla_doc_url', esc_url_raw( wp_unslash( $_POST['iwla_doc_url'] ) ) );
	}
}
add_action( 'save_post_iwla_document', 'iwla_document_save_meta' );

/* ---------------- Admin list column ---------------- */

function iwla_document_admin_columns( $columns ) {
	$columns['iwla_doc_link'] = 'Drive Link';
	return $columns;
}
add_filter( 'manage_iwla_document_posts_columns', 'iwla_document_admin_columns' );

function iwla_document_admin_column_content( $column, $post_id ) {
	if ( 'iwla_doc_link' === $column ) {
		$url = get_post_meta( $post_id, '_iwla_doc_url', true );
		if ( $url ) {
			printf( '<a href="%1$s" target="_blank" rel="noopener">%1$s</a>', esc_url( $url ) );
		} else {
			echo '<span style="color:#a3372c;">No link set</span>';
		}
	}
}
add_action( 'manage_iwla_document_posts_custom_column', 'iwla_document_admin_column_content', 10, 2 );

/* ---------------- Shortcodes ---------------- */

function iwla_doc_icon() {
	return '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/></svg> ';
}

function iwla_doc_li( $doc ) {
	$url = get_post_meta( $doc->ID, '_iwla_doc_url', true );
	if ( $url ) {
		return '<li><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . iwla_doc_icon() . esc_html( get_the_title( $doc ) ) . '</a></li>';
	}
	if ( current_user_can( 'edit_posts' ) ) {
		// Only editors see the "link pending" placeholder, not the public.
		return '<li><span class="doc-pending">' . iwla_doc_icon() . esc_html( get_the_title( $doc ) ) . ' <em>(add Drive link)</em></span></li>';
	}
	return '';
}

/**
 * [iwla_documents category="slug" limit="10" orderby="date|title" order="DESC|ASC" group="year" open="2026"]
 * group="year" wraps each year in a collapsible block; open="YYYY" leaves that year expanded.
 */
function iwla_documents_shortcode( $atts ) {
	$atts = shortcode_atts( array(
		'category' => '',
		'limit'    => 10,
		'orderby'  => 'date',
		'order'    => 'DESC',
		'group'    => '',
		'open'     => '',
	), $atts, 'iwla_documents' );

	$query_args = array(
		'post_type'      => 'iwla_document',
		'posts_per_page' => (int) $atts['limit'],
		'orderby'        => 'title' === $atts['orderby'] ? 'title' : 'date',
		'order'          => 'ASC' === strtoupper( $atts['order'] ) ? 'ASC' : 'DESC',
	);
	if ( $atts['category'] ) {
		$query_args['tax_query'] = array( array(
			'taxonomy' => 'iwla_doc_category',
			'field'    => 'slug',
			'terms'    => sanitize_title( $atts['category'] ),
		) );
	}
	$docs = get_posts( $query_args );

	if ( empty( $docs ) ) {
		return current_user_can( 'edit_posts' )
			? '<p class="doc-list-empty"><em>No documents posted yet — add one under Documents in wp-admin.</em></p>'
			: '';
	}

	if ( 'year' === $atts['group'] ) {
		$by_year = array();
		foreach ( $docs as $doc ) {
			$by_year[ mysql2date( 'Y', $doc->post_date ) ][] = $doc;
		}
		$out = '<div class="doc-years">';
		foreach ( $by_year as $year => $items ) {
			$out .= '<details class="doc-year"' . ( (string) $year === (string) $atts['open'] ? ' open' : '' ) . '><summary>' . esc_html( $year ) . ' <span class="muted">(' . count( $items ) . ')</span></summary><ul class="doc-list">';
			foreach ( $items as $doc ) {
				$out .= iwla_doc_li( $doc );
			}
			$out .= '</ul></details>';
		}
		return $out . '</div>';
	}

	$out = '<ul class="doc-list">';
	foreach ( $docs as $doc ) {
		$out .= iwla_doc_li( $doc );
	}
	return $out . '</ul>';
}
add_shortcode( 'iwla_documents', 'iwla_documents_shortcode' );

/**
 * One document as an inline link, found by its original file name:
 * [iwla_doc file="BrinoBio.pdf" text="Bio"]
 */
function iwla_doc_find_by_file( $file ) {
	$found = get_posts( array(
		'post_type'      => 'iwla_document',
		'posts_per_page' => 1,
		'meta_key'       => '_iwla_doc_file_lc',
		'meta_value'     => strtolower( $file ),
	) );
	return $found ? $found[0] : null;
}

function iwla_doc_shortcode( $atts ) {
	$atts = shortcode_atts( array( 'file' => '', 'text' => '', 'class' => '' ), $atts, 'iwla_doc' );
	$doc  = $atts['file'] ? iwla_doc_find_by_file( $atts['file'] ) : null;
	if ( ! $doc ) {
		return '';
	}
	$url = get_post_meta( $doc->ID, '_iwla_doc_url', true );
	if ( ! $url ) {
		return '';
	}
	$text = $atts['text'] ? $atts['text'] : get_the_title( $doc );
	$class = $atts['class'] ? ' class="' . esc_attr( $atts['class'] ) . '"' : '';
	return '<a' . $class . ' href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $text ) . '</a>';
}
add_shortcode( 'iwla_doc', 'iwla_doc_shortcode' );

/**
 * [iwla_document_library]: every document category as a collapsible list (minutes and newsletters have their own sections).
 */
function iwla_document_library_shortcode() {
	$skip  = array( 'minutes', 'newsletters', 'forms', 'flyers', 'grants', 'officer-bios' );
	$terms = get_terms( array( 'taxonomy' => 'iwla_doc_category', 'hide_empty' => true ) );
	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return '';
	}
	$out = '<div class="doc-years">';
	foreach ( $terms as $t ) {
		if ( in_array( $t->slug, $skip, true ) ) {
			continue;
		}
		$out .= '<details class="doc-year"><summary>' . esc_html( $t->name ) . ' <span class="muted">(' . (int) $t->count . ')</span></summary>'
			. iwla_documents_shortcode( array( 'category' => $t->slug, 'limit' => -1, 'orderby' => 'title', 'order' => 'ASC' ) ) . '</details>';
	}
	return $out . '</div>';
}
add_shortcode( 'iwla_document_library', 'iwla_document_library_shortcode' );

/**
 * Create or update one Document from the site's data file (used by the seed script).
 */
function iwla_upsert_document_row( $row ) {
	$existing = get_posts( array(
		'post_type'      => 'iwla_document',
		'post_status'    => 'any',
		'posts_per_page' => 1,
		'meta_key'       => '_iwla_doc_legacy_lc',
		'meta_value'     => strtolower( $row['legacy_path'] ),
	) );
	// A date in the future (even later today) would make WordPress schedule the post instead of publishing it.
	$stamp = $row['date'] . ' 12:00:00';
	if ( $stamp > current_time( 'mysql' ) ) {
		$stamp = current_time( 'mysql' );
	}
	$postarr = array(
		'post_type'     => 'iwla_document',
		'post_status'   => 'publish',
		'post_title'    => $row['title'],
		'post_date'     => $stamp,
		'post_date_gmt' => get_gmt_from_date( $stamp ),
	);
	if ( $existing ) {
		$postarr['ID'] = $existing[0]->ID;
		$id            = wp_update_post( $postarr );
	} else {
		$id = wp_insert_post( $postarr );
	}
	update_post_meta( $id, '_iwla_doc_url', 'https://drive.google.com/file/d/' . $row['drive_id'] . '/view' );
	update_post_meta( $id, '_iwla_doc_drive_id', $row['drive_id'] );
	update_post_meta( $id, '_iwla_doc_file', $row['filename'] );
	update_post_meta( $id, '_iwla_doc_file_lc', strtolower( $row['filename'] ) );
	update_post_meta( $id, '_iwla_doc_legacy', $row['legacy_path'] );
	update_post_meta( $id, '_iwla_doc_legacy_lc', strtolower( $row['legacy_path'] ) );
	wp_set_object_terms( $id, $row['category'], 'iwla_doc_category' );
	return $id;
}
