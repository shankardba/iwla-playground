<?php
/**
 * Tools > Chapter Setup: one-click creation of the standard pages, menu,
 * courses, announcements and documents on a fresh WordPress install
 * (no command line needed). Safe to open at any time; running it again
 * resets the standard pages to their original text.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function iwla_setup_menu() {
	add_management_page( 'Chapter Setup', 'Chapter Setup', 'manage_options', 'iwla-setup', 'iwla_setup_page' );
}
add_action( 'admin_menu', 'iwla_setup_menu' );

function iwla_setup_banners() {
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$map = array(
		'rifle-pistol' => array( 'rifle-pistol.jpg', 'Drone photo looking down the covered firing line at the Rifle & Pistol range, with the berm and target area beyond' ),
		'skeet-trap'   => array( 'skeet-trap.jpg', 'Drone photo looking down on the fan-shaped skeet and trap shooting stations, with the shot-fall field and tree line beyond' ),
		'archery'      => array( 'archery.jpg', 'A row of archery targets across a grass field, with the field archery gazebo on the right, framed by trees' ),
		'conservation' => array( 'conservation.jpg', 'A wooden bench overlooking the chapter pond on a clear winter day' ),
		'air-range'    => array( 'air-range.jpg', 'Panoramic view of the indoor Sills Air Range: a long row of shooting stations facing the target line' ),
	);
	$up    = wp_upload_dir();
	$added = 0;
	foreach ( $map as $slug => $info ) {
		$pages = get_posts( array( 'post_type' => 'page', 'name' => $slug, 'numberposts' => 1 ) );
		$src   = get_template_directory() . '/assets/seed-media/' . $info[0];
		if ( ! $pages || has_post_thumbnail( $pages[0]->ID ) || ! is_readable( $src ) ) {
			continue;
		}
		$dest = trailingslashit( $up['path'] ) . wp_unique_filename( $up['path'], $info[0] );
		if ( ! copy( $src, $dest ) ) {
			continue;
		}
		$id = wp_insert_attachment( array( 'post_mime_type' => 'image/jpeg', 'post_title' => $slug . ' banner', 'post_status' => 'inherit' ), $dest, $pages[0]->ID );
		wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $dest ) );
		update_post_meta( $id, '_wp_attachment_image_alt', $info[1] );
		set_post_thumbnail( $pages[0]->ID, $id );
		$added++;
	}
	return $added;
}

function iwla_run_setup() {
	update_option( 'permalink_structure', '/%postname%/' );
	ob_start();
	require_once get_template_directory() . '/seed-content.php';
	$log = trim( ob_get_clean() );
	$banners = iwla_setup_banners();
	flush_rewrite_rules();
	return $log . "\nBanner photos added: " . $banners . '.';
}

function iwla_setup_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$log = '';
	if ( isset( $_POST['iwla_setup_go'] ) && check_admin_referer( 'iwla_setup', 'iwla_setup_nonce' ) && ! empty( $_POST['iwla_setup_confirm'] ) ) {
		@set_time_limit( 300 );
		$log = iwla_run_setup();
	}
	$pages = (int) wp_count_posts( 'page' )->publish;
	$docs  = (int) wp_count_posts( 'iwla_document' )->publish;
	?>
	<div class="wrap">
		<h1>Chapter Setup</h1>
		<?php if ( $log ) : ?>
			<div class="notice notice-success"><p><strong>Done.</strong> The site is set up. <a href="<?php echo esc_url( home_url( '/' ) ); ?>">View the site</a>.</p><pre style="white-space:pre-wrap;"><?php echo esc_html( $log ); ?></pre></div>
		<?php endif; ?>
		<p>Creates the chapter's standard pages (Home, About, Membership, Ranges and its sub-pages, Calendar, Conservation, Youth, Resources, Contact), the main menu, the course schedule, the starting announcements, and the document library with its Google Drive links. It also sets the front page, the New York time zone and the permalink style, and adds the banner photos.</p>
		<p>Right now this site has <strong><?php echo (int) $pages; ?></strong> published pages and <strong><?php echo (int) $docs; ?></strong> documents.</p>
		<p><strong>Run this once, on a new site.</strong> Running it again puts the standard pages back to their original text, which would replace any edits made to them.</p>
		<form method="post">
			<?php wp_nonce_field( 'iwla_setup', 'iwla_setup_nonce' ); ?>
			<p><label><input type="checkbox" name="iwla_setup_confirm" value="1"> I understand, set up this site.</label></p>
			<p><button type="submit" name="iwla_setup_go" value="1" class="button button-primary button-hero">Set up the site</button></p>
		</form>
	</div>
	<?php
}
