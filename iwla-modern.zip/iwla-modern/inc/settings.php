<?php
/**
 * Settings > Chapter Settings: grounds status, calendar feed, online payment links.
 * Everything an admin needs to change day to day lives here or in the content types.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function iwla_settings_defaults() {
	return array(
		'status'         => 'open',
		'status_note'    => '',
		'calendar_feeds' => '',
		'calendar_cache' => 15,
		'pay_renewal'    => '',
		'pay_archery201' => '',
	);
}

function iwla_opt( $key, $default = '' ) {
	$opts = wp_parse_args( get_option( 'iwla_settings', array() ), iwla_settings_defaults() );
	return isset( $opts[ $key ] ) && '' !== $opts[ $key ] ? $opts[ $key ] : $default;
}

function iwla_settings_menu() {
	add_options_page( 'Chapter Settings', 'Chapter Settings', 'manage_options', 'iwla-settings', 'iwla_settings_page' );
}
add_action( 'admin_menu', 'iwla_settings_menu' );

function iwla_settings_register() {
	register_setting( 'iwla_settings_group', 'iwla_settings', array( 'sanitize_callback' => 'iwla_settings_sanitize' ) );
}
add_action( 'admin_init', 'iwla_settings_register' );

function iwla_settings_sanitize( $in ) {
	$out           = array();
	$out['status'] = in_array( $in['status'] ?? 'open', array( 'open', 'limited', 'closed' ), true ) ? $in['status'] : 'open';
	$out['status_note']    = sanitize_text_field( $in['status_note'] ?? '' );
	$out['calendar_cache'] = max( 1, (int) ( $in['calendar_cache'] ?? 15 ) );
	$lines                 = preg_split( '/\r\n|\r|\n/', (string) ( $in['calendar_feeds'] ?? '' ) );
	$clean                 = array();
	foreach ( $lines as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$parts = array_map( 'trim', explode( '|', $line, 2 ) );
		$url   = esc_url_raw( end( $parts ) );
		if ( $url ) {
			$clean[] = count( $parts ) > 1 ? sanitize_text_field( $parts[0] ) . '|' . $url : $url;
		}
	}
	$out['calendar_feeds']  = implode( "\n", $clean );
	$out['pay_renewal']     = esc_url_raw( $in['pay_renewal'] ?? '' );
	$out['pay_archery201']  = esc_url_raw( $in['pay_archery201'] ?? '' );
	// Changing feeds or cache time should take effect immediately.
	update_option( 'iwla_cal_bust', time() );
	return $out;
}

function iwla_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$o = wp_parse_args( get_option( 'iwla_settings', array() ), iwla_settings_defaults() );
	?>
	<div class="wrap">
		<h1>Chapter Settings</h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'iwla_settings_group' ); ?>

			<h2>Grounds status</h2>
			<p class="description">Shown in the bar at the very top of every page.</p>
			<table class="form-table" role="presentation">
				<tr><th scope="row">Status</th><td>
					<select name="iwla_settings[status]">
						<option value="open" <?php selected( $o['status'], 'open' ); ?>>Open</option>
						<option value="limited" <?php selected( $o['status'], 'limited' ); ?>>Limited operations</option>
						<option value="closed" <?php selected( $o['status'], 'closed' ); ?>>Closed</option>
					</select>
				</td></tr>
				<tr><th scope="row"><label for="iwla_status_note">Short note</label></th><td>
					<input type="text" id="iwla_status_note" class="regular-text" name="iwla_settings[status_note]" value="<?php echo esc_attr( $o['status_note'] ); ?>" placeholder="e.g. Rifle/Pistol range closed for repairs">
					<p class="description">Optional. Leave blank to show the default "range badge required on all ranges".</p>
				</td></tr>
			</table>

			<h2>Chapter calendar</h2>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="iwla_cal_feeds">Google Calendar feed(s)</label></th><td>
					<textarea id="iwla_cal_feeds" name="iwla_settings[calendar_feeds]" rows="4" class="large-text code" placeholder="https://calendar.google.com/calendar/ical/.../public/basic.ics"><?php echo esc_textarea( $o['calendar_feeds'] ); ?></textarea>
					<p class="description">One address per line, optionally as <code>Label|https://…</code>. In Google Calendar: Settings → the calendar → "Integrate calendar" → "Public address in iCal format" (the calendar must be public) or the "Secret address in iCal format". Several feeds are merged.</p>
				</td></tr>
				<tr><th scope="row"><label for="iwla_cal_cache">Refresh every (minutes)</label></th><td>
					<input type="number" min="1" id="iwla_cal_cache" name="iwla_settings[calendar_cache]" value="<?php echo esc_attr( $o['calendar_cache'] ); ?>" class="small-text">
				</td></tr>
			</table>

			<h2>Online payment links</h2>
			<p class="description">Paste the PayPal (or other) payment link. Leave blank to hide the button. Individual NRA courses have their own link on each course entry.</p>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="iwla_pay_renewal">Membership renewal</label></th><td>
					<input type="url" id="iwla_pay_renewal" class="large-text" name="iwla_settings[pay_renewal]" value="<?php echo esc_attr( $o['pay_renewal'] ); ?>"> <p class="description">Shown on the Membership page.</p>
				</td></tr>
				<tr><th scope="row"><label for="iwla_pay_a201">Archery 201 class</label></th><td>
					<input type="url" id="iwla_pay_a201" class="large-text" name="iwla_settings[pay_archery201]" value="<?php echo esc_attr( $o['pay_archery201'] ); ?>"> <p class="description">Shown on the Education &amp; Training page.</p>
				</td></tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/**
 * Top-bar status HTML (reads Chapter Settings).
 */
function iwla_topbar_status_html() {
	$status = iwla_opt( 'status', 'open' );
	$note   = iwla_opt( 'status_note', '' );
	$labels = array( 'open' => 'OPEN', 'limited' => 'LIMITED OPERATIONS', 'closed' => 'CLOSED' );
	$dot    = 'open' === $status ? 'dot' : 'dot closed';
	$text   = $note ? $note : ( 'open' === $status ? 'range badge required on all ranges' : '' );
	$html   = '<span class="' . esc_attr( $dot ) . '"></span> Grounds status: <strong>&nbsp;' . esc_html( $labels[ $status ] ) . '</strong>';
	if ( $text ) {
		$html .= ' &mdash; ' . esc_html( $text );
	}
	return $html;
}

/* ---------------- Shortcode: [iwla_pay key="renewal|archery201" label="Renew online"] ---------------- */

function iwla_pay_shortcode( $atts ) {
	$atts = shortcode_atts( array( 'key' => '', 'label' => 'Pay online' ), $atts, 'iwla_pay' );
	$map  = array( 'renewal' => 'pay_renewal', 'archery201' => 'pay_archery201' );
	$url  = isset( $map[ $atts['key'] ] ) ? iwla_opt( $map[ $atts['key'] ] ) : '';
	if ( $url ) {
		return '<p><a class="btn btn-primary btn-sm" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $atts['label'] ) . '</a></p>';
	}
	if ( current_user_can( 'edit_posts' ) ) {
		return '<p class="doc-pending"><em>(Payment button hidden &mdash; add the link under Settings &rarr; Chapter Settings.)</em></p>';
	}
	return '';
}
add_shortcode( 'iwla_pay', 'iwla_pay_shortcode' );
