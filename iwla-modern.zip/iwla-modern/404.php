<?php
/**
 * 404 template.
 */
get_header();
?>
<section class="page-hero">
	<div class="container">
		<h1>Page not found</h1>
		<p class="lead">Sorry &mdash; that address doesn't match anything on the chapter's site. It may have moved when the site was rebuilt.</p>
	</div>
</section>
<div class="container">
	<div class="content-wrap">
		<div class="entry-content">
			<h2>Try a search</h2>
			<?php get_search_form(); ?>

			<h2>Or head straight to</h2>
			<ul class="quick-links">
				<li><a href="<?php echo esc_url( home_url( '/calendar/' ) ); ?>"><strong>Calendar</strong><span>Range hours, events, and closures</span></a></li>
				<li><a href="<?php echo esc_url( home_url( '/ranges/' ) ); ?>"><strong>Ranges &amp; Training</strong><span>Hours, rules, leagues, classes</span></a></li>
				<li><a href="<?php echo esc_url( home_url( '/membership/' ) ); ?>"><strong>Membership</strong><span>Join, renew, FAQ</span></a></li>
				<li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><strong>Contact</strong><span>Address, phones, officers</span></a></li>
				<li><a href="<?php echo esc_url( home_url( '/resources/' ) ); ?>"><strong>Resources</strong><span>Newsletters, minutes, scholarship</span></a></li>
				<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><strong>Home</strong><span>Start over</span></a></li>
			</ul>
			<p>Still stuck? Call the chapter office at <a href="tel:7036314495">703-631-4495</a> or write to <a href="mailto:membershipscy@arlingtonfairfax-iwla.org">membershipscy@arlingtonfairfax-iwla.org</a>.</p>
		</div>
	</div>
</div>
<?php get_footer(); ?>
