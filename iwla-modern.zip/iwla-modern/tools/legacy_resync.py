#!/usr/bin/env python3
"""
Compare the legacy site's published pages against the new site, to find
content that changed on the legacy site since the snapshot and facts
(emails, phone numbers, dollar amounts) that the new site is missing.

Read-only: only GET requests to the public WordPress REST API.

Usage:
  python3 tools/legacy_resync.py [--since 2026-09-01] [--legacy URL] [--new URL]
"""
import argparse, html, json, re, sys, urllib.request


def get_all(base, params=""):
    out, page = [], 1
    while True:
        url = "%s/wp-json/wp/v2/pages?per_page=100&page=%d%s" % (base.rstrip("/"), page, params)
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        try:
            resp = urllib.request.urlopen(req, timeout=60)
        except Exception as e:  # past the last page returns 400
            break
        data = json.load(resp)
        if not data:
            break
        out += data
        if page >= int(resp.headers.get("X-WP-TotalPages", "1")):
            break
        page += 1
    return out


def text(h):
    h = re.sub(r"<(script|style)[^>]*>.*?</\1>", "", h, flags=re.S)
    h = re.sub(r"<[^>]+>", " ", h)
    return re.sub(r"\s+", " ", html.unescape(h))


def facts(t):
    f = set(m.lower() for m in re.findall(r"[\w.+-]+@[\w-]+\.[\w.-]+", t))
    f |= set(re.sub(r"\D", "", m)[-10:] for m in re.findall(r"\(?\b\d{3}\)?[-. ]\d{3}[-. ]\d{4}\b", t))
    f |= set(m.replace(" ", "") for m in re.findall(r"\$\s?\d[\d,]*(?:\.\d\d)?", t))
    return f


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--since", default="2026-09-01")
    ap.add_argument("--legacy", default="https://wp.arlingtonfairfax-iwla.org")
    ap.add_argument("--new", default="http://localhost:8888")
    a = ap.parse_args()

    legacy = get_all(a.legacy, "&status=publish")
    new = get_all(a.new)
    new_text = " ".join(text(p["content"]["rendered"]) for p in new)
    new_text += " " + " ".join(text(p["title"]["rendered"]) for p in new)
    new_norm = re.sub(r"\D", "", new_text)
    new_low = new_text.lower().replace(" ", "")

    print("Legacy pages edited since %s:" % a.since)
    changed = sorted((p for p in legacy if p["modified"][:10] >= a.since), key=lambda p: p["modified"], reverse=True)
    for p in changed:
        print("  %s  %s  /%s/" % (p["modified"][:10], html.unescape(p["title"]["rendered"]), p["slug"]))
    print("\nFacts on those pages that do not appear anywhere on the new site:")
    for p in changed:
        missing = []
        for f in sorted(facts(text(p["content"]["rendered"]))):
            ok = (f in new_norm) if f.isdigit() else (f.replace(" ", "") in new_low)
            if not ok:
                missing.append(f)
        if missing:
            print("  /%s/: %s" % (p["slug"], ", ".join(missing[:12])))


if __name__ == "__main__":
    sys.exit(main())
