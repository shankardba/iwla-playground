#!/usr/bin/env python3
"""
Crawl the site and report broken links.

  python3 tools/link_check.py [--site http://localhost:8888] [--external]

Internal links are checked for HTTP status and for a matching #anchor.
With --external, off-site links get a request too (read-only; some sites
block scripts, so 403/405/429 are reported as "uncertain", not broken).
"""
import argparse, html, re, sys, urllib.request, urllib.error, urllib.parse
from concurrent.futures import ThreadPoolExecutor

UA = {"User-Agent": "Mozilla/5.0 (link-check)"}


def fetch(url, method="GET", timeout=20):
    req = urllib.request.Request(url, headers=UA, method=method)
    try:
        r = urllib.request.urlopen(req, timeout=timeout)
        return r.status, r.geturl(), (r.read() if method == "GET" else b"")
    except urllib.error.HTTPError as e:
        return e.code, url, b""
    except Exception as e:
        return 0, url, str(e).encode()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--site", default="http://localhost:8888")
    ap.add_argument("--external", action="store_true")
    a = ap.parse_args()
    site = a.site.rstrip("/")
    host = urllib.parse.urlparse(site).netloc

    # pages from the sitemap
    _, _, idx = fetch(site + "/wp-sitemap.xml")
    sitemaps = re.findall(r"<loc>([^<]+)</loc>", idx.decode("utf8", "ignore"))
    pages = []
    for sm in sitemaps:
        sm = sm.replace("http://localhost:8888", site)
        _, _, body = fetch(sm)
        pages += re.findall(r"<loc>([^<]+)</loc>", body.decode("utf8", "ignore"))
    pages = [p.replace("http://localhost:8888", site) for p in pages]
    pages = sorted(set(pages) | {site + "/"})

    links = {}  # url -> set(source pages)
    anchors = {}
    for p in pages:
        st, _, body = fetch(p)
        text = body.decode("utf8", "ignore")
        anchors[p.split("#")[0]] = set(re.findall(r'\sid="([^"]+)"', text))
        main_html = re.sub(r"<(script|style)[^>]*>.*?</\1>", "", text, flags=re.S)
        for href in re.findall(r'<a\s[^>]*href="([^"]+)"', main_html):
            href = html.unescape(href).strip()
            if href.startswith(("mailto:", "tel:", "javascript:", "#")) or not href:
                if href.startswith("#"):
                    link = p.split("#")[0] + href
                    links.setdefault(link, set()).add(p)
                continue
            href = urllib.parse.urljoin(p, href)
            links.setdefault(href, set()).add(p)

    bad = []

    def check(item):
        url, srcs = item
        base, _, frag = url.partition("#")
        u = urllib.parse.urlparse(base)
        internal = u.netloc == host
        if not internal and not a.external:
            return None
        if internal and base.rstrip("/") + "/" not in [x if x.endswith("/") else x + "/" for x in anchors] and base not in anchors:
            pass
        st, final, body = fetch(base, "GET")
        if st in (403, 405, 429, 999) and not internal:
            return ("uncertain", st, url, srcs)
        if st == 0 or st >= 400:
            return ("broken", st, url, srcs)
        if internal and frag:
            ids = anchors.get(final.split("#")[0]) or anchors.get(base)
            if ids is None:
                ids = set(re.findall(r'\sid="([^"]+)"', body.decode("utf8", "ignore")))
            if frag not in ids:
                return ("missing-anchor", st, url, srcs)
        return None

    with ThreadPoolExecutor(8) as ex:
        for r in ex.map(check, sorted(links.items())):
            if r:
                bad.append(r)

    ext = sum(1 for u in links if urllib.parse.urlparse(u).netloc != host)
    print("Pages crawled: %d | unique links: %d (%d external%s)" % (len(pages), len(links), ext, "" if a.external else ", not checked"))
    if not bad:
        print("No broken links.")
    for kind, st, url, srcs in sorted(bad):
        print("%-14s %s  %s\n    on: %s" % (kind, st, url, ", ".join(sorted(s.replace(site, "") or "/" for s in srcs))[:160]))
    return 1 if any(b[0] in ("broken", "missing-anchor") for b in bad) else 0


if __name__ == "__main__":
    sys.exit(main())
